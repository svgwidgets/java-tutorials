<template>
  <v-layout>
    <v-main>
      <v-container class="examples-page">
        <div class="d-flex align-center mb-6">
          <v-icon size="24" color="primary" class="mr-3">mdi-book-open-variant</v-icon>
          <div>
            <h1 class="text-h5 font-weight-bold">Example Diagrams</h1>
            <p class="text-body-2 text-medium-emphasis">Load a pre-built diagram to explore the designer.</p>
          </div>
          <v-spacer />
          <v-btn variant="outlined" to="/designer">
            <v-icon start>mdi-arrow-left</v-icon> Back to Designer
          </v-btn>
        </div>

        <v-row>
          <v-col v-for="example in examples" :key="example.id" cols="12" md="4">
            <v-card variant="outlined" class="example-card" @click="loadExample(example)">
              <v-card-item>
                <v-card-title>{{ example.name }}</v-card-title>
                <v-card-subtitle>{{ example.description }}</v-card-subtitle>
              </v-card-item>
              <v-card-text class="text-medium-emphasis">
                {{ example.nodeCount }} nodes · {{ example.edgeCount }} connections
              </v-card-text>
              <v-card-actions>
                <v-btn color="primary" variant="text" @click.stop="loadExample(example)">
                  Load Diagram
                  <v-icon end>mdi-arrow-right</v-icon>
                </v-btn>
              </v-card-actions>
            </v-card>
          </v-col>
        </v-row>
      </v-container>
    </v-main>
  </v-layout>
</template>

<script setup lang="ts">
import { useRouter } from 'vue-router'
import { useDiagramStore } from '@/stores/useDiagramStore'
import { createNode, createEdge } from '@/domain/defaults'
import type { Diagram } from '@/domain/models'
import { uid } from '@/utils/uid'

const router = useRouter()
const store = useDiagramStore()

interface ExampleDef {
  id: string
  name: string
  description: string
  nodeCount: number
  edgeCount: number
  build: () => Diagram
}

const examples: ExampleDef[] = [
  {
    id: 'simple-flow',
    name: 'Simple Flow Loop',
    description: 'Tank → Valve → Pump → Tank with a pressure sensor.',
    nodeCount: 5,
    edgeCount: 4,
    build: buildSimpleFlow,
  },
  {
    id: 'dual-tank',
    name: 'Dual Tank Transfer',
    description: 'Two tanks connected via valves and a pump.',
    nodeCount: 7,
    edgeCount: 6,
    build: buildDualTank,
  },
  {
    id: 'junction-demo',
    name: 'Junction Demo',
    description: 'Junction node connecting multiple components.',
    nodeCount: 6,
    edgeCount: 5,
    build: buildJunctionDemo,
  },
]

function buildSimpleFlow(): Diagram {
  const t1 = createNode('vertical-tank', { x: 50, y: 50 }, { label: 'T-001' })
  const v1 = createNode('manual-valve', { x: 230, y: 150 }, { label: 'V-001', props: { state: 'open', alarm: 'none' } })
  const p1 = createNode('centrifugal-pump', { x: 370, y: 140 }, { label: 'P-001', props: { state: 'running', alarm: 'none' } })
  const t2 = createNode('vertical-tank', { x: 550, y: 50 }, { label: 'T-002' })
  const pt = createNode('pressure-sensor', { x: 300, y: 40 }, { label: 'PT-001', props: { value: 125.5, units: 'PSI', alarm: 'none', tag: 'PT' } })

  return {
    schemaVersion: 1, id: uid(), name: 'Simple Flow Loop',
    createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    nodes: [t1, v1, p1, t2, pt],
    edges: [],
    viewport: { panX: 50, panY: 50, zoom: 1 },
  }
}

function buildDualTank(): Diagram {
  const t1 = createNode('vertical-tank', { x: 50, y: 50 }, { label: 'T-001' })
  const v1 = createNode('manual-valve', { x: 230, y: 190 }, { label: 'V-001' })
  const p1 = createNode('centrifugal-pump', { x: 370, y: 180 }, { label: 'P-001' })
  const v2 = createNode('manual-valve', { x: 510, y: 190 }, { label: 'V-002' })
  const t2 = createNode('vertical-tank', { x: 640, y: 50 }, { label: 'T-002' })
  const pt1 = createNode('pressure-sensor', { x: 300, y: 40 }, { label: 'PT-001', props: { value: 85, units: 'PSI', alarm: 'none', tag: 'PT' } })
  const pt2 = createNode('pressure-sensor', { x: 540, y: 40 }, { label: 'PT-002', props: { value: 42, units: 'PSI', alarm: 'none', tag: 'PT' } })

  return {
    schemaVersion: 1, id: uid(), name: 'Dual Tank Transfer',
    createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    nodes: [t1, v1, p1, v2, t2, pt1, pt2],
    edges: [],
    viewport: { panX: 30, panY: 30, zoom: 1 },
  }
}

function buildJunctionDemo(): Diagram {
  const j1 = createNode('junction', { x: 350, y: 200 }, { label: 'J-001' })
  const v1 = createNode('manual-valve', { x: 100, y: 200 }, { label: 'V-001' })
  const v2 = createNode('manual-valve', { x: 550, y: 200 }, { label: 'V-002' })
  const p1 = createNode('centrifugal-pump', { x: 320, y: 50 }, { label: 'P-001' })
  const t1 = createNode('vertical-tank', { x: 300, y: 320 }, { label: 'T-001' })
  const pt = createNode('pressure-sensor', { x: 500, y: 80 }, { label: 'PT-001', props: { value: 55, units: 'PSI', alarm: 'none', tag: 'PT' } })

  return {
    schemaVersion: 1, id: uid(), name: 'Junction Demo',
    createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    nodes: [j1, v1, v2, p1, t1, pt],
    edges: [],
    viewport: { panX: 50, panY: 20, zoom: 1 },
  }
}

function loadExample(example: ExampleDef) {
  const diagram = example.build()
  store.loadDiagram(diagram)
  router.push('/designer')
}
</script>

<style scoped>
.examples-page { max-width: 900px; padding-top: 40px; }
.example-card { cursor: pointer; transition: border-color 0.15s; }
.example-card:hover { border-color: rgb(var(--v-theme-primary)); }
</style>
