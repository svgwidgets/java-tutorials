<template>
  <v-layout class="designer-layout">
    <!-- Palette (edit mode only) -->
    <v-navigation-drawer
      v-if="store.isEditMode"
      permanent
      :width="220"
      color="surface"
    >
      <PalettePanel :screen-to-canvas="screenToCanvas" />
    </v-navigation-drawer>

    <v-main>
      <AppToolbar />

      <div
        class="canvas-wrapper"
        @drop.prevent="onCanvasDrop"
        @dragover.prevent="onDragOver"
      >
        <DiagramCanvas ref="canvasRef" />
      </div>

      <AppStatusBar />
    </v-main>
  </v-layout>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useDiagramStore } from '@/stores/useDiagramStore'
import { usePaletteDrop } from '@/composables/usePaletteDrop'
import { getNodeType } from '@/domain/defaults'
import type { Point } from '@/domain/models'

import AppToolbar from '@/components/layout/AppToolbar.vue'
import AppStatusBar from '@/components/layout/AppStatusBar.vue'
import PalettePanel from '@/components/layout/PalettePanel.vue'
import DiagramCanvas from '@/components/canvas/DiagramCanvas.vue'

const store = useDiagramStore()
const canvasRef = ref<InstanceType<typeof DiagramCanvas>>()

function screenToCanvas(pos: Point): Point {
  return canvasRef.value?.screenToCanvas?.(pos) ?? pos
}

const { handleDrop } = usePaletteDrop(screenToCanvas)

// Handle native HTML5 drag-and-drop from palette onto canvas
function onDragOver(e: DragEvent) {
  if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy'
}

function onCanvasDrop(e: DragEvent) {
  const typeId = e.dataTransfer?.getData('text/plain')
  if (!typeId) return
  const typeDef = getNodeType(typeId)
  if (!typeDef) return
  handleDrop(typeDef, { x: e.clientX, y: e.clientY })
}
</script>

<style scoped>
.designer-layout { height: 100vh; }
.canvas-wrapper {
  height: calc(100vh - 48px - 32px);
  position: relative;
}
</style>
