// ═══════════════════════════════════════════════
// src/domain/models.ts
// Pure TypeScript — zero Vue imports. Portable, testable, serializable.
// ═══════════════════════════════════════════════

// ── Primitives ──

export interface Point {
  x: number
  y: number
}

export interface Dimension {
  width: number
  height: number
}

export interface Rect {
  x: number
  y: number
  width: number
  height: number
}

// ── App Mode ──

export type AppMode = 'edit' | 'run'

// ── Viewport ──

export interface ViewportState {
  panX: number
  panY: number
  zoom: number
  minZoom: number
  maxZoom: number
}

// ── Port ──

export interface PortDefinition {
  id: string
  x: number
  y: number
  direction?: 'up' | 'down' | 'left' | 'right'
}

// ── Binding (future middleware placeholder) ──

export interface BindingConfig {
  channelId?: string
  protocol?: string
  transform?: string
  [key: string]: unknown
}

// ── Node Type (palette definition) ──

export interface NodeTypeDefinition {
  typeId: string
  label: string
  category: string
  icon?: string
  defaultDimensions: Dimension
  defaultProps: Record<string, unknown>
}

// ── Node (placed instance) ──

export interface DiagramNode {
  id: string
  typeId: string
  position: Point
  rotation: number
  label: string
  dimensions: Dimension
  props: Record<string, unknown>
  binding?: BindingConfig
  zIndex: number
}

// ── Edge (pipe/connection) ──

export interface DiagramEdge {
  id: string
  from: { nodeId: string; portId: string }
  to: { nodeId: string; portId: string }
  waypoints: Point[]
  props: {
    flowing: boolean
    direction: 'forward' | 'reverse'
    flowColor?: string
    strokeWidth?: number
    label?: string
  }
  binding?: BindingConfig
}

// ── Diagram (top-level, serializable) ──

export interface Diagram {
  schemaVersion: number
  id: string
  name: string
  description?: string
  createdAt: string
  updatedAt: string
  nodes: DiagramNode[]
  edges: DiagramEdge[]
  viewport: Pick<ViewportState, 'panX' | 'panY' | 'zoom'>
}

// ── Selection State ──

export interface SelectionState {
  selectedNodeId: string | null
  selectedEdgeId: string | null
  hoveredPortInfo: { nodeId: string; portId: string } | null
}

// ── Drawing State ──

export interface DrawingState {
  active: boolean
  fromNodeId: string
  fromPortId: string
  startPos: Point
  waypoints: Point[]
}
