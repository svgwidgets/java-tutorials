// ═══════════════════════════════════════════════
// src/domain/geometry.ts
// Pure geometry math — zero Vue imports
// ═══════════════════════════════════════════════

import type { Point, Rect } from './models'

/** Euclidean distance between two points */
export function distance(a: Point, b: Point): number {
  return Math.hypot(a.x - b.x, a.y - b.y)
}

/** Manhattan distance (sum of absolute axis deltas) */
export function manhattanDistance(a: Point, b: Point): number {
  return Math.abs(a.x - b.x) + Math.abs(a.y - b.y)
}

/** Midpoint between two points */
export function midpoint(a: Point, b: Point): Point {
  return { x: (a.x + b.x) / 2, y: (a.y + b.y) / 2 }
}

/** Snap point to a grid */
export function snapToGrid(p: Point, gridSize: number): Point {
  return {
    x: Math.round(p.x / gridSize) * gridSize,
    y: Math.round(p.y / gridSize) * gridSize,
  }
}

/** Clamp a value to [min, max] */
export function clamp(value: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, value))
}

/** Check if a point is inside a rect */
export function pointInRect(p: Point, r: Rect): boolean {
  return p.x >= r.x && p.x <= r.x + r.width && p.y >= r.y && p.y <= r.y + r.height
}

/** Check if two rects overlap */
export function rectsOverlap(a: Rect, b: Rect): boolean {
  return !(a.x + a.width < b.x || b.x + b.width < a.x || a.y + a.height < b.y || b.y + b.height < a.y)
}

/** Get bounding rect from a set of points */
export function boundingRect(points: Point[]): Rect {
  if (points.length === 0) return { x: 0, y: 0, width: 0, height: 0 }
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity
  for (const p of points) {
    if (p.x < minX) minX = p.x
    if (p.y < minY) minY = p.y
    if (p.x > maxX) maxX = p.x
    if (p.y > maxY) maxY = p.y
  }
  return { x: minX, y: minY, width: maxX - minX, height: maxY - minY }
}

/**
 * Compute orthogonal L-shaped route between two points.
 * Returns intermediate waypoints (excludes start and end).
 * Horizontal-first: goes right/left, then up/down.
 */
export function orthoRoute(from: Point, to: Point): Point[] {
  if (Math.abs(from.x - to.x) < 2) return [] // Already vertically aligned
  if (Math.abs(from.y - to.y) < 2) return [] // Already horizontally aligned
  return [{ x: to.x, y: from.y }] // L-shape: horizontal then vertical
}

/**
 * Ensure the last waypoint connects orthogonally to a target point.
 * Adds a corner waypoint if the last segment would be diagonal.
 */
export function alignToTarget(waypoints: Point[], startPos: Point, targetPos: Point): Point[] {
  const wp = [...waypoints]
  const last = wp.length > 0 ? wp[wp.length - 1] : startPos
  if (Math.abs(last.x - targetPos.x) < 2 || Math.abs(last.y - targetPos.y) < 2) return wp
  wp.push({ x: targetPos.x, y: last.y })
  return wp
}

/**
 * Snap for orthogonal drawing mode.
 * Given a raw mouse position and an anchor (previous point),
 * returns the L-shaped corner + endpoint that keeps all segments H/V.
 */
export function snapOrtho(
  raw: Point,
  anchor: Point,
  gridSize: number,
  snapEnabled: boolean,
): { corner: Point | null; point: Point } {
  const dx = Math.abs(raw.x - anchor.x)
  const dy = Math.abs(raw.y - anchor.y)

  const snap = (v: number) => (snapEnabled ? Math.round(v / gridSize) * gridSize : v)

  if (dx < 5) return { corner: null, point: { x: anchor.x, y: snap(raw.y) } }
  if (dy < 5) return { corner: null, point: { x: snap(raw.x), y: anchor.y } }

  const sx = snap(raw.x)
  const sy = snap(raw.y)
  return { corner: { x: sx, y: anchor.y }, point: { x: sx, y: sy } }
}

/**
 * Remove collinear intermediate points from a polyline.
 * Two consecutive segments going the same direction merge into one.
 */
export function simplifyPolyline(pts: Point[]): Point[] {
  if (pts.length <= 1) return pts
  const out = [pts[0]]
  for (let i = 1; i < pts.length - 1; i++) {
    const [a, b, c] = [pts[i - 1], pts[i], pts[i + 1]]
    const cross = (b.x - a.x) * (c.y - a.y) - (c.x - a.x) * (b.y - a.y)
    if (Math.abs(cross) > 2) out.push(b)
  }
  out.push(pts[pts.length - 1])
  return out
}

/**
 * Check if a node rect is visible in the current viewport.
 * Used for viewport culling on large diagrams.
 */
export function isVisibleInViewport(
  nodeRect: Rect,
  viewportRect: Rect,
  margin = 100,
): boolean {
  const expanded: Rect = {
    x: viewportRect.x - margin,
    y: viewportRect.y - margin,
    width: viewportRect.width + margin * 2,
    height: viewportRect.height + margin * 2,
  }
  return rectsOverlap(nodeRect, expanded)
}
