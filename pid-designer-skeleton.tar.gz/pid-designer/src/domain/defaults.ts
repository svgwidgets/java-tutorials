// ═══════════════════════════════════════════════
// src/domain/defaults.ts
// Factory functions — create domain objects with sensible defaults
// ═══════════════════════════════════════════════

import { uid } from '@/utils/uid'
import type {
  DiagramNode,
  DiagramEdge,
  Diagram,
  NodeTypeDefinition,
  Point,
  ViewportState,
} from './models'

// ── Node Type Definitions (Palette Registry) ──

export const NODE_TYPES: NodeTypeDefinition[] = [
  {
    typeId: 'manual-valve',
    label: 'Manual Valve',
    category: 'Valves',
    icon: '◇',
    defaultDimensions: { width: 40, height: 24 },
    defaultProps: { state: 'closed', alarm: 'none' },
  },
  {
    typeId: 'centrifugal-pump',
    label: 'Centrifugal Pump',
    category: 'Pumps',
    icon: '⊙',
    defaultDimensions: { width: 48, height: 40 },
    defaultProps: { state: 'stopped', alarm: 'none' },
  },
  {
    typeId: 'vertical-tank',
    label: 'Vertical Tank',
    category: 'Tanks',
    icon: '▯',
    defaultDimensions: { width: 100, height: 180 },
    defaultProps: { level: 50, alarm: 'none' },
  },
  {
    typeId: 'pressure-sensor',
    label: 'Pressure Sensor',
    category: 'Sensors',
    icon: '◎',
    defaultDimensions: { width: 48, height: 40 },
    defaultProps: { value: 0, units: 'PSI', alarm: 'none', tag: 'PT' },
  },
  {
    typeId: 'temperature-sensor',
    label: 'Temperature Sensor',
    category: 'Sensors',
    icon: '◎',
    defaultDimensions: { width: 48, height: 40 },
    defaultProps: { value: 0, units: '°C', alarm: 'none', tag: 'TT' },
  },
  {
    typeId: 'junction',
    label: 'Junction',
    category: 'Connectors',
    icon: '●',
    defaultDimensions: { width: 24, height: 24 },
    defaultProps: {},
  },
]

export function getNodeType(typeId: string): NodeTypeDefinition | undefined {
  return NODE_TYPES.find(t => t.typeId === typeId)
}

export function getNodeTypesByCategory(): Record<string, NodeTypeDefinition[]> {
  const map: Record<string, NodeTypeDefinition[]> = {}
  for (const t of NODE_TYPES) {
    if (!map[t.category]) map[t.category] = []
    map[t.category].push(t)
  }
  return map
}

// ── Label Generation ──

const labelCounters: Record<string, number> = {}

const TYPE_PREFIXES: Record<string, string> = {
  'manual-valve': 'V',
  'centrifugal-pump': 'P',
  'vertical-tank': 'T',
  'pressure-sensor': 'PT',
  'temperature-sensor': 'TT',
  'junction': 'J',
}

export function generateLabel(typeId: string): string {
  const prefix = TYPE_PREFIXES[typeId] || 'X'
  labelCounters[typeId] = (labelCounters[typeId] || 0) + 1
  return `${prefix}-${String(labelCounters[typeId]).padStart(3, '0')}`
}

export function resetLabelCounters() {
  Object.keys(labelCounters).forEach(k => delete labelCounters[k])
}

// ── Factory: Node ──

export function createNode(
  typeId: string,
  position: Point,
  overrides?: Partial<DiagramNode>,
): DiagramNode {
  const typeDef = getNodeType(typeId)
  if (!typeDef) throw new Error(`Unknown node type: ${typeId}`)

  return {
    id: uid(),
    typeId,
    position: { ...position },
    rotation: 0,
    label: generateLabel(typeId),
    dimensions: { ...typeDef.defaultDimensions },
    props: { ...typeDef.defaultProps },
    zIndex: 0,
    ...overrides,
  }
}

// ── Factory: Edge ──

export function createEdge(
  fromNodeId: string,
  fromPortId: string,
  toNodeId: string,
  toPortId: string,
  waypoints: Point[] = [],
  overrides?: Partial<DiagramEdge>,
): DiagramEdge {
  return {
    id: uid(),
    from: { nodeId: fromNodeId, portId: fromPortId },
    to: { nodeId: toNodeId, portId: toPortId },
    waypoints: waypoints.map(w => ({ ...w })),
    props: {
      flowing: false,
      direction: 'forward',
    },
    ...overrides,
  }
}

// ── Factory: Diagram ──

export function createDiagram(name = 'Untitled Diagram'): Diagram {
  return {
    schemaVersion: 1,
    id: uid(),
    name,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    nodes: [],
    edges: [],
    viewport: { panX: 0, panY: 0, zoom: 1 },
  }
}

// ── Factory: Default Viewport ──

export function createDefaultViewport(): ViewportState {
  return {
    panX: 0,
    panY: 0,
    zoom: 1,
    minZoom: 0.1,
    maxZoom: 5,
  }
}
