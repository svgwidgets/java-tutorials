// ═══════════════════════════════════════════════
// src/domain/schema.ts
// JSON schema validation for import/export
// ═══════════════════════════════════════════════

import type { Diagram } from './models'

export const CURRENT_SCHEMA_VERSION = 1

export interface ValidationResult {
  valid: boolean
  error?: string
}

/**
 * Validate a parsed JSON object against the diagram schema.
 * Does NOT throw — returns a result object.
 */
export function validateDiagram(data: unknown): ValidationResult {
  if (!data || typeof data !== 'object') {
    return { valid: false, error: 'File does not contain a JSON object' }
  }

  const d = data as Record<string, unknown>

  // Schema version
  if (typeof d.schemaVersion !== 'number') {
    return { valid: false, error: 'Missing schemaVersion field' }
  }
  if (d.schemaVersion > CURRENT_SCHEMA_VERSION) {
    return {
      valid: false,
      error: `Schema version ${d.schemaVersion} is newer than supported (${CURRENT_SCHEMA_VERSION}). Update the app.`,
    }
  }
  if (d.schemaVersion < 1) {
    return { valid: false, error: `Schema version ${d.schemaVersion} is too old` }
  }

  // Nodes
  if (!Array.isArray(d.nodes)) {
    return { valid: false, error: 'Missing or invalid nodes array' }
  }
  for (let i = 0; i < d.nodes.length; i++) {
    const n = d.nodes[i] as Record<string, unknown>
    if (!n.id || typeof n.id !== 'string') {
      return { valid: false, error: `Node at index ${i} has invalid id` }
    }
    if (!n.typeId || typeof n.typeId !== 'string') {
      return { valid: false, error: `Node "${n.id}" has invalid typeId` }
    }
    if (!n.position || typeof (n.position as any).x !== 'number') {
      return { valid: false, error: `Node "${n.id}" has invalid position` }
    }
  }

  // Edges
  if (!Array.isArray(d.edges)) {
    return { valid: false, error: 'Missing or invalid edges array' }
  }
  for (let i = 0; i < d.edges.length; i++) {
    const e = d.edges[i] as Record<string, unknown>
    if (!e.id || typeof e.id !== 'string') {
      return { valid: false, error: `Edge at index ${i} has invalid id` }
    }
    const from = e.from as Record<string, unknown> | undefined
    const to = e.to as Record<string, unknown> | undefined
    if (!from?.nodeId || !from?.portId) {
      return { valid: false, error: `Edge "${e.id}" has invalid from` }
    }
    if (!to?.nodeId || !to?.portId) {
      return { valid: false, error: `Edge "${e.id}" has invalid to` }
    }

    // Verify referenced nodes exist
    const nodeIds = new Set((d.nodes as any[]).map((n: any) => n.id))
    if (!nodeIds.has(from.nodeId)) {
      return { valid: false, error: `Edge "${e.id}" references non-existent from node "${from.nodeId}"` }
    }
    if (!nodeIds.has(to.nodeId)) {
      return { valid: false, error: `Edge "${e.id}" references non-existent to node "${to.nodeId}"` }
    }
  }

  // Viewport (optional but should be valid if present)
  if (d.viewport) {
    const v = d.viewport as Record<string, unknown>
    if (typeof v.zoom !== 'number' || v.zoom <= 0) {
      return { valid: false, error: 'Invalid viewport zoom value' }
    }
  }

  return { valid: true }
}

/**
 * Migrate older schema versions to current.
 * Currently a no-op since we're at v1.
 * Add migration logic here when schemaVersion bumps.
 */
export function migrateDiagram(data: Diagram): Diagram {
  // v1 → v1: no migration needed
  return data
}
