import { createRouter, createWebHistory } from 'vue-router'

export default createRouter({
  history: createWebHistory(),
  routes: [
    { path: '/', redirect: '/designer' },
    {
      path: '/designer',
      name: 'designer',
      component: () => import('@/pages/DesignerPage.vue'),
    },
    {
      path: '/examples',
      name: 'examples',
      component: () => import('@/pages/ExamplesPage.vue'),
    },
  ],
})
