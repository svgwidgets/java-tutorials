// ═══════════════════════════════════════════════
// src/stores/useDiagramStore.ts
// Single Pinia store — all diagram state lives here
// ═══════════════════════════════════════════════

import { defineStore } from 'pinia'
import { ref, reactive, computed } from 'vue'
import type {
  AppMode, DiagramNode, DiagramEdge, ViewportState,
  SelectionState, DrawingState, Point, Diagram,
} from '@/domain/models'
import { uid } from '@/utils/uid'

export const useDiagramStore = defineStore('diagram', () => {

  // ── State ──

  const mode = ref<AppMode>('edit')
  const diagramName = ref('Untitled Diagram')
  const nodes = reactive<DiagramNode[]>([])
  const edges = reactive<DiagramEdge[]>([])

  const viewport = reactive<ViewportState>({
    panX: 0, panY: 0, zoom: 1, minZoom: 0.1, maxZoom: 5,
  })

  const selection = reactive<SelectionState>({
    selectedNodeId: null,
    selectedEdgeId: null,
    hoveredPortInfo: null,
  })

  const drawing = reactive<DrawingState>({
    active: false,
    fromNodeId: '',
    fromPortId: '',
    startPos: { x: 0, y: 0 },
    waypoints: [],
  })

  // ── Getters ──

  const isEditMode = computed(() => mode.value === 'edit')
  const isRunMode = computed(() => mode.value === 'run')
  const selectedNode = computed(() => nodes.find(n => n.id === selection.selectedNodeId))
  const selectedEdge = computed(() => edges.find(e => e.id === selection.selectedEdgeId))

  function getNode(id: string) { return nodes.find(n => n.id === id) }

  function getEdgesForNode(nodeId: string) {
    return edges.filter(e => e.from.nodeId === nodeId || e.to.nodeId === nodeId)
  }

  // ── Mode ──

  function setMode(m: AppMode) {
    mode.value = m
    if (m === 'run') { clearSelection(); cancelDrawing() }
  }

  function toggleMode() { setMode(mode.value === 'edit' ? 'run' : 'edit') }

  // ── Viewport ──

  function pan(dx: number, dy: number) {
    viewport.panX += dx
    viewport.panY += dy
  }

  function zoomTo(newZoom: number, focalPoint?: Point) {
    const clamped = Math.max(viewport.minZoom, Math.min(viewport.maxZoom, newZoom))
    if (focalPoint) {
      const ratio = clamped / viewport.zoom
      viewport.panX = focalPoint.x - ratio * (focalPoint.x - viewport.panX)
      viewport.panY = focalPoint.y - ratio * (focalPoint.y - viewport.panY)
    }
    viewport.zoom = clamped
  }

  function zoomIn() { zoomTo(viewport.zoom * 1.2) }
  function zoomOut() { zoomTo(viewport.zoom / 1.2) }
  function resetViewport() { viewport.panX = 0; viewport.panY = 0; viewport.zoom = 1 }

  // ── Selection ──

  function selectNode(id: string | null) {
    selection.selectedNodeId = id
    selection.selectedEdgeId = null
  }

  function selectEdge(id: string | null) {
    selection.selectedEdgeId = id
    selection.selectedNodeId = null
  }

  function clearSelection() {
    selection.selectedNodeId = null
    selection.selectedEdgeId = null
    selection.hoveredPortInfo = null
  }

  // ── Nodes ──

  function addNode(node: DiagramNode) {
    nodes.push(node)
  }

  function moveNode(nodeId: string, position: Point) {
    const node = getNode(nodeId)
    if (node) { node.position.x = position.x; node.position.y = position.y }
  }

  function removeNode(nodeId: string) {
    const connected = getEdgesForNode(nodeId)
    connected.forEach(e => removeEdge(e.id))
    const idx = nodes.findIndex(n => n.id === nodeId)
    if (idx >= 0) nodes.splice(idx, 1)
    if (selection.selectedNodeId === nodeId) selection.selectedNodeId = null
  }

  function updateNodeProps(nodeId: string, props: Record<string, unknown>) {
    const node = getNode(nodeId)
    if (node) Object.assign(node.props, props)
  }

  // ── Edges ──

  function addEdge(edge: DiagramEdge) { edges.push(edge) }

  function updateEdgeWaypoints(edgeId: string, waypoints: Point[]) {
    const edge = edges.find(e => e.id === edgeId)
    if (edge) edge.waypoints = waypoints
  }

  function removeEdge(edgeId: string) {
    const idx = edges.findIndex(e => e.id === edgeId)
    if (idx >= 0) edges.splice(idx, 1)
    if (selection.selectedEdgeId === edgeId) selection.selectedEdgeId = null
  }

  // ── Drawing ──

  function startDrawing(nodeId: string, portId: string, startPos: Point) {
    drawing.active = true
    drawing.fromNodeId = nodeId
    drawing.fromPortId = portId
    drawing.startPos = { ...startPos }
    drawing.waypoints = []
  }

  function addDrawingWaypoint(point: Point) {
    drawing.waypoints.push({ ...point })
  }

  function cancelDrawing() {
    drawing.active = false
    drawing.fromNodeId = ''
    drawing.fromPortId = ''
    drawing.waypoints = []
  }

  // ── Serialization ──

  function toDiagram(): Diagram {
    return {
      schemaVersion: 1,
      id: uid(),
      name: diagramName.value,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      nodes: nodes.map(n => structuredClone(n)),
      edges: edges.map(e => structuredClone(e)),
      viewport: { panX: viewport.panX, panY: viewport.panY, zoom: viewport.zoom },
    }
  }

  function loadDiagram(diagram: Diagram) {
    nodes.splice(0, nodes.length, ...diagram.nodes)
    edges.splice(0, edges.length, ...diagram.edges)
    diagramName.value = diagram.name || 'Untitled'
    if (diagram.viewport) {
      viewport.panX = diagram.viewport.panX
      viewport.panY = diagram.viewport.panY
      viewport.zoom = diagram.viewport.zoom
    }
    clearSelection()
    cancelDrawing()
  }

  function clearDiagram() {
    nodes.splice(0); edges.splice(0)
    diagramName.value = 'Untitled Diagram'
    clearSelection(); cancelDrawing(); resetViewport()
  }

  return {
    mode, diagramName, nodes, edges, viewport, selection, drawing,
    isEditMode, isRunMode, selectedNode, selectedEdge,
    getNode, getEdgesForNode,
    setMode, toggleMode,
    pan, zoomTo, zoomIn, zoomOut, resetViewport,
    selectNode, selectEdge, clearSelection,
    addNode, moveNode, removeNode, updateNodeProps,
    addEdge, updateEdgeWaypoints, removeEdge,
    startDrawing, addDrawingWaypoint, cancelDrawing,
    toDiagram, loadDiagram, clearDiagram,
  }
})
