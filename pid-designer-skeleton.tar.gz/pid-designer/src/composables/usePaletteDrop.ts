import { useDiagramStore } from '@/stores/useDiagramStore'
import { createNode } from '@/domain/defaults'
import type { NodeTypeDefinition, Point } from '@/domain/models'

export function usePaletteDrop(screenToCanvas: (screen: Point) => Point) {
  const store = useDiagramStore()

  function handleDrop(typeDef: NodeTypeDefinition, screenPos: Point) {
    if (!store.isEditMode) return

    const canvasPos = screenToCanvas(screenPos)
    const position = {
      x: canvasPos.x - typeDef.defaultDimensions.width / 2,
      y: canvasPos.y - typeDef.defaultDimensions.height / 2,
    }

    const node = createNode(typeDef.typeId, position)
    node.zIndex = store.nodes.length
    store.addNode(node)
    store.selectNode(node.id)
  }

  return { handleDrop }
}
