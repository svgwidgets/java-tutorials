import { useDiagramStore } from '@/stores/useDiagramStore'
import { validateDiagram, migrateDiagram } from '@/domain/schema'
import type { Diagram } from '@/domain/models'

export function useSerializer() {
  const store = useDiagramStore()

  function exportDiagram() {
    const diagram = store.toDiagram()
    const json = JSON.stringify(diagram, null, 2)
    const blob = new Blob([json], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `${diagram.name.replace(/\s+/g, '_')}.json`
    a.click()
    URL.revokeObjectURL(url)
  }

  function importDiagram(): Promise<{ success: boolean; error?: string }> {
    return new Promise(resolve => {
      const input = document.createElement('input')
      input.type = 'file'
      input.accept = '.json'

      input.onchange = async () => {
        const file = input.files?.[0]
        if (!file) { resolve({ success: false, error: 'No file selected' }); return }

        try {
          const text = await file.text()
          const data = JSON.parse(text)
          const result = validateDiagram(data)
          if (!result.valid) { resolve({ success: false, error: result.error }); return }

          const migrated = migrateDiagram(data as Diagram)
          store.loadDiagram(migrated)
          resolve({ success: true })
        } catch {
          resolve({ success: false, error: 'Invalid JSON file' })
        }
      }

      input.click()
    })
  }

  return { exportDiagram, importDiagram }
}
