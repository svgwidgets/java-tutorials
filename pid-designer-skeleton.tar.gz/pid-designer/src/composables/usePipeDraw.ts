import { ref } from 'vue'
import { useDiagramStore } from '@/stores/useDiagramStore'
import { useOrthoRouter } from './useOrthoRouter'
import { alignToTarget, simplifyPolyline, snapOrtho } from '@/domain/geometry'
import { uid } from '@/utils/uid'
import type { Point } from '@/domain/models'

export function usePipeDraw(screenToCanvas: (screen: Point) => Point) {
  const store = useDiagramStore()
  const router = useOrthoRouter()
  const canvasMousePos = ref<Point>({ x: 0, y: 0 })
  const drawingMode = ref<'ortho' | 'click'>('ortho')

  function onPortClick(nodeId: string, portId: string) {
    if (!store.isEditMode) return

    if (!store.drawing.active) {
      const portWorld = router.getPortWorldPos(nodeId, portId)
      store.startDrawing(nodeId, portId, portWorld)
      return
    }

    // Finish — clicked target port
    if (nodeId === store.drawing.fromNodeId && portId === store.drawing.fromPortId) return

    const fromPos = store.drawing.startPos
    const toPos = router.getPortWorldPos(nodeId, portId)

    let waypoints = [...store.drawing.waypoints]
    if (drawingMode.value === 'ortho') {
      waypoints = alignToTarget(waypoints, fromPos, toPos)
    }

    store.addEdge({
      id: uid(),
      from: { nodeId: store.drawing.fromNodeId, portId: store.drawing.fromPortId },
      to: { nodeId, portId },
      waypoints: simplifyPolyline(waypoints),
      props: { flowing: false, direction: 'forward' },
    })

    store.cancelDrawing()
  }

  function onCanvasClick(raw: Point, gridSize: number, snapEnabled: boolean) {
    if (!store.drawing.active) {
      store.clearSelection()
      return
    }

    const anchor = store.drawing.waypoints.length > 0
      ? store.drawing.waypoints[store.drawing.waypoints.length - 1]
      : store.drawing.startPos

    if (drawingMode.value === 'ortho') {
      const { corner, point } = snapOrtho(raw, anchor, gridSize, snapEnabled)
      if (corner) store.addDrawingWaypoint(corner)
      store.addDrawingWaypoint(point)
    } else {
      store.addDrawingWaypoint(raw)
    }
  }

  function onPortEnter(nodeId: string, portId: string) {
    store.selection.hoveredPortInfo = { nodeId, portId }
  }

  function onPortLeave() {
    store.selection.hoveredPortInfo = null
  }

  return { onPortClick, onCanvasClick, onPortEnter, onPortLeave, drawingMode, canvasMousePos }
}
