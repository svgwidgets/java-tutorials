import { ref, computed, onMounted, onUnmounted, type Ref } from 'vue'
import { useDiagramStore } from '@/stores/useDiagramStore'
import type { Point } from '@/domain/models'

export function useCanvas(
  containerRef: Ref<HTMLDivElement | undefined>,
  svgRef: Ref<SVGSVGElement | undefined>,
) {
  const store = useDiagramStore()
  const containerSize = ref({ width: 1920, height: 1080 })
  const gridSize = ref(10)

  const canvasTransform = computed(() =>
    `translate(${store.viewport.panX}, ${store.viewport.panY}) scale(${store.viewport.zoom})`
  )

  function screenToCanvas(screen: Point): Point {
    if (!containerRef.value) return screen
    const rect = containerRef.value.getBoundingClientRect()
    return {
      x: (screen.x - rect.left - store.viewport.panX) / store.viewport.zoom,
      y: (screen.y - rect.top - store.viewport.panY) / store.viewport.zoom,
    }
  }

  function canvasToScreen(canvas: Point): Point {
    if (!containerRef.value) return canvas
    const rect = containerRef.value.getBoundingClientRect()
    return {
      x: canvas.x * store.viewport.zoom + store.viewport.panX + rect.left,
      y: canvas.y * store.viewport.zoom + store.viewport.panY + rect.top,
    }
  }

  function onWheel(e: WheelEvent) {
    const delta = e.deltaY > 0 ? 0.9 : 1.1
    const newZoom = store.viewport.zoom * delta
    store.zoomTo(newZoom, { x: e.clientX, y: e.clientY })
  }

  let resizeObserver: ResizeObserver | null = null

  onMounted(() => {
    if (containerRef.value) {
      const rect = containerRef.value.getBoundingClientRect()
      containerSize.value = { width: rect.width, height: rect.height }
      resizeObserver = new ResizeObserver(entries => {
        for (const entry of entries) {
          containerSize.value = {
            width: entry.contentRect.width,
            height: entry.contentRect.height,
          }
        }
      })
      resizeObserver.observe(containerRef.value)
    }
  })

  onUnmounted(() => resizeObserver?.disconnect())

  return { containerSize, canvasTransform, screenToCanvas, canvasToScreen, onWheel, gridSize }
}
