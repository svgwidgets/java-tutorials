import { ref } from 'vue'
import { useDiagramStore } from '@/stores/useDiagramStore'
import { useOrthoRouter } from './useOrthoRouter'
import type { Point } from '@/domain/models'

export function useNodeDrag(screenToCanvas: (screen: Point) => Point) {
  const store = useDiagramStore()
  const router = useOrthoRouter()
  const dragging = ref(false)
  const dragNodeId = ref('')
  const dragOffset = ref<Point>({ x: 0, y: 0 })

  function onNodeMouseDown(nodeId: string, e: MouseEvent) {
    if (!store.isEditMode || e.button !== 0) return
    const node = store.getNode(nodeId)
    if (!node) return

    store.selectNode(nodeId)
    dragging.value = true
    dragNodeId.value = nodeId

    const canvasPos = screenToCanvas({ x: e.clientX, y: e.clientY })
    dragOffset.value = {
      x: canvasPos.x - node.position.x,
      y: canvasPos.y - node.position.y,
    }

    const onMove = (me: MouseEvent) => {
      if (!dragging.value) return
      const pos = screenToCanvas({ x: me.clientX, y: me.clientY })
      store.moveNode(dragNodeId.value, {
        x: pos.x - dragOffset.value.x,
        y: pos.y - dragOffset.value.y,
      })
    }

    const onUp = () => {
      dragging.value = false
      // Recompute routes for connected edges ONCE on drop
      router.recomputeEdgesForNode(dragNodeId.value)
      window.removeEventListener('mousemove', onMove)
      window.removeEventListener('mouseup', onUp)
    }

    window.addEventListener('mousemove', onMove)
    window.addEventListener('mouseup', onUp)
    e.preventDefault()
    e.stopPropagation()
  }

  return { onNodeMouseDown, dragging }
}
