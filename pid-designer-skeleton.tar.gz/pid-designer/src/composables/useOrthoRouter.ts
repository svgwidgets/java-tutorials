import { useDiagramStore } from '@/stores/useDiagramStore'
import { orthoRoute } from '@/domain/geometry'
import type { Point, PortDefinition } from '@/domain/models'

/**
 * Wraps orthogonal routing + port position lookup.
 * Reads port positions from component refs (single source of truth).
 */
export function useOrthoRouter() {
  const store = useDiagramStore()

  // Component refs keyed by node id — set by NodeRenderer
  const compRefs: Record<string, any> = {}

  function registerCompRef(nodeId: string, el: any) {
    if (el) compRefs[nodeId] = el
    else delete compRefs[nodeId]
  }

  function getExposedPorts(nodeId: string): PortDefinition[] {
    const comp = compRefs[nodeId]
    if (!comp) return []
    const ports = comp.ports
    return Array.isArray(ports) ? ports : (ports?.value ?? [])
  }

  function getPortWorldPos(nodeId: string, portId: string): Point {
    const node = store.getNode(nodeId)
    if (!node) return { x: 0, y: 0 }
    const ports = getExposedPorts(nodeId)
    const port = ports.find((p: PortDefinition) => p.id === portId)
    if (!port) return node.position
    return { x: node.position.x + port.x, y: node.position.y + port.y }
  }

  /**
   * Recompute waypoints for all edges connected to a node.
   * Called ONCE after drag ends.
   */
  function recomputeEdgesForNode(nodeId: string) {
    const affected = store.getEdgesForNode(nodeId)
    for (const edge of affected) {
      const fromPos = getPortWorldPos(edge.from.nodeId, edge.from.portId)
      const toPos = getPortWorldPos(edge.to.nodeId, edge.to.portId)
      const waypoints = orthoRoute(fromPos, toPos)
      store.updateEdgeWaypoints(edge.id, waypoints)
    }
  }

  return { registerCompRef, getExposedPorts, getPortWorldPos, recomputeEdgesForNode }
}
