<template>
  <v-footer app height="32" color="surface" class="status-bar" :border="true">
    <span class="status-item">
      <v-icon size="12" class="mr-1">mdi-vector-point</v-icon>
      {{ store.nodes.length }} nodes
    </span>
    <v-divider vertical class="mx-2" />
    <span class="status-item">
      <v-icon size="12" class="mr-1">mdi-vector-polyline</v-icon>
      {{ store.edges.length }} edges
    </span>
    <v-divider vertical class="mx-2" />
    <span class="status-item">
      Mode: <strong>{{ store.mode.toUpperCase() }}</strong>
    </span>
    <v-divider vertical class="mx-2" />
    <span class="status-item">
      Zoom: {{ Math.round(store.viewport.zoom * 100) }}%
    </span>
    <v-spacer />
    <span class="status-item">
      Pan: {{ Math.round(store.viewport.panX) }}, {{ Math.round(store.viewport.panY) }}
    </span>
  </v-footer>
</template>

<script setup lang="ts">
import { useDiagramStore } from '@/stores/useDiagramStore'
const store = useDiagramStore()
</script>

<style scoped>
.status-bar {
  font-size: 11px; color: rgba(255,255,255,0.4);
  display: flex; align-items: center; padding: 0 12px;
}
.status-item { display: flex; align-items: center; gap: 2px; }
.status-item strong { color: rgba(255,255,255,0.7); margin-left: 4px; }
</style>
