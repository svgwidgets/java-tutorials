<template>
  <v-app-bar density="compact" color="surface" elevation="0" class="toolbar" :border="true">
    <div class="toolbar-left">
      <v-icon size="20" color="primary" class="mr-2">mdi-vector-polyline</v-icon>
      <span class="toolbar-title">P&amp;ID Designer</span>
      <v-divider vertical class="mx-3" />
      <span class="diagram-name">{{ store.diagramName }}</span>
    </div>

    <v-spacer />

    <!-- Mode toggle -->
    <v-btn-toggle v-model="currentMode" mandatory density="compact" color="primary" class="mr-3">
      <v-btn value="edit" size="small" variant="text">
        <v-icon start size="16">mdi-pencil</v-icon> Edit
      </v-btn>
      <v-btn value="run" size="small" variant="text">
        <v-icon start size="16">mdi-play</v-icon> Run
      </v-btn>
    </v-btn-toggle>

    <v-divider vertical class="mx-2" />

    <!-- Zoom controls -->
    <v-btn icon size="small" variant="text" @click="store.zoomOut()" title="Zoom Out">
      <v-icon size="18">mdi-magnify-minus</v-icon>
    </v-btn>
    <span class="zoom-label">{{ zoomPercent }}%</span>
    <v-btn icon size="small" variant="text" @click="store.zoomIn()" title="Zoom In">
      <v-icon size="18">mdi-magnify-plus</v-icon>
    </v-btn>
    <v-btn icon size="small" variant="text" @click="store.resetViewport()" title="Reset View">
      <v-icon size="18">mdi-fit-to-screen</v-icon>
    </v-btn>

    <v-divider vertical class="mx-2" />

    <!-- Import / Export -->
    <v-btn size="small" variant="text" @click="onImport">
      <v-icon start size="16">mdi-upload</v-icon> Import
    </v-btn>
    <v-btn size="small" variant="text" @click="serializer.exportDiagram()">
      <v-icon start size="16">mdi-download</v-icon> Export
    </v-btn>

    <v-divider vertical class="mx-2" />

    <!-- Clear -->
    <v-btn icon size="small" variant="text" color="error" @click="store.clearDiagram()" title="Clear All">
      <v-icon size="18">mdi-delete-outline</v-icon>
    </v-btn>
  </v-app-bar>

  <!-- Import error snackbar -->
  <v-snackbar v-model="showError" color="error" :timeout="4000">
    {{ errorMessage }}
  </v-snackbar>
</template>

<script setup lang="ts">
import { computed, ref, watch } from 'vue'
import { useDiagramStore } from '@/stores/useDiagramStore'
import { useSerializer } from '@/composables/useSerializer'
import type { AppMode } from '@/domain/models'

const store = useDiagramStore()
const serializer = useSerializer()
const showError = ref(false)
const errorMessage = ref('')

const currentMode = computed({
  get: () => store.mode,
  set: (v: AppMode) => store.setMode(v),
})

const zoomPercent = computed(() => Math.round(store.viewport.zoom * 100))

async function onImport() {
  const result = await serializer.importDiagram()
  if (!result.success) {
    errorMessage.value = result.error || 'Import failed'
    showError.value = true
  }
}
</script>

<style scoped>
.toolbar { font-size: 13px; }
.toolbar-left { display: flex; align-items: center; padding-left: 12px; }
.toolbar-title { font-weight: 600; font-size: 14px; }
.diagram-name { font-size: 12px; color: rgba(255,255,255,0.5); }
.zoom-label { font-size: 11px; font-family: monospace; color: rgba(255,255,255,0.5); min-width: 40px; text-align: center; }
</style>
