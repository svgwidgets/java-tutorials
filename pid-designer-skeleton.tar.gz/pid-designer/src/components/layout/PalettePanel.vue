<template>
  <div class="palette-panel">
    <div class="palette-header">
      <v-icon size="16" class="mr-2">mdi-puzzle</v-icon>
      Components
    </div>

    <div v-for="(types, category) in categorized" :key="category" class="palette-category">
      <div class="category-title">{{ category }}</div>
      <div class="palette-grid">
        <PaletteItem
          v-for="typeDef in types" :key="typeDef.typeId"
          :type-def="typeDef"
          @drop="(pos: DragEndPos) => onDrop(typeDef, pos)"
        />
      </div>
    </div>

    <v-divider class="my-3" />

    <div class="palette-help">
      <strong>Drag</strong> a component onto the canvas to place it.
      <br /><strong>Click a port</strong> to start drawing a pipe.
      <br /><strong>Shift+drag</strong> or <strong>middle-click</strong> to pan.
      <br /><strong>Scroll</strong> to zoom.
      <br /><strong>Delete</strong> to remove selected.
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { getNodeTypesByCategory } from '@/domain/defaults'
import { usePaletteDrop } from '@/composables/usePaletteDrop'
import type { NodeTypeDefinition, Point } from '@/domain/models'
import PaletteItem from '../palette/PaletteItem.vue'

interface DragEndPos { x: number; y: number }

const props = defineProps<{
  screenToCanvas: (pos: Point) => Point
}>()

const categorized = computed(() => getNodeTypesByCategory())

const { handleDrop } = usePaletteDrop(props.screenToCanvas)

function onDrop(typeDef: NodeTypeDefinition, pos: DragEndPos) {
  handleDrop(typeDef, pos)
}
</script>

<style scoped>
.palette-panel { padding: 12px; height: 100%; overflow-y: auto; }
.palette-header {
  display: flex; align-items: center; font-size: 13px;
  font-weight: 600; margin-bottom: 12px;
}
.palette-category { margin-bottom: 16px; }
.category-title {
  font-size: 10px; font-weight: 600; text-transform: uppercase;
  letter-spacing: 0.08em; color: rgba(255,255,255,0.35); margin-bottom: 6px;
}
.palette-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.palette-help {
  font-size: 11px; color: rgba(255,255,255,0.3);
  line-height: 1.7; padding: 8px;
  background: rgba(255,255,255,0.02); border-radius: 6px;
}
.palette-help strong { color: rgba(255,255,255,0.5); }
</style>
