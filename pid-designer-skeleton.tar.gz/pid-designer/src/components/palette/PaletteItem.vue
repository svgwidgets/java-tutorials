<template>
  <div
    class="palette-item"
    draggable="true"
    @dragstart="onDragStart"
    @dragend="onDragEnd"
    :title="typeDef.label"
  >
    <span class="item-icon">{{ typeDef.icon || '▪' }}</span>
    <span class="item-label">{{ typeDef.label }}</span>
  </div>
</template>

<script setup lang="ts">
import type { NodeTypeDefinition } from '@/domain/models'

interface Props {
  typeDef: NodeTypeDefinition
}

const props = defineProps<Props>()
const emit = defineEmits<{ drop: [pos: { x: number; y: number }] }>()

function onDragStart(e: DragEvent) {
  if (!e.dataTransfer) return
  e.dataTransfer.setData('text/plain', props.typeDef.typeId)
  e.dataTransfer.effectAllowed = 'copy'
}

function onDragEnd(e: DragEvent) {
  // If dropped on the canvas area (not cancelled), emit position
  if (e.dataTransfer?.dropEffect !== 'none') {
    emit('drop', { x: e.clientX, y: e.clientY })
  }
}
</script>

<style scoped>
.palette-item {
  display: flex; flex-direction: column; align-items: center; gap: 4px;
  padding: 10px 4px 8px; cursor: grab;
  background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.06);
  border-radius: 6px; transition: all 0.15s;
}
.palette-item:hover {
  border-color: rgba(88,166,255,0.4);
  background: rgba(88,166,255,0.05);
  transform: translateY(-1px);
}
.palette-item:active { cursor: grabbing; }
.item-icon { font-size: 18px; line-height: 1; }
.item-label { font-size: 10px; color: rgba(255,255,255,0.5); font-weight: 500; white-space: nowrap; }
</style>
