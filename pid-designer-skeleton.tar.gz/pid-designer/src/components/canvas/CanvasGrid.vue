<template>
  <!--
    SVG <defs> content — must be placed inside a parent <defs>.
    Two nested patterns: fine grid + coarse grid.
  -->
  <pattern id="canvas-grid-fine" :width="gridSize" :height="gridSize" patternUnits="userSpaceOnUse">
    <path
      :d="`M ${gridSize} 0 L 0 0 0 ${gridSize}`"
      fill="none"
      stroke="rgba(255,255,255,0.03)"
      stroke-width="0.5"
    />
  </pattern>
  <pattern id="canvas-grid" :width="gridSize * 5" :height="gridSize * 5" patternUnits="userSpaceOnUse">
    <rect :width="gridSize * 5" :height="gridSize * 5" fill="url(#canvas-grid-fine)" />
    <path
      :d="`M ${gridSize * 5} 0 L 0 0 0 ${gridSize * 5}`"
      fill="none"
      stroke="rgba(255,255,255,0.06)"
      stroke-width="0.5"
    />
  </pattern>
</template>

<script setup lang="ts">
interface Props {
  gridSize: number
  zoom: number
}
defineProps<Props>()
</script>
