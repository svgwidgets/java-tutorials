<template>
  <g class="junction-node">
    <circle
      :cx="radius" :cy="radius" :r="radius"
      fill="#1c2129" stroke="#58a6ff" stroke-width="1.5"
      vector-effect="non-scaling-stroke"
    />
    <circle
      :cx="radius" :cy="radius" :r="radius * 0.3"
      fill="#58a6ff" opacity="0.3"
    />

    <!-- 8 ports via your library's PortIndicator -->
    <PortIndicator
      :ports="ports"
      :show="showPorts"
      :highlighted-port-id="highlightedPortId"
      @port-click="handlePortClick"
      @port-mouse-enter="handlePortMouseEnter"
      @port-mouse-leave="handlePortMouseLeave"
    />
  </g>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { PortIndicator } from '@/lib/components/common'
import { usePortEvents } from '@/lib/composables/usePortEvents'

interface Props {
  showPorts?: boolean
  highlightedPortId?: string
  radius?: number
}

const props = withDefaults(defineProps<Props>(), {
  showPorts: false,
  radius: 12,
})

const emit = defineEmits(['port-click', 'port-mouse-enter', 'port-mouse-leave'])

// 8 ports evenly spaced: N, NE, E, SE, S, SW, W, NW
const ports = computed(() => {
  const r = props.radius
  const cx = r, cy = r
  const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW']
  const angles = [270, 315, 0, 45, 90, 135, 180, 225]
  return dirs.map((id, i) => {
    const rad = (angles[i] * Math.PI) / 180
    return { id, x: cx + r * Math.cos(rad), y: cy + r * Math.sin(rad) }
  })
})

const { handlePortClick, handlePortMouseEnter, handlePortMouseLeave } = usePortEvents(emit)

defineExpose({ ports })
</script>
