<template>
  <div
    ref="containerRef"
    class="canvas-container"
    @wheel.prevent="onWheel"
    @mousedown="onPanStart"
    @mousemove="onMouseMove"
    @mouseup="onPanEnd"
    @contextmenu.prevent="store.cancelDrawing()"
    @keydown.escape="store.cancelDrawing()"
    @keydown.delete="onDelete"
    tabindex="0"
  >
    <svg
      ref="svgRef"
      class="canvas-svg"
      :viewBox="`0 0 ${containerSize.width} ${containerSize.height}`"
    >
      <defs>
        <CanvasGrid :grid-size="gridSize" :zoom="store.viewport.zoom" />
      </defs>

      <!-- Grid background -->
      <rect width="100%" height="100%" fill="url(#canvas-grid)" />

      <!-- Master pan/zoom transform group -->
      <g :transform="canvasTransform">

        <!-- Layer 1: Edges -->
        <EdgeRenderer
          v-for="edge in store.edges" :key="edge.id"
          :edge="edge"
          :selected="store.selection.selectedEdgeId === edge.id"
          @click="store.selectEdge(edge.id)"
        />

        <!-- Drawing preview -->
        <DrawingPreview
          v-if="store.drawing.active"
          :drawing="store.drawing"
          :mouse-pos="canvasMousePos"
          :mode="pipeDraw.drawingMode.value"
        />

        <!-- Layer 2: Nodes -->
        <NodeRenderer
          v-for="node in store.nodes" :key="node.id"
          :node="node"
          :edit-mode="store.isEditMode"
          :selected="store.selection.selectedNodeId === node.id"
          :highlighted-port-id="getHighlightedPort(node.id)"
          @node-mousedown="nodeDrag.onNodeMouseDown(node.id, $event)"
          @port-click="(portId: string) => pipeDraw.onPortClick(node.id, portId)"
          @port-mouse-enter="(portId: string) => pipeDraw.onPortEnter(node.id, portId)"
          @port-mouse-leave="() => pipeDraw.onPortLeave()"
          @register-ref="router.registerCompRef"
        />
      </g>
    </svg>

    <!-- Zoom indicator -->
    <div class="zoom-badge">{{ Math.round(store.viewport.zoom * 100) }}%</div>

    <!-- Drawing status -->
    <div v-if="store.drawing.active" class="draw-status">
      <span class="draw-dot" />
      Drawing from <strong>{{ store.drawing.fromNodeId }}:{{ store.drawing.fromPortId }}</strong>
      · {{ store.drawing.waypoints.length }} waypoints
      · <button class="draw-cancel" @click="store.cancelDrawing()">Cancel (Esc)</button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useDiagramStore } from '@/stores/useDiagramStore'
import { useCanvas } from '@/composables/useCanvas'
import { useNodeDrag } from '@/composables/useNodeDrag'
import { usePipeDraw } from '@/composables/usePipeDraw'
import { useOrthoRouter } from '@/composables/useOrthoRouter'
import type { Point } from '@/domain/models'

import CanvasGrid from './CanvasGrid.vue'
import EdgeRenderer from './EdgeRenderer.vue'
import NodeRenderer from './NodeRenderer.vue'
import DrawingPreview from './DrawingPreview.vue'

const store = useDiagramStore()
const containerRef = ref<HTMLDivElement>()
const svgRef = ref<SVGSVGElement>()

const { containerSize, canvasTransform, screenToCanvas, onWheel, gridSize } = useCanvas(containerRef, svgRef)
const nodeDrag = useNodeDrag(screenToCanvas)
const pipeDraw = usePipeDraw(screenToCanvas)
const router = useOrthoRouter()

const canvasMousePos = ref<Point | null>(null)

// Expose for palette drop
defineExpose({ screenToCanvas })

// ── Port highlighting ──

function getHighlightedPort(nodeId: string): string | undefined {
  const hp = store.selection.hoveredPortInfo
  if (hp?.nodeId === nodeId) return hp.portId
  if (store.drawing.active && store.drawing.fromNodeId === nodeId) return store.drawing.fromPortId
  return undefined
}

// ── Pan via shift+drag or middle-click ──

const isPanning = ref(false)
const panStart = ref<Point>({ x: 0, y: 0 })

function onPanStart(e: MouseEvent) {
  if (e.button === 1 || (e.button === 0 && e.shiftKey)) {
    isPanning.value = true
    panStart.value = { x: e.clientX, y: e.clientY }
    e.preventDefault()
  }
}

function onMouseMove(e: MouseEvent) {
  const canvasPos = screenToCanvas({ x: e.clientX, y: e.clientY })
  canvasMousePos.value = canvasPos
  pipeDraw.canvasMousePos.value = canvasPos

  if (isPanning.value) {
    store.pan(e.clientX - panStart.value.x, e.clientY - panStart.value.y)
    panStart.value = { x: e.clientX, y: e.clientY }
  }
}

function onPanEnd() {
  isPanning.value = false
}

function onClick(e: MouseEvent) {
  if (store.drawing.active) {
    const pos = screenToCanvas({ x: e.clientX, y: e.clientY })
    pipeDraw.onCanvasClick(pos, gridSize.value, true)
  } else {
    store.clearSelection()
  }
}

function onDelete() {
  if (store.selection.selectedNodeId) store.removeNode(store.selection.selectedNodeId)
  else if (store.selection.selectedEdgeId) store.removeEdge(store.selection.selectedEdgeId)
}
</script>

<style scoped>
.canvas-container {
  width: 100%; height: 100%; overflow: hidden; position: relative;
  cursor: crosshair; outline: none; background: #0e1117;
}
.canvas-svg { width: 100%; height: 100%; display: block; }
.zoom-badge {
  position: absolute; bottom: 8px; right: 8px;
  padding: 2px 8px; background: rgba(22,27,34,0.85);
  border: 1px solid rgba(48,54,61,0.6); border-radius: 4px;
  font-size: 11px; color: #8b949e; font-family: monospace; pointer-events: none;
}
.draw-status {
  position: absolute; bottom: 8px; left: 8px; right: 80px;
  padding: 6px 12px; background: #161b22; border: 1px solid #30363d;
  border-radius: 6px; font-size: 11px; color: #8b949e;
  display: flex; align-items: center; gap: 6px;
}
.draw-status strong { color: #e6edf3; }
.draw-dot {
  width: 6px; height: 6px; background: #58a6ff;
  border-radius: 50%; animation: blink 1.5s infinite;
}
@keyframes blink { 0%,100% { opacity: 1; } 50% { opacity: 0.3; } }
.draw-cancel {
  background: none; border: none; color: #f85149;
  font-family: inherit; font-size: 11px; cursor: pointer; text-decoration: underline;
}
</style>
