<template>
  <g @click.stop="$emit('click')">
    <!-- Selection glow -->
    <path
      v-if="selected"
      :d="pathD"
      fill="none" stroke="rgba(88,166,255,0.25)" stroke-width="8"
      stroke-linecap="round" stroke-linejoin="round"
    />
    <!-- Invisible hit area for clicking -->
    <path
      :d="pathD"
      fill="none" stroke="transparent" stroke-width="14"
      style="pointer-events:stroke;cursor:pointer"
    />
    <!-- Actual pipe via your library's ConnectionPipe -->
    <ConnectionPipe
      :start-position="fromPos"
      :end-position="toPos"
      :waypoints="edge.waypoints"
      :flowing="edge.props.flowing"
      :direction="edge.props.direction"
    />
  </g>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { DiagramEdge, Point } from '@/domain/models'
import { useOrthoRouter } from '@/composables/useOrthoRouter'
import ConnectionPipe from '@/lib/components/PID/connectors/ConnectionPipe.vue'

interface Props {
  edge: DiagramEdge
  selected: boolean
}

const props = defineProps<Props>()
defineEmits<{ click: [] }>()

const router = useOrthoRouter()

const fromPos = computed(() => router.getPortWorldPos(props.edge.from.nodeId, props.edge.from.portId))
const toPos = computed(() => router.getPortWorldPos(props.edge.to.nodeId, props.edge.to.portId))

const pathD = computed(() => {
  const pts: Point[] = [fromPos.value, ...props.edge.waypoints, toPos.value]
  return pts.map((p, i) => `${i ? 'L' : 'M'} ${p.x} ${p.y}`).join(' ')
})
</script>
