<template>
  <rect
    v-if="visible"
    :x="node.position.x - padding"
    :y="node.position.y - padding"
    :width="node.dimensions.width + padding * 2"
    :height="node.dimensions.height + padding * 2"
    fill="none"
    stroke="#58a6ff"
    stroke-width="1.5"
    stroke-dasharray="4 4"
    :rx="4"
    vector-effect="non-scaling-stroke"
    pointer-events="none"
  />
</template>

<script setup lang="ts">
import type { DiagramNode } from '@/domain/models'

interface Props {
  node: DiagramNode
  visible: boolean
  padding?: number
}

withDefaults(defineProps<Props>(), { padding: 4 })
</script>
