<template>
  <g class="drawing-preview">
    <!-- Committed segments so far -->
    <polyline
      v-if="allPoints.length > 1"
      :points="allPoints.map(p => `${p.x},${p.y}`).join(' ')"
      fill="none"
      stroke="#58a6ff"
      stroke-width="2"
      stroke-linecap="round"
      stroke-linejoin="round"
      opacity="0.6"
    />

    <!-- Rubber-band from last point to mouse -->
    <line
      v-if="lastPoint && mousePos"
      :x1="lastPoint.x" :y1="lastPoint.y"
      :x2="mousePos.x" :y2="mousePos.y"
      stroke="#58a6ff"
      stroke-width="2"
      stroke-dasharray="6 4"
      stroke-linecap="round"
      opacity="0.4"
    />

    <!-- Start point pulse -->
    <circle
      :cx="drawing.startPos.x" :cy="drawing.startPos.y"
      r="6"
      fill="none" stroke="#58a6ff" stroke-width="1.5"
      class="pulse"
    />

    <!-- Waypoint dots -->
    <circle
      v-for="(wp, i) in drawing.waypoints" :key="i"
      :cx="wp.x" :cy="wp.y" r="3"
      fill="#58a6ff" opacity="0.5"
    />
  </g>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import type { DrawingState, Point } from '@/domain/models'

interface Props {
  drawing: DrawingState
  mousePos: Point | null
  mode: 'ortho' | 'click'
}

const props = defineProps<Props>()

const allPoints = computed(() => [props.drawing.startPos, ...props.drawing.waypoints])

const lastPoint = computed(() =>
  props.drawing.waypoints.length > 0
    ? props.drawing.waypoints[props.drawing.waypoints.length - 1]
    : props.drawing.startPos
)
</script>

<style scoped>
.pulse { animation: pulse-ring 1.5s ease-out infinite; }
@keyframes pulse-ring {
  0% { r: 6; opacity: 0.6; }
  100% { r: 14; opacity: 0; }
}
</style>
