<template>
  <!--
    Optional port hit-target overlay.
    Only needed if your library's PortIndicator circles are too small
    for comfortable clicking. Renders larger invisible circles on top.
    If your PortIndicator already has good hit areas, skip this component.
  -->
  <g v-if="visible" class="port-overlay">
    <circle
      v-for="port in ports" :key="port.id"
      :cx="port.x" :cy="port.y"
      :r="hitRadius"
      fill="transparent"
      class="port-hit-target"
      @click.stop="$emit('port-click', port.id)"
      @mouseenter="$emit('port-enter', port.id)"
      @mouseleave="$emit('port-leave', port.id)"
    />
  </g>
</template>

<script setup lang="ts">
import type { PortDefinition } from '@/domain/models'

interface Props {
  ports: PortDefinition[]
  visible: boolean
  hitRadius?: number
}

withDefaults(defineProps<Props>(), { hitRadius: 10 })
defineEmits<{
  'port-click': [portId: string]
  'port-enter': [portId: string]
  'port-leave': [portId: string]
}>()
</script>

<style scoped>
.port-hit-target {
  cursor: crosshair;
  pointer-events: all;
}
</style>
