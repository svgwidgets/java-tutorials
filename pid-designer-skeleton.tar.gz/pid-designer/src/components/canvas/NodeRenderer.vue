<template>
  <g
    :transform="`translate(${node.position.x}, ${node.position.y})`"
    class="node-renderer"
    @mousedown.stop="$emit('node-mousedown', $event)"
  >
    <!-- Selection outline (edit mode) -->
    <SelectionBox :node="{ ...node, position: { x: 0, y: 0 } }" :visible="selected && editMode" />

    <!-- Library component via dynamic <component :is> -->
    <component
      v-if="componentMap[node.typeId]"
      :is="componentMap[node.typeId]"
      :ref="(el: any) => registerRef(el)"
      v-bind="node.props"
      :label="node.label"
      :show-label="true"
      :show-ports="editMode"
      :highlighted-port-id="highlightedPortId"
      @port-click="(portId: string) => $emit('port-click', portId)"
      @port-mouse-enter="(portId: string) => $emit('port-mouse-enter', portId)"
      @port-mouse-leave="(portId: string) => $emit('port-mouse-leave', portId)"
    />

    <!-- Junction (special 8-port node) -->
    <JunctionNode
      v-else-if="node.typeId === 'junction'"
      :ref="(el: any) => registerRef(el)"
      :show-ports="editMode"
      :highlighted-port-id="highlightedPortId"
      @port-click="(portId: string) => $emit('port-click', portId)"
      @port-mouse-enter="(portId: string) => $emit('port-mouse-enter', portId)"
      @port-mouse-leave="(portId: string) => $emit('port-mouse-leave', portId)"
    />
  </g>
</template>

<script setup lang="ts">
import { markRaw, type Component } from 'vue'
import type { DiagramNode } from '@/domain/models'
import SelectionBox from './SelectionBox.vue'
import JunctionNode from './JunctionNode.vue'

// ── Your library components ──
// Adjust paths to match your project
import ManualValve from '@/lib/components/PID/valves/ManualValve.vue'
import CentrifugalPump from '@/lib/components/PID/pumps/GeneralPump.vue'
import VerticalTank from '@/lib/components/PID/tanks/VerticalTank.vue'
import AnalogDisplay from '@/lib/components/PID/sensors/AnalogDisplay.vue'

const componentMap: Record<string, Component> = {
  'manual-valve': markRaw(ManualValve),
  'centrifugal-pump': markRaw(CentrifugalPump),
  'vertical-tank': markRaw(VerticalTank),
  'pressure-sensor': markRaw(AnalogDisplay),
  'temperature-sensor': markRaw(AnalogDisplay),
}

interface Props {
  node: DiagramNode
  editMode: boolean
  selected: boolean
  highlightedPortId?: string
}

const props = defineProps<Props>()

const emit = defineEmits<{
  'node-mousedown': [event: MouseEvent]
  'port-click': [portId: string]
  'port-mouse-enter': [portId: string]
  'port-mouse-leave': [portId: string]
  'register-ref': [nodeId: string, el: any]
}>()

function registerRef(el: any) {
  emit('register-ref', props.node.id, el)
}
</script>

<style scoped>
.node-renderer { cursor: pointer; }
</style>
