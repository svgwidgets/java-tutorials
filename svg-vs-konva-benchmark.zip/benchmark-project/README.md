# SVG vs Vue Konva Benchmark

Engineering benchmark comparing SVG and Vue Konva rendering architectures for an Electron + Vue 3 + TypeScript industrial monitoring application (P&ID Designer + Monitor).

## Quick Start

```bash
# Install dependencies
npm install

# Start development server (browser mode)
npm run dev

# Start with Electron
npm run electron:dev
```

Open http://localhost:5173 in a browser (or the Electron window will open automatically).

## Project Structure

```
benchmark-project/
├── src/
│   ├── shared/                    # Shared across all variants
│   │   ├── scene-generator.ts     # Canonical scene model generator
│   │   ├── update-replay.ts       # Live update replay harness
│   │   └── constants.ts           # Variants, workloads, thresholds
│   │
│   ├── variants/
│   │   ├── svg-only/
│   │   │   └── SvgRenderer.vue    # Variant A/C/E: SVG renderer
│   │   └── konva-only/
│   │       └── KonvaRenderer.vue  # Variant B/D/F: Vue Konva renderer
│   │
│   ├── harness/
│   │   ├── workload-executor.ts   # Automated workload scenarios
│   │   └── benchmark-runner.ts    # Run orchestration & CSV export
│   │
│   ├── instrumentation/
│   │   └── metrics.ts             # Frame sampler, latency tracker, memory profiler
│   │
│   ├── stores/
│   │   └── benchmark.ts           # Pinia store for results & state
│   │
│   ├── views/
│   │   ├── DashboardView.vue      # Control panel & variant launcher
│   │   ├── BenchmarkView.vue      # Live variant execution view
│   │   ├── ResultsView.vue        # Tabular results with thresholds
│   │   └── CompareView.vue        # Analysis framework & decisions
│   │
│   ├── App.vue                    # Root component
│   ├── main.ts                    # Entry point
│   └── router.ts                  # Vue Router config
│
├── types/
│   └── index.ts                   # All TypeScript type definitions
│
├── electron/
│   ├── main.ts                    # Electron main process
│   └── preload.ts                 # Secure IPC bridge
│
├── scripts/
│   └── analyze-results.ts         # Post-hoc CSV analysis
│
└── package.json
```

## Benchmark Variants

| Variant | Renderer | Control Strategy | Purpose |
|---------|----------|-----------------|---------|
| **A** | SVG | None | Pure SVG rendering baseline |
| **B** | Vue Konva | None | Pure canvas rendering baseline |
| **C** | SVG | DOM overlay controls | SVG + overlay reposition cost |
| **D** | Vue Konva | DOM overlay controls | Canvas + overlay reposition cost |
| **E** | SVG | Pseudo-controls (SVG) | In-renderer controls |
| **F** | Vue Konva | Pseudo-controls (Konva) | In-renderer controls |

## Scene Model

Three canonical scene sizes are generated deterministically:

| Size | Elements | Equipment | Sensors | Connectors | Labels | Alarms | Commands |
|------|----------|-----------|---------|------------|--------|--------|----------|
| Small | 122 | 12 | 30 | 35 | 20 | 15 | 10 |
| Medium | 315 | 30 | 80 | 90 | 55 | 35 | 25 |
| Large | 700 | 60 | 180 | 200 | 120 | 80 | 60 |

Both SVG and Konva render the **exact same** scene data from the same JSON model.

## Workload Scenarios

| ID | Description |
|----|-------------|
| W-INIT | Cold-start initial render |
| W-SWITCH | Sub-diagram switch (large → small → large) |
| W-PAN | Smooth pan 3000px over 3 seconds |
| W-ZOOM | Zoom 100%→30%→100%→200%→100% |
| W-LIVE-LO | Live updates at 5/s |
| W-LIVE-MED | Live updates at 20/s (realistic) |
| W-LIVE-HI | Live updates at 60/s (burst) |
| W-LIVE-STRESS | Live updates at 120/s (stress) |
| W-ALARM | 40 simultaneous alarm state changes |
| W-INTERACT | Operator interaction during live updates |
| W-LONG | 4-hour simulated session (accelerated) |
| W-MIXED | Full operator workflow sequence |

## Control Density Scenarios

| ID | Visible Controls | Strategy |
|----|-----------------|----------|
| C-0 | 0 | None (graphics-only baseline) |
| C-10 | 10 | Real DOM overlays |
| C-30 | 30 | Real DOM overlays |
| C-60 | 60 | Real DOM overlays |
| C-CTX | 1–3 | Contextual (on-demand) |
| C-PSEUDO | 30 | Pseudo-controls in renderer |

## Acceptance Thresholds

| Metric | Acceptable | Warning | Fail |
|--------|-----------|---------|------|
| p95 frame time | ≤16.7 ms | 16.7–25 ms | >25 ms |
| p99 frame time | ≤25 ms | 25–33 ms | >33 ms |
| Click-to-highlight | ≤50 ms | 50–100 ms | >100 ms |
| Memory growth (4h) | ≤15% | 15–30% | >30% |

## Usage Guide

### 1. Dashboard
Launch from the main screen. Select scene size, preview any variant, or run benchmark suites.

### 2. Running Benchmarks
- **Quick Bench**: Runs 5 core workloads for a single variant
- **Full A vs B**: Runs all workloads for SVG (A) and Konva (B)
- **Control Density**: Tests C-0 through C-60 for overlay variants
- **All 6 Variants**: Complete matrix

### 3. Viewing Results
The Results tab shows raw data with threshold coloring (green/yellow/red).

### 4. Analysis
The Compare tab applies the §14 analysis framework and §15 decision logic automatically.

### 5. Export & Offline Analysis
Click "Export CSV" to download results. Then run:

```bash
npx ts-node scripts/analyze-results.ts benchmark-results.csv
```

## Fairness Rules (§10)

- Same machine, Electron version, display resolution, window size
- Same scene data model consumed by both renderers
- Same symbol geometry complexity
- Same pre-recorded update replay sequences
- Same warm-up (500ms) and run count (10 per config, first 2 discarded)
- DevTools must be closed during measured runs

## Architecture Notes

### SVG Variant
- Uses CSS `transform` on SVG root for pan/zoom (compositor layer via `will-change`)
- Vue reactive bindings for live state updates
- CSS classes for alarm state styling

### Konva Variant
- Multi-layer Konva Stage: static connectors, equipment, sensors, alarms
- `batchDraw()` coalesces updates into single canvas repaints
- `listening: false` on non-interactive shapes reduces hit-detection overhead
- Stage-level draggable for pan, wheel handler for zoom

### Instrumentation
- `requestAnimationFrame`-based frame-time sampling
- Double-rAF latency measurement (ensures paint completion)
- Periodic memory snapshots via `performance.memory` / Electron IPC
- Statistical aggregation: min, median, mean, p95, p99, max, stddev

## 5-Day Execution Plan

| Day | Activity |
|-----|----------|
| 1 | Build shared scene model, replay harness, instrumentation |
| 2 | Implement SVG prototype (A, C, E) |
| 3 | Implement Konva prototype (B, D, F) |
| 4 | Integrate instrumentation, validate, dry run |
| 5 | Execute full benchmark matrix, analyze, draft findings |
