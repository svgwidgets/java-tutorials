<template>
  <div id="benchmark-app">
    <nav class="top-nav" v-if="showNav">
      <div class="nav-brand">
        <span class="brand-icon">◈</span>
        SVG vs Konva Benchmark
      </div>
      <div class="nav-links">
        <router-link to="/" class="nav-link">Dashboard</router-link>
        <router-link to="/results" class="nav-link">Results</router-link>
        <router-link to="/compare" class="nav-link">Compare</router-link>
      </div>
    </nav>
    <main class="app-main" :class="{ 'no-nav': !showNav }">
      <router-view />
    </main>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useRoute } from 'vue-router';

const route = useRoute();
const showNav = computed(() => route.name !== 'benchmark');
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

html, body, #app, #benchmark-app {
  height: 100%;
  width: 100%;
  font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
  background: #0f1117;
  color: #e1e4ea;
}

.top-nav {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 24px;
  height: 52px;
  background: #181a22;
  border-bottom: 1px solid #2a2d38;
}

.nav-brand {
  font-weight: 700;
  font-size: 15px;
  color: #c5cad6;
  letter-spacing: 0.02em;
}

.brand-icon {
  color: #5b8def;
  margin-right: 8px;
}

.nav-links {
  display: flex;
  gap: 4px;
}

.nav-link {
  padding: 6px 14px;
  border-radius: 6px;
  font-size: 13px;
  font-weight: 500;
  color: #8b90a0;
  text-decoration: none;
  transition: all 0.15s;
}

.nav-link:hover {
  color: #c5cad6;
  background: #22252f;
}

.nav-link.router-link-active {
  color: #5b8def;
  background: rgba(91, 141, 239, 0.1);
}

.app-main {
  height: calc(100% - 52px);
  overflow: auto;
}

.app-main.no-nav {
  height: 100%;
}
</style>
