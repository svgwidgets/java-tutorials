/**
 * Instrumentation Module (§9)
 *
 * Provides:
 *  - Frame-time sampling via requestAnimationFrame
 *  - Interaction latency measurement
 *  - Memory snapshot collection
 *  - Statistical aggregation (min, max, mean, median, p95, p99, stddev)
 */

import type {
  FrameSample,
  LatencySample,
  MemorySnapshot,
  MetricStats,
  RunMetrics,
  BenchmarkRunConfig,
} from '../../types';

// ── Statistical Helpers ──

export function computeStats(values: number[]): MetricStats {
  if (values.length === 0) {
    return { min: 0, max: 0, mean: 0, median: 0, p95: 0, p99: 0, stdDev: 0, count: 0 };
  }

  const sorted = [...values].sort((a, b) => a - b);
  const n = sorted.length;
  const sum = sorted.reduce((a, b) => a + b, 0);
  const mean = sum / n;

  const variance = sorted.reduce((acc, v) => acc + (v - mean) ** 2, 0) / n;
  const stdDev = Math.sqrt(variance);

  return {
    min: sorted[0],
    max: sorted[n - 1],
    mean: Math.round(mean * 100) / 100,
    median: sorted[Math.floor(n * 0.5)],
    p95: sorted[Math.floor(n * 0.95)],
    p99: sorted[Math.floor(n * 0.99)],
    stdDev: Math.round(stdDev * 100) / 100,
    count: n,
  };
}

// ── Frame Time Sampler ──

export class FrameSampler {
  private samples: FrameSample[] = [];
  private lastTimestamp = 0;
  private rafId: number | null = null;
  private _isRunning = false;

  get isRunning(): boolean {
    return this._isRunning;
  }

  start(): void {
    if (this._isRunning) return;
    this._isRunning = true;
    this.lastTimestamp = 0;
    this.rafId = requestAnimationFrame((ts) => this.onFrame(ts));
  }

  stop(): void {
    this._isRunning = false;
    if (this.rafId !== null) {
      cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  reset(): void {
    this.stop();
    this.samples = [];
    this.lastTimestamp = 0;
  }

  getSamples(): FrameSample[] {
    return [...this.samples];
  }

  getStats(): MetricStats {
    return computeStats(this.samples.map(s => s.deltaMs));
  }

  getDroppedFrameCount(): number {
    return this.samples.filter(s => s.deltaMs > 33).length;
  }

  private onFrame(timestamp: number): void {
    if (!this._isRunning) return;

    if (this.lastTimestamp > 0) {
      const delta = timestamp - this.lastTimestamp;
      this.samples.push({ timestamp, deltaMs: delta });
    }
    this.lastTimestamp = timestamp;
    this.rafId = requestAnimationFrame((ts) => this.onFrame(ts));
  }
}

// ── Latency Tracker ──

export class LatencyTracker {
  private samples: LatencySample[] = [];
  private pendingMeasurements = new Map<string, number>();

  /**
   * Call at the start of an interaction (e.g., mousedown).
   * Returns a measurement ID to pass to `end()`.
   */
  begin(interactionType: string): string {
    const id = `${interactionType}-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    this.pendingMeasurements.set(id, performance.now());
    return id;
  }

  /**
   * Call when the visual effect is confirmed (post-render callback).
   * Uses double-rAF to ensure the paint has actually happened.
   */
  end(measurementId: string): void {
    const startMs = this.pendingMeasurements.get(measurementId);
    if (startMs === undefined) return;

    const endMs = performance.now();
    const interactionType = measurementId.split('-')[0];

    this.samples.push({
      interactionType,
      startMs,
      endMs,
      deltaMs: endMs - startMs,
    });

    this.pendingMeasurements.delete(measurementId);
  }

  /**
   * End measurement after double-rAF (ensures paint completion).
   */
  endAfterPaint(measurementId: string): void {
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        this.end(measurementId);
      });
    });
  }

  getSamples(interactionType?: string): LatencySample[] {
    if (interactionType) {
      return this.samples.filter(s => s.interactionType === interactionType);
    }
    return [...this.samples];
  }

  getStats(interactionType: string): MetricStats {
    const values = this.samples
      .filter(s => s.interactionType === interactionType)
      .map(s => s.deltaMs);
    return computeStats(values);
  }

  reset(): void {
    this.samples = [];
    this.pendingMeasurements.clear();
  }
}

// ── Memory Profiler ──

export class MemoryProfiler {
  private snapshots: MemorySnapshot[] = [];
  private intervalId: ReturnType<typeof setInterval> | null = null;

  /**
   * Start periodic memory sampling.
   * @param intervalMs Sampling interval in milliseconds (default 5000ms for long sessions)
   */
  startPeriodic(intervalMs = 5000): void {
    this.takeSnapshot(); // immediate first sample
    this.intervalId = setInterval(() => this.takeSnapshot(), intervalMs);
  }

  stop(): void {
    if (this.intervalId !== null) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }

  async takeSnapshot(): Promise<MemorySnapshot> {
    const snapshot: MemorySnapshot = {
      timestampMs: performance.now(),
      heapUsedMB: 0,
      heapTotalMB: 0,
      externalMB: 0,
    };

    // Try performance.measureUserAgentSpecificMemory (Chrome 89+)
    if ('measureUserAgentSpecificMemory' in performance) {
      try {
        const mem = await (performance as any).measureUserAgentSpecificMemory();
        snapshot.heapUsedMB = mem.bytes / (1024 * 1024);
      } catch {
        // fallback below
      }
    }

    // Try Electron IPC
    if (window.electronAPI) {
      try {
        const mem = await window.electronAPI.getProcessMemory();
        snapshot.heapUsedMB = mem.heapUsed / (1024 * 1024);
        snapshot.heapTotalMB = mem.heapTotal / (1024 * 1024);
        snapshot.externalMB = mem.external / (1024 * 1024);
        snapshot.rss = mem.rss / (1024 * 1024);
      } catch {
        // non-Electron environment
      }
    }

    // Fallback: performance.memory (non-standard but available in Chrome)
    if (snapshot.heapUsedMB === 0 && (performance as any).memory) {
      const mem = (performance as any).memory;
      snapshot.heapUsedMB = mem.usedJSHeapSize / (1024 * 1024);
      snapshot.heapTotalMB = mem.totalJSHeapSize / (1024 * 1024);
    }

    this.snapshots.push(snapshot);
    return snapshot;
  }

  getSnapshots(): MemorySnapshot[] {
    return [...this.snapshots];
  }

  /**
   * Calculate memory growth percentage between first stabilized baseline and last snapshot.
   * Baseline is defined as the average of snapshots 2-5 (after initial GC settling).
   */
  getGrowthPercent(): number {
    if (this.snapshots.length < 6) return 0;

    const baselineSnapshots = this.snapshots.slice(1, 5);
    const baseline = baselineSnapshots.reduce((a, s) => a + s.heapUsedMB, 0) / baselineSnapshots.length;

    const lastSnapshots = this.snapshots.slice(-3);
    const current = lastSnapshots.reduce((a, s) => a + s.heapUsedMB, 0) / lastSnapshots.length;

    if (baseline === 0) return 0;
    return ((current - baseline) / baseline) * 100;
  }

  reset(): void {
    this.stop();
    this.snapshots = [];
  }
}

// ── Metrics Collector (aggregates all instrumentation for a run) ──

export class MetricsCollector {
  public frameSampler = new FrameSampler();
  public latencyTracker = new LatencyTracker();
  public memoryProfiler = new MemoryProfiler();

  private config: BenchmarkRunConfig | null = null;
  private startTime = 0;
  private initialRenderMs: number | null = null;
  private subDiagramSwitchMs: number | null = null;

  configure(config: BenchmarkRunConfig): void {
    this.config = config;
  }

  startCollection(): void {
    this.startTime = performance.now();
    this.frameSampler.start();
  }

  stopCollection(): RunMetrics {
    this.frameSampler.stop();
    this.memoryProfiler.stop();

    const frameSamples = this.frameSampler.getSamples();
    const frameDeltas = frameSamples.map(s => s.deltaMs);

    const metrics: RunMetrics = {
      config: this.config!,
      startTime: this.startTime,
      endTime: performance.now(),
      frameSamples,
      frameStats: computeStats(frameDeltas),
      droppedFrames: frameSamples.filter(s => s.deltaMs > 33).length,
      latencySamples: this.latencyTracker.getSamples(),
      memorySnapshots: this.memoryProfiler.getSnapshots(),
    };

    // Add interaction latency stats if samples exist
    const clickHighlight = this.latencyTracker.getSamples('clickHighlight');
    if (clickHighlight.length > 0) {
      metrics.clickToHighlight = computeStats(clickHighlight.map(s => s.deltaMs));
    }

    const clickControl = this.latencyTracker.getSamples('clickControlOpen');
    if (clickControl.length > 0) {
      metrics.clickToControlOpen = computeStats(clickControl.map(s => s.deltaMs));
    }

    const inputFocus = this.latencyTracker.getSamples('inputFocus');
    if (inputFocus.length > 0) {
      metrics.inputFocusLatency = computeStats(inputFocus.map(s => s.deltaMs));
    }

    if (this.initialRenderMs !== null) {
      metrics.initialRenderMs = this.initialRenderMs;
    }

    if (this.subDiagramSwitchMs !== null) {
      metrics.subDiagramSwitchMs = this.subDiagramSwitchMs;
    }

    return metrics;
  }

  recordInitialRender(ms: number): void {
    this.initialRenderMs = ms;
  }

  recordSubDiagramSwitch(ms: number): void {
    this.subDiagramSwitchMs = ms;
  }

  reset(): void {
    this.frameSampler.reset();
    this.latencyTracker.reset();
    this.memoryProfiler.reset();
    this.config = null;
    this.startTime = 0;
    this.initialRenderMs = null;
    this.subDiagramSwitchMs = null;
  }
}

// ── CSV Export ──

export function metricsToCSV(allMetrics: RunMetrics[]): string {
  const headers = [
    'variant', 'workload', 'controlDensity', 'sceneSize', 'runIndex', 'isWarmUp',
    'frameCount', 'frameMean', 'frameMedian', 'frameP95', 'frameP99', 'frameMin', 'frameMax', 'frameStdDev',
    'droppedFrames',
    'clickHighlightMedian', 'clickHighlightP95',
    'clickControlOpenMedian', 'clickControlOpenP95',
    'inputFocusMedian', 'inputFocusP95',
    'initialRenderMs', 'subDiagramSwitchMs',
    'heapUsedMB_start', 'heapUsedMB_end', 'memoryGrowthPct',
    'durationMs',
  ].join(',');

  const rows = allMetrics.map(m => {
    const memStart = m.memorySnapshots.length > 0 ? m.memorySnapshots[0].heapUsedMB.toFixed(2) : '';
    const memEnd = m.memorySnapshots.length > 0 ? m.memorySnapshots[m.memorySnapshots.length - 1].heapUsedMB.toFixed(2) : '';
    const growthPct = m.memorySnapshots.length > 5
      ? (((parseFloat(memEnd) - parseFloat(memStart)) / parseFloat(memStart)) * 100).toFixed(1)
      : '';

    return [
      m.config.variantId,
      m.config.workloadId,
      m.config.controlDensity,
      m.config.sceneSize,
      m.config.runIndex,
      m.config.isWarmUp,
      m.frameStats.count,
      m.frameStats.mean.toFixed(2),
      m.frameStats.median.toFixed(2),
      m.frameStats.p95.toFixed(2),
      m.frameStats.p99.toFixed(2),
      m.frameStats.min.toFixed(2),
      m.frameStats.max.toFixed(2),
      m.frameStats.stdDev.toFixed(2),
      m.droppedFrames,
      m.clickToHighlight?.median.toFixed(2) ?? '',
      m.clickToHighlight?.p95.toFixed(2) ?? '',
      m.clickToControlOpen?.median.toFixed(2) ?? '',
      m.clickToControlOpen?.p95.toFixed(2) ?? '',
      m.inputFocusLatency?.median.toFixed(2) ?? '',
      m.inputFocusLatency?.p95.toFixed(2) ?? '',
      m.initialRenderMs?.toFixed(2) ?? '',
      m.subDiagramSwitchMs?.toFixed(2) ?? '',
      memStart,
      memEnd,
      growthPct,
      (m.endTime - m.startTime).toFixed(0),
    ].join(',');
  });

  return [headers, ...rows].join('\n');
}
