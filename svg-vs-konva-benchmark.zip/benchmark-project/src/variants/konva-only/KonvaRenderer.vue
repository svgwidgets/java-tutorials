<template>
  <div
    ref="containerRef"
    class="konva-renderer-container"
  >
    <v-stage
      ref="stageRef"
      :config="stageConfig"
      @wheel="onWheel"
      @mousedown="onStageMouseDown"
    >
      <!-- Static layer: connectors (cached for performance) -->
      <v-layer ref="connectorLayerRef" :config="{ listening: false }">
        <v-line
          v-for="el in connectorElements"
          :key="el.id"
          :config="{
            points: getConnectorPoints(el),
            stroke: elementStates[el.id]?.stroke ?? el.stroke,
            strokeWidth: 2,
            lineJoin: 'round',
            listening: false,
          }"
        />
      </v-layer>

      <!-- Equipment layer -->
      <v-layer ref="equipmentLayerRef">
        <v-group
          v-for="el in equipmentElements"
          :key="el.id"
          :config="{
            x: el.x,
            y: el.y,
            rotation: el.rotation,
            name: el.id,
          }"
          @click="() => onElementClick(el.id)"
          @mouseenter="() => onElementHover(el.id)"
          @mouseleave="() => onElementHover(null)"
        >
          <template v-for="(prim, pi) in el.primitives" :key="pi">
            <v-rect
              v-if="prim.type === 'rect'"
              :config="{
                x: prim.x, y: prim.y,
                width: prim.width, height: prim.height,
                fill: pi === 0 ? (elementStates[el.id]?.fill ?? prim.fill) : prim.fill,
                stroke: pi === 0 ? (elementStates[el.id]?.stroke ?? prim.stroke) : prim.stroke,
                strokeWidth: prim.strokeWidth,
                listening: pi === 0,
              }"
            />
            <v-circle
              v-if="prim.type === 'circle'"
              :config="{
                x: prim.x, y: prim.y,
                radius: prim.r,
                fill: pi === 0 ? (elementStates[el.id]?.fill ?? prim.fill) : prim.fill,
                stroke: pi === 0 ? (elementStates[el.id]?.stroke ?? prim.stroke) : prim.stroke,
                strokeWidth: prim.strokeWidth,
                listening: pi === 0,
              }"
            />
            <v-ellipse
              v-if="prim.type === 'ellipse'"
              :config="{
                x: prim.x, y: prim.y,
                radiusX: prim.rx, radiusY: prim.ry,
                fill: prim.fill, stroke: prim.stroke,
                strokeWidth: prim.strokeWidth,
                listening: false,
              }"
            />
            <v-line
              v-if="prim.type === 'polygon'"
              :config="{
                points: prim.points,
                fill: pi === 0 ? (elementStates[el.id]?.fill ?? prim.fill) : prim.fill,
                stroke: pi === 0 ? (elementStates[el.id]?.stroke ?? prim.stroke) : prim.stroke,
                strokeWidth: prim.strokeWidth,
                closed: true,
                listening: pi === 0,
              }"
            />
            <v-path
              v-if="prim.type === 'path'"
              :config="{
                data: prim.d,
                fill: prim.fill, stroke: prim.stroke,
                strokeWidth: prim.strokeWidth,
                listening: false,
              }"
            />
            <v-line
              v-if="prim.type === 'line'"
              :config="{
                points: prim.points,
                stroke: prim.stroke,
                strokeWidth: prim.strokeWidth,
                listening: false,
              }"
            />
          </template>
          <!-- Label -->
          <v-text
            :config="{
              x: 0, y: el.height + 4,
              width: el.width,
              text: el.label,
              fontSize: 10,
              fill: '#333',
              align: 'center',
              listening: false,
            }"
          />
        </v-group>
      </v-layer>

      <!-- Sensor layer (dynamic updates) -->
      <v-layer ref="sensorLayerRef">
        <v-group
          v-for="el in sensorElements"
          :key="el.id"
          :config="{
            x: el.x,
            y: el.y,
            visible: elementStates[el.id]?.visible ?? el.visible,
            name: el.id,
          }"
          @click="() => onElementClick(el.id)"
        >
          <template v-for="(prim, pi) in el.primitives" :key="pi">
            <v-circle
              v-if="prim.type === 'circle'"
              :config="{
                x: prim.x, y: prim.y,
                radius: prim.r,
                fill: elementStates[el.id]?.fill ?? prim.fill,
                stroke: elementStates[el.id]?.stroke ?? prim.stroke,
                strokeWidth: prim.strokeWidth,
                listening: pi === 0,
              }"
            />
            <v-rect
              v-if="prim.type === 'rect'"
              :config="{
                x: prim.x, y: prim.y,
                width: prim.width, height: prim.height,
                fill: prim.fill, stroke: prim.stroke,
                strokeWidth: prim.strokeWidth,
                listening: false,
              }"
            />
            <v-path
              v-if="prim.type === 'path'"
              :config="{
                data: prim.d,
                fill: prim.fill, stroke: prim.stroke,
                strokeWidth: prim.strokeWidth,
                listening: false,
              }"
            />
          </template>
          <v-text
            :config="{
              x: 0, y: 35,
              width: 32,
              text: `${elementStates[el.id]?.value ?? el.value ?? ''}${el.units ? ' ' + el.units : ''}`,
              fontSize: 9,
              fill: '#333',
              align: 'center',
              listening: false,
            }"
          />
          <v-text
            :config="{
              x: 0, y: 48,
              width: 32,
              text: el.label,
              fontSize: 7,
              fill: '#666',
              align: 'center',
              listening: false,
            }"
          />
        </v-group>
      </v-layer>

      <!-- Alarm layer -->
      <v-layer ref="alarmLayerRef">
        <v-group
          v-for="el in alarmElements"
          :key="el.id"
          :config="{
            x: el.x,
            y: el.y,
            visible: elementStates[el.id]?.visible ?? el.visible,
          }"
        >
          <template v-for="(prim, pi) in el.primitives" :key="pi">
            <v-line
              v-if="prim.type === 'polygon'"
              :config="{
                points: prim.points,
                fill: elementStates[el.id]?.fill ?? prim.fill,
                stroke: elementStates[el.id]?.stroke ?? prim.stroke,
                strokeWidth: prim.strokeWidth,
                closed: true,
                listening: false,
              }"
            />
            <v-rect
              v-if="prim.type === 'rect'"
              :config="{
                x: prim.x, y: prim.y,
                width: prim.width, height: prim.height,
                fill: elementStates[el.id]?.fill ?? prim.fill,
                stroke: prim.stroke,
                strokeWidth: prim.strokeWidth,
                listening: false,
              }"
            />
            <v-circle
              v-if="prim.type === 'circle'"
              :config="{
                x: prim.x, y: prim.y,
                radius: prim.r,
                fill: elementStates[el.id]?.fill ?? prim.fill,
                stroke: prim.stroke,
                strokeWidth: prim.strokeWidth,
                listening: false,
              }"
            />
          </template>
        </v-group>
      </v-layer>

      <!-- Pseudo-controls layer (variant F) -->
      <v-layer v-if="showPseudoControls" ref="pseudoLayerRef">
        <v-group
          v-for="el in commandElements"
          :key="el.id"
          :config="{ x: el.x, y: el.y }"
          @click="() => onElementClick(el.id)"
        >
          <v-rect
            :config="{
              width: el.width, height: el.height,
              fill: elementStates[el.id]?.fill ?? el.fill,
              stroke: elementStates[el.id]?.stroke ?? el.stroke,
              strokeWidth: 1.5,
              cornerRadius: 3,
            }"
          />
          <v-text
            :config="{
              width: el.width, height: el.height,
              text: el.controlType === 'toggle' ? 'ON' : el.controlType === 'push_button' ? 'CMD' : '...',
              fontSize: 8,
              fill: '#1565C0',
              align: 'center',
              verticalAlign: 'middle',
              listening: false,
            }"
          />
        </v-group>
      </v-layer>
    </v-stage>

    <!-- DOM overlay controls (variant D) -->
    <div v-if="showOverlayControls" class="overlay-controls-layer" :style="overlayLayerStyle">
      <div
        v-for="ctrl in visibleOverlayControls"
        :key="ctrl.element.id"
        class="overlay-control"
        :style="getOverlayPosition(ctrl.element)"
      >
        <label class="control-label">{{ ctrl.element.label }}</label>
        <template v-if="ctrl.element.controlType === 'toggle'">
          <button class="ctrl-toggle" @click="onControlAction(ctrl.element.id, 'toggle')">
            {{ ctrl.state ? 'ON' : 'OFF' }}
          </button>
        </template>
        <template v-else-if="ctrl.element.controlType === 'numeric_stepper'">
          <div class="ctrl-stepper">
            <button @click="onControlAction(ctrl.element.id, 'decrement')">−</button>
            <input type="number" :value="ctrl.numValue" readonly class="stepper-input" />
            <button @click="onControlAction(ctrl.element.id, 'increment')">+</button>
          </div>
        </template>
        <template v-else-if="ctrl.element.controlType === 'text_input'">
          <input type="text" class="ctrl-text" placeholder="Value..." />
        </template>
        <template v-else-if="ctrl.element.controlType === 'dropdown'">
          <select class="ctrl-dropdown">
            <option v-for="opt in ctrl.element.controlOptions" :key="opt">{{ opt }}</option>
          </select>
        </template>
        <template v-else-if="ctrl.element.controlType === 'push_button'">
          <button class="ctrl-button" @click="onControlAction(ctrl.element.id, 'push')">Execute</button>
        </template>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, reactive, onMounted, nextTick } from 'vue';
import type { SceneModel, SceneElement, ViewportState, UpdateEvent, ControlDensityId } from '../../../types';

const props = defineProps<{
  scene: SceneModel | null;
  controlDensity: ControlDensityId;
  showPseudoControls?: boolean;
  showOverlayControls?: boolean;
}>();

const emit = defineEmits<{
  (e: 'elementClick', id: string): void;
  (e: 'elementHover', id: string | null): void;
  (e: 'viewportChange', state: ViewportState): void;
  (e: 'controlAction', id: string, action: string): void;
}>();

const containerRef = ref<HTMLDivElement>();
const stageRef = ref<any>();
const connectorLayerRef = ref<any>();
const equipmentLayerRef = ref<any>();
const sensorLayerRef = ref<any>();
const alarmLayerRef = ref<any>();
const pseudoLayerRef = ref<any>();

const selectedId = ref<string | null>(null);
const hoveredId = ref<string | null>(null);

const viewport = reactive<ViewportState>({ x: 0, y: 0, scale: 1 });

const stageConfig = computed(() => ({
  width: containerRef.value?.clientWidth ?? 1920,
  height: containerRef.value?.clientHeight ?? 1080,
  draggable: true,
  scaleX: viewport.scale,
  scaleY: viewport.scale,
  x: viewport.x,
  y: viewport.y,
}));

// ── Element state tracking ──
const elementStates = reactive<Record<string, Partial<SceneElement>>>({});

// ── Element categorization ──
const equipmentElements = computed(() =>
  props.scene?.elements.filter(e => e.category === 'equipment') ?? []
);
const sensorElements = computed(() =>
  props.scene?.elements.filter(e => e.category === 'sensor') ?? []
);
const connectorElements = computed(() =>
  props.scene?.elements.filter(e => e.category === 'connector') ?? []
);
const alarmElements = computed(() =>
  props.scene?.elements.filter(e => e.category === 'alarm') ?? []
);
const commandElements = computed(() =>
  props.scene?.elements.filter(e => e.isCommandCapable) ?? []
);

// ── Overlay controls (same logic as SVG variant for fairness) ──
const visibleOverlayControls = computed(() => {
  if (!props.showOverlayControls || !props.scene) return [];
  const cmds = commandElements.value.filter(e =>
    (elementStates[e.id]?.controlEnabled ?? e.controlEnabled)
  );
  const density = props.controlDensity;
  if (density === 'C-CTX') {
    return cmds
      .filter(e => e.id === selectedId.value || e.id === hoveredId.value)
      .slice(0, 3)
      .map(e => ({ element: e, state: true, numValue: 50 }));
  }
  const counts: Record<string, number> = { 'C-10': 10, 'C-30': 30, 'C-60': 60, 'C-0': 0 };
  const count = counts[density] ?? 0;
  return cmds.slice(0, count).map(e => ({ element: e, state: true, numValue: 50 }));
});

const overlayLayerStyle = computed(() => ({
  transform: `translate(${viewport.x}px, ${viewport.y}px) scale(${viewport.scale})`,
  transformOrigin: '0 0',
  position: 'absolute' as const,
  top: '0',
  left: '0',
  pointerEvents: 'none' as const,
}));

// ── Methods ──

function getConnectorPoints(el: SceneElement): number[] {
  if (el.connectorRouting?.waypoints) {
    return el.connectorRouting.waypoints.flatMap(w => [w.x, w.y]);
  }
  return el.primitives[0]?.points ?? [];
}

function getOverlayPosition(el: SceneElement) {
  return {
    position: 'absolute' as const,
    left: `${el.x}px`,
    top: `${el.y + el.height + 4}px`,
    pointerEvents: 'auto' as const,
  };
}

function onElementClick(id: string) {
  selectedId.value = id;
  emit('elementClick', id);
}

function onElementHover(id: string | null) {
  hoveredId.value = id;
  emit('elementHover', id);
}

function onControlAction(id: string, action: string) {
  emit('controlAction', id, action);
}

function onStageMouseDown() {
  // handled by Konva's draggable
}

function onWheel(e: any) {
  e.evt.preventDefault();
  const stage = stageRef.value?.getStage();
  if (!stage) return;
  const oldScale = viewport.scale;
  const pointer = stage.getPointerPosition();
  if (!pointer) return;

  const delta = e.evt.deltaY > 0 ? 0.9 : 1.1;
  const newScale = Math.max(0.1, Math.min(5, oldScale * delta));

  const mousePointTo = {
    x: (pointer.x - viewport.x) / oldScale,
    y: (pointer.y - viewport.y) / oldScale,
  };

  viewport.scale = newScale;
  viewport.x = pointer.x - mousePointTo.x * newScale;
  viewport.y = pointer.y - mousePointTo.y * newScale;

  emit('viewportChange', { ...viewport });
}

// ── Batch draw helper ──
function batchRedraw() {
  nextTick(() => {
    sensorLayerRef.value?.getNode()?.batchDraw();
    alarmLayerRef.value?.getNode()?.batchDraw();
    equipmentLayerRef.value?.getNode()?.batchDraw();
  });
}

// ── Public API ──

function setViewport(state: ViewportState) {
  viewport.x = state.x;
  viewport.y = state.y;
  viewport.scale = state.scale;

  const stage = stageRef.value?.getStage();
  if (stage) {
    stage.scale({ x: state.scale, y: state.scale });
    stage.position({ x: state.x, y: state.y });
    stage.batchDraw();
  }
}

function applyUpdates(events: UpdateEvent[]) {
  for (const event of events) {
    const current = elementStates[event.elementId] || {};
    switch (event.payload.type) {
      case 'color_change':
        elementStates[event.elementId] = {
          ...current,
          fill: event.payload.fill,
          stroke: event.payload.stroke,
          status: event.payload.status,
        };
        break;
      case 'value_change':
        elementStates[event.elementId] = {
          ...current,
          value: event.payload.value,
        };
        break;
      case 'alarm_change':
        elementStates[event.elementId] = {
          ...current,
          alarmLevel: event.payload.alarmLevel,
          fill: event.payload.fill,
          stroke: event.payload.stroke,
        };
        break;
      case 'control_enable':
        elementStates[event.elementId] = {
          ...current,
          controlEnabled: event.payload.enabled,
        };
        break;
      case 'visibility_change':
        elementStates[event.elementId] = {
          ...current,
          visible: event.payload.visible,
        };
        break;
    }
  }
  // Use batchDraw for efficiency
  batchRedraw();
}

function clearState() {
  Object.keys(elementStates).forEach(k => delete elementStates[k]);
  selectedId.value = null;
  hoveredId.value = null;
  viewport.x = 0;
  viewport.y = 0;
  viewport.scale = 1;
}

defineExpose({
  setViewport,
  applyUpdates,
  clearState,
  viewport,
  selectedId,
});
</script>

<style scoped>
.konva-renderer-container {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
  background: #f5f5f5;
}

.overlay-controls-layer {
  position: absolute;
  top: 0;
  left: 0;
}

.overlay-control {
  background: white;
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 4px 8px;
  font-size: 11px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.12);
  white-space: nowrap;
}

.control-label {
  display: block;
  font-weight: 600;
  font-size: 9px;
  color: #666;
  margin-bottom: 2px;
}

.ctrl-toggle {
  padding: 2px 8px;
  font-size: 10px;
  border: 1px solid #1976D2;
  border-radius: 3px;
  background: #E3F2FD;
  cursor: pointer;
}

.ctrl-stepper {
  display: flex;
  align-items: center;
  gap: 2px;
}

.ctrl-stepper button {
  width: 20px;
  height: 20px;
  border: 1px solid #ccc;
  border-radius: 3px;
  cursor: pointer;
  font-size: 12px;
}

.stepper-input {
  width: 40px;
  height: 20px;
  text-align: center;
  border: 1px solid #ccc;
  border-radius: 3px;
  font-size: 10px;
}

.ctrl-text {
  width: 60px;
  height: 20px;
  border: 1px solid #ccc;
  border-radius: 3px;
  font-size: 10px;
  padding: 0 4px;
}

.ctrl-dropdown {
  height: 20px;
  border: 1px solid #ccc;
  border-radius: 3px;
  font-size: 10px;
}

.ctrl-button {
  padding: 2px 8px;
  font-size: 10px;
  border: 1px solid #E65100;
  border-radius: 3px;
  background: #FFF3E0;
  cursor: pointer;
}
</style>
