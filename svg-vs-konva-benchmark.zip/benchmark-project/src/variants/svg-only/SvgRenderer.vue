<template>
  <div
    ref="containerRef"
    class="svg-renderer-container"
    @wheel.prevent="onWheel"
    @pointerdown="onPointerDown"
    @pointermove="onPointerMove"
    @pointerup="onPointerUp"
  >
    <svg
      ref="svgRef"
      :viewBox="`0 0 ${scene?.bounds.width ?? 1920} ${scene?.bounds.height ?? 1080}`"
      :width="scene?.bounds.width ?? 1920"
      :height="scene?.bounds.height ?? 1080"
      :style="svgTransformStyle"
      class="svg-canvas"
      xmlns="http://www.w3.org/2000/svg"
    >
      <!-- Connectors (lowest z-index) -->
      <g class="layer-connectors">
        <polyline
          v-for="el in connectorElements"
          :key="el.id"
          :points="formatPolylinePoints(el)"
          :stroke="elementStates[el.id]?.stroke ?? el.stroke"
          :stroke-width="2"
          fill="none"
          stroke-linejoin="round"
        />
      </g>

      <!-- Equipment symbols -->
      <g class="layer-equipment">
        <g
          v-for="el in equipmentElements"
          :key="el.id"
          :transform="`translate(${el.x}, ${el.y}) rotate(${el.rotation})`"
          :class="['equipment-group', { selected: selectedId === el.id }]"
          @click="onElementClick(el.id)"
          @mouseenter="onElementHover(el.id)"
          @mouseleave="onElementHover(null)"
        >
          <template v-for="(prim, pi) in el.primitives" :key="pi">
            <rect
              v-if="prim.type === 'rect'"
              :x="prim.x" :y="prim.y"
              :width="prim.width" :height="prim.height"
              :fill="pi === 0 ? (elementStates[el.id]?.fill ?? prim.fill) : prim.fill"
              :stroke="pi === 0 ? (elementStates[el.id]?.stroke ?? prim.stroke) : prim.stroke"
              :stroke-width="prim.strokeWidth"
            />
            <circle
              v-if="prim.type === 'circle'"
              :cx="prim.x" :cy="prim.y" :r="prim.r"
              :fill="pi === 0 ? (elementStates[el.id]?.fill ?? prim.fill) : prim.fill"
              :stroke="pi === 0 ? (elementStates[el.id]?.stroke ?? prim.stroke) : prim.stroke"
              :stroke-width="prim.strokeWidth"
            />
            <ellipse
              v-if="prim.type === 'ellipse'"
              :cx="prim.x" :cy="prim.y" :rx="prim.rx" :ry="prim.ry"
              :fill="prim.fill" :stroke="prim.stroke" :stroke-width="prim.strokeWidth"
            />
            <polygon
              v-if="prim.type === 'polygon'"
              :points="prim.points?.join(' ')"
              :fill="pi === 0 ? (elementStates[el.id]?.fill ?? prim.fill) : prim.fill"
              :stroke="pi === 0 ? (elementStates[el.id]?.stroke ?? prim.stroke) : prim.stroke"
              :stroke-width="prim.strokeWidth"
            />
            <path
              v-if="prim.type === 'path'"
              :d="prim.d"
              :fill="prim.fill" :stroke="prim.stroke" :stroke-width="prim.strokeWidth"
            />
            <line
              v-if="prim.type === 'line' && prim.points && prim.points.length >= 4"
              :x1="prim.points[0]" :y1="prim.points[1]"
              :x2="prim.points[2]" :y2="prim.points[3]"
              :stroke="prim.stroke" :stroke-width="prim.strokeWidth"
            />
          </template>
          <!-- Label -->
          <text
            :x="el.width / 2"
            :y="el.height + 14"
            text-anchor="middle"
            font-size="10"
            fill="#333"
          >{{ el.label }}</text>
        </g>
      </g>

      <!-- Sensors -->
      <g class="layer-sensors">
        <g
          v-for="el in sensorElements"
          :key="el.id"
          :transform="`translate(${el.x}, ${el.y})`"
          :class="['sensor-group', { selected: selectedId === el.id }]"
          :style="{ display: (elementStates[el.id]?.visible ?? el.visible) ? '' : 'none' }"
          @click="onElementClick(el.id)"
        >
          <template v-for="(prim, pi) in el.primitives" :key="pi">
            <circle
              v-if="prim.type === 'circle'"
              :cx="prim.x" :cy="prim.y" :r="prim.r"
              :fill="elementStates[el.id]?.fill ?? prim.fill"
              :stroke="elementStates[el.id]?.stroke ?? prim.stroke"
              :stroke-width="prim.strokeWidth"
            />
            <rect
              v-if="prim.type === 'rect'"
              :x="prim.x" :y="prim.y"
              :width="prim.width" :height="prim.height"
              :fill="prim.fill" :stroke="prim.stroke" :stroke-width="prim.strokeWidth"
            />
            <path
              v-if="prim.type === 'path'"
              :d="prim.d"
              :fill="prim.fill" :stroke="prim.stroke" :stroke-width="prim.strokeWidth"
            />
          </template>
          <text x="16" y="45" text-anchor="middle" font-size="9" fill="#333">
            {{ elementStates[el.id]?.value ?? el.value }}{{ el.units ? ` ${el.units}` : '' }}
          </text>
          <text x="16" y="58" text-anchor="middle" font-size="7" fill="#666">{{ el.label }}</text>
        </g>
      </g>

      <!-- Alarm indicators -->
      <g class="layer-alarms">
        <g
          v-for="el in alarmElements"
          :key="el.id"
          :transform="`translate(${el.x}, ${el.y})`"
          :style="{ display: (elementStates[el.id]?.visible ?? el.visible) ? '' : 'none' }"
          :class="['alarm-indicator', elementStates[el.id]?.alarmLevel ?? el.alarmLevel]"
        >
          <template v-for="(prim, pi) in el.primitives" :key="pi">
            <polygon
              v-if="prim.type === 'polygon'"
              :points="prim.points?.join(' ')"
              :fill="elementStates[el.id]?.fill ?? prim.fill"
              :stroke="elementStates[el.id]?.stroke ?? prim.stroke"
              :stroke-width="prim.strokeWidth"
            />
            <rect
              v-if="prim.type === 'rect'"
              :x="prim.x" :y="prim.y"
              :width="prim.width" :height="prim.height"
              :fill="elementStates[el.id]?.fill ?? prim.fill"
              :stroke="prim.stroke" :stroke-width="prim.strokeWidth"
            />
            <circle
              v-if="prim.type === 'circle'"
              :cx="prim.x" :cy="prim.y" :r="prim.r"
              :fill="elementStates[el.id]?.fill ?? prim.fill"
              :stroke="prim.stroke" :stroke-width="prim.strokeWidth"
            />
          </template>
        </g>
      </g>

      <!-- Labels -->
      <g class="layer-labels">
        <g
          v-for="el in labelElements"
          :key="el.id"
          :transform="`translate(${el.x}, ${el.y})`"
        >
          <rect
            :width="el.width" :height="el.height"
            :fill="el.fill" :stroke="el.stroke" stroke-width="0.5"
          />
          <text x="4" y="13" font-size="9" fill="#444">{{ el.label }}</text>
        </g>
      </g>

      <!-- Command indicators (for pseudo-controls in variant E) -->
      <g v-if="showPseudoControls" class="layer-pseudo-controls">
        <g
          v-for="el in commandElements"
          :key="el.id"
          :transform="`translate(${el.x}, ${el.y})`"
          @click="onElementClick(el.id)"
          class="pseudo-control"
        >
          <rect
            :width="el.width" :height="el.height"
            :fill="elementStates[el.id]?.fill ?? el.fill"
            :stroke="elementStates[el.id]?.stroke ?? el.stroke"
            stroke-width="1.5" rx="3"
          />
          <text :x="el.width / 2" :y="el.height / 2 + 3" text-anchor="middle" font-size="8" fill="#1565C0">
            {{ el.controlType === 'toggle' ? 'ON' : el.controlType === 'push_button' ? 'CMD' : '...' }}
          </text>
        </g>
      </g>
    </svg>

    <!-- DOM overlay controls (for variants C) -->
    <div v-if="showOverlayControls" class="overlay-controls-layer" :style="overlayLayerStyle">
      <div
        v-for="ctrl in visibleOverlayControls"
        :key="ctrl.element.id"
        class="overlay-control"
        :style="getOverlayPosition(ctrl.element)"
      >
        <label class="control-label">{{ ctrl.element.label }}</label>
        <template v-if="ctrl.element.controlType === 'toggle'">
          <button class="ctrl-toggle" @click="onControlAction(ctrl.element.id, 'toggle')">
            {{ ctrl.state ? 'ON' : 'OFF' }}
          </button>
        </template>
        <template v-else-if="ctrl.element.controlType === 'numeric_stepper'">
          <div class="ctrl-stepper">
            <button @click="onControlAction(ctrl.element.id, 'decrement')">−</button>
            <input type="number" :value="ctrl.numValue" readonly class="stepper-input" />
            <button @click="onControlAction(ctrl.element.id, 'increment')">+</button>
          </div>
        </template>
        <template v-else-if="ctrl.element.controlType === 'text_input'">
          <input type="text" class="ctrl-text" placeholder="Value..." @focus="onInputFocus(ctrl.element.id)" />
        </template>
        <template v-else-if="ctrl.element.controlType === 'dropdown'">
          <select class="ctrl-dropdown" @change="onControlAction(ctrl.element.id, 'select')">
            <option v-for="opt in ctrl.element.controlOptions" :key="opt">{{ opt }}</option>
          </select>
        </template>
        <template v-else-if="ctrl.element.controlType === 'push_button'">
          <button class="ctrl-button" @click="onControlAction(ctrl.element.id, 'push')">Execute</button>
        </template>
      </div>
    </div>

    <!-- Selection highlight -->
    <div
      v-if="selectedId && selectedElement"
      class="selection-highlight"
      :style="getSelectionHighlightStyle()"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, reactive, onMounted, onUnmounted, watch } from 'vue';
import type { SceneModel, SceneElement, ViewportState, UpdateEvent, ControlDensityId } from '../../../types';

const props = defineProps<{
  scene: SceneModel | null;
  controlDensity: ControlDensityId;
  showPseudoControls?: boolean;
  showOverlayControls?: boolean;
}>();

const emit = defineEmits<{
  (e: 'elementClick', id: string): void;
  (e: 'elementHover', id: string | null): void;
  (e: 'viewportChange', state: ViewportState): void;
  (e: 'controlAction', id: string, action: string): void;
}>();

// ── Refs ──
const containerRef = ref<HTMLDivElement>();
const svgRef = ref<SVGSVGElement>();
const selectedId = ref<string | null>(null);
const hoveredId = ref<string | null>(null);

// ── Viewport ──
const viewport = reactive<ViewportState>({ x: 0, y: 0, scale: 1 });

const svgTransformStyle = computed(() => ({
  transform: `translate(${viewport.x}px, ${viewport.y}px) scale(${viewport.scale})`,
  transformOrigin: '0 0',
  willChange: 'transform',
}));

// ── Element state tracking (for live updates) ──
const elementStates = reactive<Record<string, Partial<SceneElement>>>({});

// ── Element categorization ──
const equipmentElements = computed(() =>
  props.scene?.elements.filter(e => e.category === 'equipment') ?? []
);
const sensorElements = computed(() =>
  props.scene?.elements.filter(e => e.category === 'sensor') ?? []
);
const connectorElements = computed(() =>
  props.scene?.elements.filter(e => e.category === 'connector') ?? []
);
const labelElements = computed(() =>
  props.scene?.elements.filter(e => e.category === 'label') ?? []
);
const alarmElements = computed(() =>
  props.scene?.elements.filter(e => e.category === 'alarm') ?? []
);
const commandElements = computed(() =>
  props.scene?.elements.filter(e => e.isCommandCapable) ?? []
);

const selectedElement = computed(() =>
  props.scene?.elements.find(e => e.id === selectedId.value)
);

// ── Overlay controls ──
const visibleOverlayControls = computed(() => {
  if (!props.showOverlayControls || !props.scene) return [];
  const cmds = commandElements.value.filter(e =>
    (elementStates[e.id]?.controlEnabled ?? e.controlEnabled)
  );

  const density = props.controlDensity;
  if (density === 'C-CTX') {
    // Only show for selected/hovered element
    return cmds
      .filter(e => e.id === selectedId.value || e.id === hoveredId.value)
      .slice(0, 3)
      .map(e => ({ element: e, state: true, numValue: 50 }));
  }

  const counts: Record<string, number> = {
    'C-10': 10, 'C-30': 30, 'C-60': 60, 'C-0': 0,
  };
  const count = counts[density] ?? 0;
  return cmds.slice(0, count).map(e => ({ element: e, state: true, numValue: 50 }));
});

const overlayLayerStyle = computed(() => ({
  transform: `translate(${viewport.x}px, ${viewport.y}px) scale(${viewport.scale})`,
  transformOrigin: '0 0',
  position: 'absolute' as const,
  top: '0',
  left: '0',
  pointerEvents: 'none' as const,
}));

// ── Methods ──

function formatPolylinePoints(el: SceneElement): string {
  if (el.connectorRouting?.waypoints) {
    return el.connectorRouting.waypoints.map(w => `${w.x},${w.y}`).join(' ');
  }
  if (el.primitives[0]?.points) {
    const pts = el.primitives[0].points;
    const pairs: string[] = [];
    for (let i = 0; i < pts.length; i += 2) {
      pairs.push(`${pts[i]},${pts[i + 1]}`);
    }
    return pairs.join(' ');
  }
  return '';
}

function getOverlayPosition(el: SceneElement) {
  return {
    position: 'absolute' as const,
    left: `${el.x}px`,
    top: `${el.y + el.height + 4}px`,
    pointerEvents: 'auto' as const,
  };
}

function getSelectionHighlightStyle() {
  const el = selectedElement.value;
  if (!el) return { display: 'none' };
  return {
    position: 'absolute' as const,
    left: `${viewport.x + el.x * viewport.scale - 3}px`,
    top: `${viewport.y + el.y * viewport.scale - 3}px`,
    width: `${el.width * viewport.scale + 6}px`,
    height: `${el.height * viewport.scale + 6}px`,
    border: '2px solid #2196F3',
    borderRadius: '4px',
    pointerEvents: 'none' as const,
  };
}

function onElementClick(id: string) {
  selectedId.value = id;
  emit('elementClick', id);
}

function onElementHover(id: string | null) {
  hoveredId.value = id;
  emit('elementHover', id);
}

function onControlAction(id: string, action: string) {
  emit('controlAction', id, action);
}

function onInputFocus(id: string) {
  // Tracked by latency instrumentation externally
}

// ── Pan/Zoom Handlers ──
let isPanning = false;
let panStartX = 0;
let panStartY = 0;
let viewStartX = 0;
let viewStartY = 0;

function onPointerDown(e: PointerEvent) {
  if (e.button !== 1 && !e.ctrlKey) return; // middle-click or ctrl+click to pan
  isPanning = true;
  panStartX = e.clientX;
  panStartY = e.clientY;
  viewStartX = viewport.x;
  viewStartY = viewport.y;
  (e.target as HTMLElement)?.setPointerCapture?.(e.pointerId);
}

function onPointerMove(e: PointerEvent) {
  if (!isPanning) return;
  viewport.x = viewStartX + (e.clientX - panStartX);
  viewport.y = viewStartY + (e.clientY - panStartY);
  emit('viewportChange', { ...viewport });
}

function onPointerUp(_e: PointerEvent) {
  isPanning = false;
}

function onWheel(e: WheelEvent) {
  const delta = e.deltaY > 0 ? 0.9 : 1.1;
  const newScale = Math.max(0.1, Math.min(5, viewport.scale * delta));
  viewport.scale = newScale;
  emit('viewportChange', { ...viewport });
}

// ── Public API (exposed for workload executor) ──

function setViewport(state: ViewportState) {
  viewport.x = state.x;
  viewport.y = state.y;
  viewport.scale = state.scale;
}

function applyUpdates(events: UpdateEvent[]) {
  for (const event of events) {
    const current = elementStates[event.elementId] || {};
    switch (event.payload.type) {
      case 'color_change':
        elementStates[event.elementId] = {
          ...current,
          fill: event.payload.fill,
          stroke: event.payload.stroke,
          status: event.payload.status,
        };
        break;
      case 'value_change':
        elementStates[event.elementId] = {
          ...current,
          value: event.payload.value,
        };
        break;
      case 'alarm_change':
        elementStates[event.elementId] = {
          ...current,
          alarmLevel: event.payload.alarmLevel,
          fill: event.payload.fill,
          stroke: event.payload.stroke,
        };
        break;
      case 'control_enable':
        elementStates[event.elementId] = {
          ...current,
          controlEnabled: event.payload.enabled,
        };
        break;
      case 'visibility_change':
        elementStates[event.elementId] = {
          ...current,
          visible: event.payload.visible,
        };
        break;
    }
  }
}

function clearState() {
  Object.keys(elementStates).forEach(k => delete elementStates[k]);
  selectedId.value = null;
  hoveredId.value = null;
  viewport.x = 0;
  viewport.y = 0;
  viewport.scale = 1;
}

defineExpose({
  setViewport,
  applyUpdates,
  clearState,
  viewport,
  selectedId,
});
</script>

<style scoped>
.svg-renderer-container {
  position: relative;
  width: 100%;
  height: 100%;
  overflow: hidden;
  background: #f5f5f5;
  cursor: grab;
}

.svg-renderer-container:active {
  cursor: grabbing;
}

.svg-canvas {
  position: absolute;
  top: 0;
  left: 0;
}

.equipment-group {
  cursor: pointer;
}

.equipment-group:hover rect:first-child,
.equipment-group:hover circle:first-child {
  filter: brightness(1.1);
}

.equipment-group.selected rect:first-child,
.equipment-group.selected circle:first-child {
  stroke: #2196F3;
  stroke-width: 3;
}

.sensor-group {
  cursor: pointer;
}

.alarm-indicator.critical,
.alarm-indicator.emergency {
  animation: alarm-blink 0.8s ease-in-out infinite;
}

@keyframes alarm-blink {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.4; }
}

.pseudo-control {
  cursor: pointer;
}

.pseudo-control:hover rect {
  filter: brightness(1.1);
}

.overlay-controls-layer {
  position: absolute;
  top: 0;
  left: 0;
}

.overlay-control {
  background: white;
  border: 1px solid #ccc;
  border-radius: 4px;
  padding: 4px 8px;
  font-size: 11px;
  box-shadow: 0 1px 3px rgba(0,0,0,0.12);
  white-space: nowrap;
}

.control-label {
  display: block;
  font-weight: 600;
  font-size: 9px;
  color: #666;
  margin-bottom: 2px;
}

.ctrl-toggle {
  padding: 2px 8px;
  font-size: 10px;
  border: 1px solid #1976D2;
  border-radius: 3px;
  background: #E3F2FD;
  cursor: pointer;
}

.ctrl-stepper {
  display: flex;
  align-items: center;
  gap: 2px;
}

.ctrl-stepper button {
  width: 20px;
  height: 20px;
  border: 1px solid #ccc;
  border-radius: 3px;
  cursor: pointer;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.stepper-input {
  width: 40px;
  height: 20px;
  text-align: center;
  border: 1px solid #ccc;
  border-radius: 3px;
  font-size: 10px;
}

.ctrl-text {
  width: 60px;
  height: 20px;
  border: 1px solid #ccc;
  border-radius: 3px;
  font-size: 10px;
  padding: 0 4px;
}

.ctrl-dropdown {
  height: 20px;
  border: 1px solid #ccc;
  border-radius: 3px;
  font-size: 10px;
}

.ctrl-button {
  padding: 2px 8px;
  font-size: 10px;
  border: 1px solid #E65100;
  border-radius: 3px;
  background: #FFF3E0;
  cursor: pointer;
}

.selection-highlight {
  pointer-events: none;
  z-index: 100;
}
</style>
