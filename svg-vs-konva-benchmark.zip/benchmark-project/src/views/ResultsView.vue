<template>
  <div class="results-view">
    <header class="results-header">
      <h1>Benchmark Results</h1>
      <div class="header-actions">
        <span class="result-count">{{ validResults.length }} valid runs ({{ store.allResults.length }} total)</span>
        <button class="btn-export" @click="store.downloadCSV()" :disabled="store.allResults.length === 0">
          Export CSV
        </button>
      </div>
    </header>

    <div v-if="validResults.length === 0" class="empty-state">
      <p>No benchmark results yet. Run benchmarks from the Dashboard.</p>
    </div>

    <!-- Graphics-Only Comparison (A vs B) -->
    <section v-if="hasVariant('A') || hasVariant('B')" class="card">
      <h2>Graphics-Only Comparison (A: SVG vs B: Konva)</h2>
      <table class="results-table">
        <thead>
          <tr>
            <th>Workload</th>
            <th>Scene</th>
            <th>SVG p95 (ms)</th>
            <th>Konva p95 (ms)</th>
            <th>SVG Drops</th>
            <th>Konva Drops</th>
            <th>Diff %</th>
            <th>Winner</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in graphicsComparisonRows" :key="row.key">
            <td>{{ row.workload }}</td>
            <td>{{ row.scene }}</td>
            <td :class="thresholdClass(row.svgP95, 'p95')">{{ row.svgP95?.toFixed(1) ?? '—' }}</td>
            <td :class="thresholdClass(row.konvaP95, 'p95')">{{ row.konvaP95?.toFixed(1) ?? '—' }}</td>
            <td>{{ row.svgDrops ?? '—' }}</td>
            <td>{{ row.konvaDrops ?? '—' }}</td>
            <td :class="diffClass(row.diffPct)">{{ row.diffPct !== null ? row.diffPct.toFixed(1) + '%' : '—' }}</td>
            <td>
              <span v-if="row.winner" :class="['winner-badge', row.winner]">{{ row.winner.toUpperCase() }}</span>
            </td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- Control Density Comparison -->
    <section v-if="hasVariant('C') || hasVariant('D')" class="card">
      <h2>Control Density Impact (C: SVG+Overlay vs D: Konva+Overlay)</h2>
      <table class="results-table">
        <thead>
          <tr>
            <th>Controls</th>
            <th>SVG+Overlay p95</th>
            <th>Konva+Overlay p95</th>
            <th>Delta</th>
            <th>Bottleneck</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="row in controlDensityRows" :key="row.density">
            <td>{{ row.density }}</td>
            <td :class="thresholdClass(row.svgP95, 'p95')">{{ row.svgP95?.toFixed(1) ?? '—' }}</td>
            <td :class="thresholdClass(row.konvaP95, 'p95')">{{ row.konvaP95?.toFixed(1) ?? '—' }}</td>
            <td>{{ row.delta !== null ? row.delta.toFixed(1) + 'ms' : '—' }}</td>
            <td>{{ row.bottleneck }}</td>
          </tr>
        </tbody>
      </table>
    </section>

    <!-- All Raw Results -->
    <section class="card">
      <h2>All Results (Raw)</h2>
      <div class="table-scroll">
        <table class="results-table compact">
          <thead>
            <tr>
              <th>Variant</th>
              <th>Workload</th>
              <th>Controls</th>
              <th>Scene</th>
              <th>Run</th>
              <th>Mean (ms)</th>
              <th>Median (ms)</th>
              <th>p95 (ms)</th>
              <th>p99 (ms)</th>
              <th>Dropped</th>
              <th>Init (ms)</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="(m, i) in validResults" :key="i" :class="{ warmup: m.config.isWarmUp }">
              <td><span class="variant-chip">{{ m.config.variantId }}</span></td>
              <td>{{ m.config.workloadId }}</td>
              <td>{{ m.config.controlDensity }}</td>
              <td>{{ m.config.sceneSize }}</td>
              <td>{{ m.config.runIndex + 1 }}</td>
              <td>{{ m.frameStats.mean.toFixed(2) }}</td>
              <td>{{ m.frameStats.median.toFixed(2) }}</td>
              <td :class="thresholdClass(m.frameStats.p95, 'p95')">{{ m.frameStats.p95.toFixed(2) }}</td>
              <td :class="thresholdClass(m.frameStats.p99, 'p99')">{{ m.frameStats.p99.toFixed(2) }}</td>
              <td>{{ m.droppedFrames }}</td>
              <td>{{ m.initialRenderMs?.toFixed(1) ?? '—' }}</td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useBenchmarkStore } from '../stores/benchmark';
import { THRESHOLDS, evaluateThreshold, WORKLOAD_LABELS } from '../shared/constants';
import { computeStats } from '../instrumentation/metrics';
import type { VariantId, WorkloadId, ControlDensityId } from '../../types';

const store = useBenchmarkStore();

const validResults = computed(() => store.allResults.filter(r => !r.config.isWarmUp));

function hasVariant(id: VariantId): boolean {
  return validResults.value.some(r => r.config.variantId === id);
}

function getMedianP95(variantId: VariantId, workloadId: WorkloadId, density: ControlDensityId = 'C-0', scene = 'large'): number | null {
  const results = store.getResults(variantId, workloadId, density, scene as any);
  if (results.length === 0) return null;
  return computeStats(results.map(r => r.frameStats.p95)).median;
}

function getMedianDrops(variantId: VariantId, workloadId: WorkloadId): number | null {
  const results = store.getResults(variantId, workloadId);
  if (results.length === 0) return null;
  return computeStats(results.map(r => r.droppedFrames)).median;
}

// Graphics comparison rows
const graphicsComparisonRows = computed(() => {
  const workloads: WorkloadId[] = [
    'W-INIT', 'W-PAN', 'W-ZOOM',
    'W-LIVE-LO', 'W-LIVE-MED', 'W-LIVE-HI', 'W-LIVE-STRESS', 'W-ALARM',
  ];

  return workloads.map(wl => {
    const svgP95 = getMedianP95('A', wl);
    const konvaP95 = getMedianP95('B', wl);
    const svgDrops = getMedianDrops('A', wl);
    const konvaDrops = getMedianDrops('B', wl);

    let diffPct: number | null = null;
    let winner: string | null = null;
    if (svgP95 !== null && konvaP95 !== null) {
      diffPct = ((svgP95 - konvaP95) / svgP95) * 100;
      if (Math.abs(diffPct) < 10) winner = 'tie';
      else winner = konvaP95 < svgP95 ? 'konva' : 'svg';
    }

    return {
      key: wl,
      workload: WORKLOAD_LABELS[wl],
      scene: 'large',
      svgP95,
      konvaP95,
      svgDrops,
      konvaDrops,
      diffPct,
      winner,
    };
  });
});

// Control density rows
const controlDensityRows = computed(() => {
  const densities: ControlDensityId[] = ['C-0', 'C-10', 'C-30', 'C-60', 'C-CTX'];

  return densities.map(d => {
    const svgP95 = getMedianP95('C', 'W-PAN', d);
    const konvaP95 = getMedianP95('D', 'W-PAN', d);
    let delta: number | null = null;
    let bottleneck = '—';

    if (svgP95 !== null && konvaP95 !== null) {
      delta = svgP95 - konvaP95;
      if (svgP95 > 25 && konvaP95 > 25) bottleneck = 'Overlay DOM';
      else if (svgP95 > 25) bottleneck = 'SVG + Overlay';
      else if (konvaP95 > 25) bottleneck = 'Konva + Overlay';
      else bottleneck = 'Within budget';
    }

    return {
      density: d,
      svgP95,
      konvaP95,
      delta,
      bottleneck,
    };
  });
});

function thresholdClass(value: number | null | undefined, metric: 'p95' | 'p99'): string {
  if (value == null) return '';
  const threshold = metric === 'p95' ? THRESHOLDS.p95FrameMs : THRESHOLDS.p99FrameMs;
  const status = evaluateThreshold(value, threshold);
  return status;
}

function diffClass(pct: number | null): string {
  if (pct === null) return '';
  if (Math.abs(pct) < 10) return 'negligible';
  if (pct > 0) return 'positive';
  return 'negative';
}
</script>

<style scoped>
.results-view {
  padding: 24px 32px;
  max-width: 1400px;
  margin: 0 auto;
}

.results-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 24px;
}

.results-header h1 {
  font-size: 22px;
  font-weight: 700;
}

.header-actions {
  display: flex;
  align-items: center;
  gap: 16px;
}

.result-count {
  font-size: 12px;
  color: #6b7084;
}

.btn-export {
  padding: 6px 16px;
  border: 1px solid #2a2d38;
  border-radius: 6px;
  background: transparent;
  color: #5b8def;
  cursor: pointer;
  font-size: 12px;
}

.btn-export:disabled { opacity: 0.4; }

.empty-state {
  text-align: center;
  padding: 60px;
  color: #6b7084;
  font-size: 14px;
}

.card {
  background: #181a22;
  border: 1px solid #2a2d38;
  border-radius: 10px;
  padding: 20px 24px;
  margin-bottom: 20px;
}

.card h2 {
  font-size: 15px;
  font-weight: 600;
  color: #c5cad6;
  margin-bottom: 16px;
}

.table-scroll {
  overflow-x: auto;
}

.results-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 12px;
}

.results-table th {
  text-align: left;
  padding: 8px 12px;
  border-bottom: 2px solid #2a2d38;
  color: #6b7084;
  font-weight: 600;
  font-size: 11px;
  text-transform: uppercase;
  letter-spacing: 0.03em;
  white-space: nowrap;
}

.results-table td {
  padding: 6px 12px;
  border-bottom: 1px solid #22252f;
  color: #c5cad6;
  font-variant-numeric: tabular-nums;
}

.results-table.compact td {
  padding: 4px 8px;
  font-size: 11px;
}

.results-table tr.warmup { opacity: 0.4; }

td.pass { color: #66BB6A; }
td.warning { color: #FFA726; }
td.fail { color: #EF5350; font-weight: 600; }

td.negligible { color: #9E9E9E; }
td.positive { color: #66BB6A; }
td.negative { color: #EF5350; }

.winner-badge {
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 700;
}

.winner-badge.svg { background: rgba(76, 175, 80, 0.15); color: #66BB6A; }
.winner-badge.konva { background: rgba(91, 141, 239, 0.15); color: #5b8def; }
.winner-badge.tie { background: rgba(158, 158, 158, 0.15); color: #9E9E9E; }

.variant-chip {
  display: inline-block;
  width: 20px;
  height: 20px;
  border-radius: 4px;
  background: #2a2d38;
  text-align: center;
  line-height: 20px;
  font-weight: 700;
  font-size: 10px;
  color: #5b8def;
}
</style>
