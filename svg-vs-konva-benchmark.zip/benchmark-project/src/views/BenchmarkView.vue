<template>
  <div class="benchmark-view">
    <!-- Control bar -->
    <div class="control-bar">
      <button class="btn-back" @click="$router.push('/')">← Back</button>
      <div class="variant-info">
        <span class="variant-badge">{{ variantId }}</span>
        <span class="variant-name">{{ variantConfig?.label }}</span>
      </div>

      <div class="controls-group">
        <select v-model="selectedWorkload" class="select-input">
          <option v-for="w in workloadOptions" :key="w.id" :value="w.id">{{ w.label }}</option>
        </select>

        <select v-model="selectedSceneSize" class="select-input">
          <option value="small">Small (122)</option>
          <option value="medium">Medium (315)</option>
          <option value="large">Large (700)</option>
        </select>

        <select v-model="selectedDensity" class="select-input">
          <option v-for="d in densityOptions" :key="d.id" :value="d.id">{{ d.label }}</option>
        </select>

        <button class="btn-run" @click="executeCurrentWorkload" :disabled="isExecuting">
          {{ isExecuting ? 'Running...' : 'Run Workload' }}
        </button>

        <button class="btn-run-all" @click="executeQuickSuite" :disabled="isExecuting">
          Quick Suite
        </button>
      </div>

      <!-- Live metrics -->
      <div class="live-metrics">
        <div class="metric">
          <span class="metric-label">FPS</span>
          <span class="metric-value" :class="fpsClass">{{ liveFps }}</span>
        </div>
        <div class="metric">
          <span class="metric-label">p95</span>
          <span class="metric-value">{{ liveP95.toFixed(1) }}ms</span>
        </div>
        <div class="metric">
          <span class="metric-label">Drops</span>
          <span class="metric-value">{{ liveDropped }}</span>
        </div>
      </div>
    </div>

    <!-- Renderer viewport -->
    <div class="renderer-viewport" ref="viewportRef">
      <SvgRenderer
        v-if="variantConfig?.renderer === 'svg'"
        ref="rendererRef"
        :scene="currentScene"
        :controlDensity="selectedDensity"
        :showOverlayControls="variantConfig?.controlStrategy === 'overlay'"
        :showPseudoControls="variantConfig?.controlStrategy === 'pseudo'"
        @elementClick="onElementClick"
        @viewportChange="onViewportChange"
      />
      <KonvaRenderer
        v-else-if="variantConfig?.renderer === 'konva'"
        ref="rendererRef"
        :scene="currentScene"
        :controlDensity="selectedDensity"
        :showOverlayControls="variantConfig?.controlStrategy === 'overlay'"
        :showPseudoControls="variantConfig?.controlStrategy === 'pseudo'"
        @elementClick="onElementClick"
        @viewportChange="onViewportChange"
      />
    </div>

    <!-- Results panel -->
    <div v-if="lastRunMetrics" class="results-panel">
      <h3>Last Run Results</h3>
      <div class="results-grid">
        <div class="result-item">
          <span class="res-label">Frame Mean</span>
          <span class="res-value">{{ lastRunMetrics.frameStats.mean.toFixed(2) }} ms</span>
        </div>
        <div class="result-item">
          <span class="res-label">Frame p95</span>
          <span class="res-value" :class="p95Class">{{ lastRunMetrics.frameStats.p95.toFixed(2) }} ms</span>
        </div>
        <div class="result-item">
          <span class="res-label">Frame p99</span>
          <span class="res-value">{{ lastRunMetrics.frameStats.p99.toFixed(2) }} ms</span>
        </div>
        <div class="result-item">
          <span class="res-label">Dropped</span>
          <span class="res-value">{{ lastRunMetrics.droppedFrames }}</span>
        </div>
        <div class="result-item" v-if="lastRunMetrics.initialRenderMs">
          <span class="res-label">Init Render</span>
          <span class="res-value">{{ lastRunMetrics.initialRenderMs.toFixed(1) }} ms</span>
        </div>
        <div class="result-item">
          <span class="res-label">Duration</span>
          <span class="res-value">{{ ((lastRunMetrics.endTime - lastRunMetrics.startTime) / 1000).toFixed(1) }}s</span>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, watch } from 'vue';
import { useRoute } from 'vue-router';
import { useBenchmarkStore } from '../stores/benchmark';
import { VARIANTS, WORKLOAD_IDS, WORKLOAD_LABELS, CONTROL_DENSITIES, CONTROL_DENSITY_IDS } from '../shared/constants';
import { MetricsCollector, FrameSampler } from '../instrumentation/metrics';
import { executeWorkload } from '../harness/workload-executor';
import type {
  VariantId, WorkloadId, ControlDensityId, SceneSize,
  SceneModel, RunMetrics, ViewportState, UpdateEvent, BenchmarkRunConfig,
} from '../../types';

import SvgRenderer from '../variants/svg-only/SvgRenderer.vue';
import KonvaRenderer from '../variants/konva-only/KonvaRenderer.vue';

const props = defineProps<{ variantId: string }>();
const route = useRoute();
const store = useBenchmarkStore();

const variantConfig = computed(() => VARIANTS[props.variantId as VariantId]);

const selectedWorkload = ref<WorkloadId>('W-PAN');
const selectedSceneSize = ref<SceneSize>('large');
const selectedDensity = ref<ControlDensityId>('C-0');
const isExecuting = ref(false);
const lastRunMetrics = ref<RunMetrics | null>(null);

const rendererRef = ref<InstanceType<typeof SvgRenderer> | InstanceType<typeof KonvaRenderer>>();
const viewportRef = ref<HTMLDivElement>();

// Live FPS tracking
const liveFps = ref(60);
const liveP95 = ref(0);
const liveDropped = ref(0);
const liveFrameSampler = new FrameSampler();

const workloadOptions = WORKLOAD_IDS.map(id => ({ id, label: WORKLOAD_LABELS[id] }));
const densityOptions = CONTROL_DENSITY_IDS.map(id => ({
  id,
  label: CONTROL_DENSITIES[id].label,
}));

const currentScene = computed(() => store.scenes[selectedSceneSize.value]);

const fpsClass = computed(() => {
  if (liveFps.value >= 55) return 'good';
  if (liveFps.value >= 40) return 'warn';
  return 'bad';
});

const p95Class = computed(() => {
  if (!lastRunMetrics.value) return '';
  const p95 = lastRunMetrics.value.frameStats.p95;
  if (p95 <= 16.7) return 'good';
  if (p95 <= 25) return 'warn';
  return 'bad';
});

// Live FPS update loop
let fpsInterval: ReturnType<typeof setInterval>;

onMounted(() => {
  liveFrameSampler.start();
  fpsInterval = setInterval(() => {
    const samples = liveFrameSampler.getSamples();
    const recent = samples.slice(-60);
    if (recent.length > 0) {
      const avgDelta = recent.reduce((s, f) => s + f.deltaMs, 0) / recent.length;
      liveFps.value = Math.round(1000 / avgDelta);
      const sorted = [...recent.map(f => f.deltaMs)].sort((a, b) => a - b);
      liveP95.value = sorted[Math.floor(sorted.length * 0.95)] ?? 0;
      liveDropped.value = recent.filter(f => f.deltaMs > 33).length;
    }
  }, 500);

  // Auto-run if query param present
  if (route.query.autoRun) {
    setTimeout(() => executeCurrentWorkload(), 500);
  }
});

onUnmounted(() => {
  liveFrameSampler.stop();
  clearInterval(fpsInterval);
});

function onElementClick(id: string) {
  // Tracked by latency instrumentation
}

function onViewportChange(state: ViewportState) {
  // Tracked by frame sampler
}

async function executeCurrentWorkload() {
  if (isExecuting.value || !rendererRef.value) return;
  isExecuting.value = true;

  const collector = new MetricsCollector();
  const config: BenchmarkRunConfig = {
    variantId: props.variantId as VariantId,
    workloadId: selectedWorkload.value,
    controlDensity: selectedDensity.value,
    sceneSize: selectedSceneSize.value,
    runIndex: 0,
    warmUpMs: 500,
    isWarmUp: false,
  };
  collector.configure(config);

  // Build workload context
  const renderer = rendererRef.value;
  const ctx = {
    scene: currentScene.value,
    smallScene: store.scenes.small,
    applyUpdates: (events: UpdateEvent[]) => renderer.applyUpdates(events),
    setViewport: (state: ViewportState) => renderer.setViewport(state),
    renderScene: async (scene: SceneModel) => {
      // Scene is reactive via prop, switching is handled by changing selectedSceneSize
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
    },
    clearScene: () => renderer.clearState(),
    simulateClick: (elementId: string) => {
      // Simulate via the instrumentation
      const mid = collector.latencyTracker.begin('clickHighlight');
      renderer.selectedId.value = elementId;
      collector.latencyTracker.endAfterPaint(mid);
    },
  };

  // Warm up
  await new Promise(r => setTimeout(r, 500));

  // Execute
  collector.startCollection();
  collector.memoryProfiler.startPeriodic(2000);

  const extra = await executeWorkload(selectedWorkload.value, ctx);

  const metrics = collector.stopCollection();
  if (extra.initialRenderMs) collector.recordInitialRender(extra.initialRenderMs);
  if (extra.subDiagramSwitchMs) collector.recordSubDiagramSwitch(extra.subDiagramSwitchMs);

  lastRunMetrics.value = metrics;
  store.addResults([metrics]);

  isExecuting.value = false;
}

async function executeQuickSuite() {
  const quickWorkloads: WorkloadId[] = ['W-INIT', 'W-PAN', 'W-ZOOM', 'W-LIVE-MED', 'W-ALARM'];

  for (const wl of quickWorkloads) {
    selectedWorkload.value = wl;
    await new Promise(r => setTimeout(r, 300));
    await executeCurrentWorkload();
    await new Promise(r => setTimeout(r, 500));
  }
}
</script>

<style scoped>
.benchmark-view {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.control-bar {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 8px 16px;
  background: #181a22;
  border-bottom: 1px solid #2a2d38;
  flex-shrink: 0;
  overflow-x: auto;
}

.btn-back {
  padding: 5px 12px;
  border: 1px solid #2a2d38;
  border-radius: 5px;
  background: transparent;
  color: #8b90a0;
  cursor: pointer;
  font-size: 12px;
  white-space: nowrap;
}

.variant-info {
  display: flex;
  align-items: center;
  gap: 8px;
  white-space: nowrap;
}

.variant-badge {
  width: 24px;
  height: 24px;
  border-radius: 5px;
  background: #5b8def;
  color: #fff;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 12px;
}

.variant-name {
  font-size: 13px;
  font-weight: 600;
  color: #c5cad6;
}

.controls-group {
  display: flex;
  gap: 6px;
  align-items: center;
}

.select-input {
  padding: 5px 8px;
  border: 1px solid #2a2d38;
  border-radius: 5px;
  background: #1e2029;
  color: #c5cad6;
  font-size: 11px;
}

.btn-run, .btn-run-all {
  padding: 5px 14px;
  border: none;
  border-radius: 5px;
  font-size: 11px;
  font-weight: 600;
  cursor: pointer;
  white-space: nowrap;
}

.btn-run {
  background: #5b8def;
  color: #fff;
}

.btn-run-all {
  background: rgba(171, 71, 188, 0.2);
  color: #BA68C8;
}

.btn-run:disabled, .btn-run-all:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.live-metrics {
  display: flex;
  gap: 14px;
  margin-left: auto;
}

.metric {
  display: flex;
  flex-direction: column;
  align-items: center;
}

.metric-label {
  font-size: 9px;
  color: #6b7084;
  text-transform: uppercase;
  letter-spacing: 0.05em;
}

.metric-value {
  font-size: 14px;
  font-weight: 700;
  font-variant-numeric: tabular-nums;
}

.metric-value.good { color: #66BB6A; }
.metric-value.warn { color: #FFA726; }
.metric-value.bad { color: #EF5350; }

.renderer-viewport {
  flex: 1;
  position: relative;
  overflow: hidden;
}

/* Results panel */
.results-panel {
  padding: 12px 16px;
  background: #181a22;
  border-top: 1px solid #2a2d38;
  flex-shrink: 0;
}

.results-panel h3 {
  font-size: 12px;
  font-weight: 600;
  color: #8b90a0;
  margin-bottom: 8px;
}

.results-grid {
  display: flex;
  gap: 20px;
}

.result-item {
  display: flex;
  flex-direction: column;
}

.res-label {
  font-size: 9px;
  color: #6b7084;
  text-transform: uppercase;
}

.res-value {
  font-size: 13px;
  font-weight: 600;
  color: #c5cad6;
  font-variant-numeric: tabular-nums;
}

.res-value.good { color: #66BB6A; }
.res-value.warn { color: #FFA726; }
.res-value.bad { color: #EF5350; }
</style>
