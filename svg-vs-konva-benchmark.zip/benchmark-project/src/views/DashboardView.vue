<template>
  <div class="dashboard">
    <header class="dash-header">
      <h1>Benchmark Control Panel</h1>
      <p class="subtitle">SVG vs Vue Konva · Electron + Vue 3 + TypeScript · Industrial Monitoring</p>
    </header>

    <!-- Scene Info -->
    <section class="card scene-card">
      <h2>Scene Model</h2>
      <div class="scene-selector">
        <button
          v-for="size in sceneSizes"
          :key="size"
          :class="['scene-btn', { active: store.activeSceneSize === size }]"
          @click="store.activeSceneSize = size"
        >
          {{ size.charAt(0).toUpperCase() + size.slice(1) }}
          <span class="count">({{ store.scenes[size].meta.totalElements }} elements)</span>
        </button>
      </div>
      <div class="scene-meta">
        <div v-for="(count, cat) in store.activeScene.meta.elementCounts" :key="cat" class="meta-item">
          <span class="meta-label">{{ cat }}</span>
          <span class="meta-value">{{ count }}</span>
        </div>
        <div class="meta-item">
          <span class="meta-label">Canvas</span>
          <span class="meta-value">{{ store.activeScene.bounds.width }}×{{ store.activeScene.bounds.height }}</span>
        </div>
      </div>
    </section>

    <!-- Variant Grid -->
    <section class="card">
      <h2>Benchmark Variants</h2>
      <div class="variant-grid">
        <div
          v-for="variant in variants"
          :key="variant.id"
          class="variant-card"
          :class="{ running: runningVariant === variant.id }"
        >
          <div class="variant-header">
            <span class="variant-id">{{ variant.id }}</span>
            <span class="variant-label">{{ variant.label }}</span>
          </div>
          <div class="variant-tags">
            <span class="tag" :class="variant.renderer">{{ variant.renderer.toUpperCase() }}</span>
            <span class="tag" :class="variant.controlStrategy">{{ variant.controlStrategy }}</span>
          </div>
          <div class="variant-actions">
            <button class="btn btn-preview" @click="previewVariant(variant.id)">Preview</button>
            <button class="btn btn-run" @click="runQuickBenchmark(variant.id)" :disabled="isRunning">
              {{ runningVariant === variant.id ? 'Running...' : 'Quick Bench' }}
            </button>
          </div>
          <div v-if="getVariantSummary(variant.id)" class="variant-result">
            <span class="result-p95">p95: {{ getVariantSummary(variant.id)!.toFixed(1) }}ms</span>
          </div>
        </div>
      </div>
    </section>

    <!-- Quick Actions -->
    <section class="card">
      <h2>Benchmark Actions</h2>
      <div class="action-grid">
        <button class="btn btn-primary btn-lg" @click="runFullComparison" :disabled="isRunning">
          Run Full A vs B Comparison
        </button>
        <button class="btn btn-secondary btn-lg" @click="runControlDensityTest" :disabled="isRunning">
          Run Control Density Test (C vs D)
        </button>
        <button class="btn btn-accent btn-lg" @click="runAllVariants" :disabled="isRunning">
          Run All 6 Variants
        </button>
        <button class="btn btn-outline btn-lg" @click="store.downloadCSV()" :disabled="store.allResults.length === 0">
          Export CSV ({{ store.allResults.length }} results)
        </button>
        <button class="btn btn-danger btn-lg" @click="store.clearResults()" :disabled="store.allResults.length === 0">
          Clear All Results
        </button>
      </div>
    </section>

    <!-- Progress -->
    <section v-if="isRunning" class="card progress-card">
      <h2>Benchmark Progress</h2>
      <div class="progress-info">
        <div class="progress-bar-container">
          <div class="progress-bar" :style="{ width: progressPercent + '%' }"></div>
        </div>
        <p>{{ progressText }}</p>
      </div>
    </section>

    <!-- Configuration -->
    <section class="card">
      <h2>Run Configuration</h2>
      <div class="config-grid">
        <div class="config-item">
          <label>Runs per config</label>
          <input type="number" v-model.number="runConfig.runsPerConfig" min="3" max="50" class="config-input" />
        </div>
        <div class="config-item">
          <label>Warm-up runs</label>
          <input type="number" v-model.number="runConfig.warmUpRuns" min="1" max="10" class="config-input" />
        </div>
        <div class="config-item">
          <label>Warm-up delay (ms)</label>
          <input type="number" v-model.number="runConfig.warmUpMs" min="100" max="2000" step="100" class="config-input" />
        </div>
      </div>
    </section>
  </div>
</template>

<script setup lang="ts">
import { ref, reactive, computed } from 'vue';
import { useRouter } from 'vue-router';
import { useBenchmarkStore } from '../stores/benchmark';
import { VARIANTS, VARIANT_IDS, SCENE_SIZES } from '../shared/constants';
import type { VariantId, SceneSize } from '../../types';

const router = useRouter();
const store = useBenchmarkStore();

const variants = Object.values(VARIANTS);
const sceneSizes = SCENE_SIZES;
const isRunning = ref(false);
const runningVariant = ref<VariantId | null>(null);
const progressPercent = ref(0);
const progressText = ref('');

const runConfig = reactive({
  runsPerConfig: 10,
  warmUpRuns: 2,
  warmUpMs: 500,
});

function previewVariant(variantId: VariantId) {
  router.push({ name: 'benchmark', params: { variantId } });
}

function getVariantSummary(variantId: VariantId): number | null {
  return store.getAggregatedP95FrameTime(variantId, 'W-PAN', 'C-0', store.activeSceneSize);
}

async function runQuickBenchmark(variantId: VariantId) {
  isRunning.value = true;
  runningVariant.value = variantId;
  progressText.value = `Running quick benchmark for Variant ${variantId}...`;

  // Navigate to the benchmark view which will execute the workloads
  router.push({
    name: 'benchmark',
    params: { variantId },
    query: { autoRun: 'quick' },
  });

  isRunning.value = false;
  runningVariant.value = null;
}

async function runFullComparison() {
  isRunning.value = true;
  progressText.value = 'Running full A vs B comparison...';
  progressPercent.value = 0;

  for (const variantId of ['A', 'B'] as VariantId[]) {
    runningVariant.value = variantId;
    progressPercent.value = variantId === 'A' ? 25 : 75;
    progressText.value = `Running Variant ${variantId}...`;

    router.push({
      name: 'benchmark',
      params: { variantId },
      query: { autoRun: 'full' },
    });

    // Wait for navigation and execution
    await new Promise(resolve => setTimeout(resolve, 2000));
  }

  progressPercent.value = 100;
  progressText.value = 'Comparison complete!';
  isRunning.value = false;
  runningVariant.value = null;
}

async function runControlDensityTest() {
  isRunning.value = true;
  progressText.value = 'Running control density test (C vs D)...';
  router.push({
    name: 'benchmark',
    params: { variantId: 'C' },
    query: { autoRun: 'density' },
  });
  isRunning.value = false;
}

async function runAllVariants() {
  isRunning.value = true;
  progressText.value = 'Running all 6 variants...';
  router.push({
    name: 'benchmark',
    params: { variantId: 'A' },
    query: { autoRun: 'all' },
  });
  isRunning.value = false;
}
</script>

<style scoped>
.dashboard {
  padding: 24px 32px;
  max-width: 1200px;
  margin: 0 auto;
}

.dash-header {
  margin-bottom: 28px;
}

.dash-header h1 {
  font-size: 22px;
  font-weight: 700;
  color: #e1e4ea;
}

.subtitle {
  font-size: 13px;
  color: #6b7084;
  margin-top: 4px;
}

.card {
  background: #181a22;
  border: 1px solid #2a2d38;
  border-radius: 10px;
  padding: 20px 24px;
  margin-bottom: 20px;
}

.card h2 {
  font-size: 15px;
  font-weight: 600;
  color: #c5cad6;
  margin-bottom: 16px;
}

/* Scene selector */
.scene-selector {
  display: flex;
  gap: 8px;
  margin-bottom: 16px;
}

.scene-btn {
  padding: 8px 16px;
  border: 1px solid #2a2d38;
  border-radius: 6px;
  background: transparent;
  color: #8b90a0;
  cursor: pointer;
  font-size: 13px;
  transition: all 0.15s;
}

.scene-btn.active {
  background: rgba(91, 141, 239, 0.12);
  border-color: #5b8def;
  color: #5b8def;
}

.scene-btn .count {
  font-size: 11px;
  opacity: 0.7;
}

.scene-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
}

.meta-item {
  background: #1e2029;
  padding: 6px 12px;
  border-radius: 6px;
  font-size: 12px;
}

.meta-label {
  color: #6b7084;
  margin-right: 6px;
}

.meta-value {
  color: #c5cad6;
  font-weight: 600;
}

/* Variant grid */
.variant-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 12px;
}

.variant-card {
  background: #1e2029;
  border: 1px solid #2a2d38;
  border-radius: 8px;
  padding: 16px;
  transition: border-color 0.2s;
}

.variant-card.running {
  border-color: #5b8def;
  box-shadow: 0 0 12px rgba(91, 141, 239, 0.15);
}

.variant-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 10px;
}

.variant-id {
  width: 28px;
  height: 28px;
  border-radius: 6px;
  background: #2a2d38;
  display: flex;
  align-items: center;
  justify-content: center;
  font-weight: 700;
  font-size: 13px;
  color: #5b8def;
}

.variant-label {
  font-size: 13px;
  font-weight: 600;
  color: #c5cad6;
}

.variant-tags {
  display: flex;
  gap: 6px;
  margin-bottom: 12px;
}

.tag {
  padding: 2px 8px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 600;
  text-transform: uppercase;
}

.tag.svg { background: rgba(76, 175, 80, 0.15); color: #66BB6A; }
.tag.konva { background: rgba(91, 141, 239, 0.15); color: #5b8def; }
.tag.none { background: rgba(158, 158, 158, 0.15); color: #9E9E9E; }
.tag.overlay { background: rgba(255, 152, 0, 0.15); color: #FFA726; }
.tag.pseudo { background: rgba(171, 71, 188, 0.15); color: #BA68C8; }

.variant-actions {
  display: flex;
  gap: 8px;
}

.variant-result {
  margin-top: 10px;
  padding-top: 10px;
  border-top: 1px solid #2a2d38;
}

.result-p95 {
  font-size: 12px;
  font-weight: 600;
  color: #66BB6A;
}

/* Buttons */
.btn {
  padding: 6px 14px;
  border-radius: 6px;
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  border: 1px solid transparent;
  transition: all 0.15s;
}

.btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
}

.btn-preview {
  background: transparent;
  border-color: #2a2d38;
  color: #8b90a0;
}

.btn-preview:hover:not(:disabled) {
  border-color: #5b8def;
  color: #5b8def;
}

.btn-run {
  background: rgba(91, 141, 239, 0.15);
  color: #5b8def;
}

.btn-run:hover:not(:disabled) {
  background: rgba(91, 141, 239, 0.25);
}

.btn-primary {
  background: #5b8def;
  color: #fff;
}

.btn-primary:hover:not(:disabled) {
  background: #4a7de0;
}

.btn-secondary {
  background: rgba(255, 152, 0, 0.15);
  color: #FFA726;
}

.btn-accent {
  background: rgba(171, 71, 188, 0.15);
  color: #BA68C8;
}

.btn-outline {
  background: transparent;
  border-color: #2a2d38;
  color: #8b90a0;
}

.btn-danger {
  background: rgba(244, 67, 54, 0.15);
  color: #EF5350;
}

.btn-lg {
  padding: 10px 20px;
  font-size: 13px;
}

.action-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
}

/* Config */
.config-grid {
  display: flex;
  gap: 20px;
}

.config-item label {
  display: block;
  font-size: 11px;
  color: #6b7084;
  margin-bottom: 4px;
}

.config-input {
  width: 100px;
  padding: 6px 10px;
  border: 1px solid #2a2d38;
  border-radius: 6px;
  background: #1e2029;
  color: #c5cad6;
  font-size: 13px;
}

/* Progress */
.progress-card {
  border-color: #5b8def;
}

.progress-bar-container {
  height: 6px;
  background: #2a2d38;
  border-radius: 3px;
  overflow: hidden;
  margin-bottom: 10px;
}

.progress-bar {
  height: 100%;
  background: #5b8def;
  border-radius: 3px;
  transition: width 0.3s;
}

.progress-info p {
  font-size: 12px;
  color: #8b90a0;
}
</style>
