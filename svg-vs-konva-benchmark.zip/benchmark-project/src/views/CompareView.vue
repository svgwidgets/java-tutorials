<template>
  <div class="compare-view">
    <header class="compare-header">
      <h1>Analysis &amp; Decision Framework</h1>
      <p class="subtitle">Engineering decision based on measured data (§14–§15 of benchmark plan)</p>
    </header>

    <div v-if="store.allResults.length === 0" class="empty-state">
      <p>Run benchmarks first to see analysis.</p>
    </div>

    <template v-else>
      <!-- Summary Cards -->
      <div class="summary-grid">
        <div class="summary-card" v-for="s in summaries" :key="s.workload">
          <div class="summary-title">{{ s.label }}</div>
          <div class="summary-values">
            <div class="sv-item">
              <span class="sv-label">SVG p95</span>
              <span class="sv-value" :class="s.svgClass">{{ s.svgP95?.toFixed(1) ?? '—' }} ms</span>
            </div>
            <div class="sv-item">
              <span class="sv-label">Konva p95</span>
              <span class="sv-value" :class="s.konvaClass">{{ s.konvaP95?.toFixed(1) ?? '—' }} ms</span>
            </div>
          </div>
          <div class="summary-verdict">
            <span :class="['magnitude', s.magnitude]">{{ s.magnitude }}</span>
            <span v-if="s.winner" :class="['winner', s.winner]">
              {{ s.winner === 'tie' ? 'Tie' : s.winner.toUpperCase() + ' wins' }}
            </span>
          </div>
        </div>
      </div>

      <!-- Decision Tree -->
      <section class="card">
        <h2>Decision Tree (§15)</h2>
        <div class="decision-tree">
          <div class="decision-node" v-for="(d, i) in decisions" :key="i">
            <div class="decision-condition">{{ d.condition }}</div>
            <div class="decision-result" :class="d.resultClass">{{ d.result }}</div>
            <div class="decision-evidence">{{ d.evidence }}</div>
          </div>
        </div>
      </section>

      <!-- Bottleneck Analysis -->
      <section class="card">
        <h2>Bottleneck Attribution (§14.4)</h2>
        <div class="analysis-text">
          <p v-for="(finding, i) in findings" :key="i" class="finding">
            <span class="finding-num">{{ i + 1 }}.</span>
            {{ finding }}
          </p>
        </div>
      </section>

      <!-- Recommendation Template -->
      <section class="card recommendation-card">
        <h2>Architecture Review Summary Template (§18)</h2>
        <div class="recommendation-text">
          <p><strong>Benchmark scope:</strong> Compared SVG vs Vue Konva across
            {{ uniqueWorkloads.length }} workloads on {{ store.activeSceneSize }} scene
            ({{ store.activeScene.meta.totalElements }} elements).
            Total {{ store.allResults.length }} measured runs.</p>

          <p><strong>Key finding — Graphics-only:</strong>
            {{ graphicsFinding }}</p>

          <p><strong>Key finding — Interaction:</strong>
            Both renderers {{ interactionFinding }}</p>

          <p><strong>Recommendation:</strong>
            {{ recommendation }}</p>
        </div>
      </section>
    </template>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { useBenchmarkStore } from '../stores/benchmark';
import { WORKLOAD_LABELS, THRESHOLDS, evaluateThreshold } from '../shared/constants';
import type { WorkloadId } from '../../types';

const store = useBenchmarkStore();

const ANALYZED_WORKLOADS: { id: WorkloadId; label: string }[] = [
  { id: 'W-PAN', label: 'Pan' },
  { id: 'W-ZOOM', label: 'Zoom' },
  { id: 'W-LIVE-MED', label: 'Live Update (Realistic)' },
  { id: 'W-LIVE-HI', label: 'Live Update (Burst)' },
  { id: 'W-ALARM', label: 'Alarm Burst' },
];

const summaries = computed(() =>
  ANALYZED_WORKLOADS.map(wl => {
    const cmp = store.getComparisonSummary(wl.id);
    const svgP95 = cmp?.svgP95 ?? null;
    const konvaP95 = cmp?.konvaP95 ?? null;

    return {
      workload: wl.id,
      label: wl.label,
      svgP95,
      konvaP95,
      svgClass: svgP95 !== null ? evaluateThreshold(svgP95, THRESHOLDS.p95FrameMs) : '',
      konvaClass: konvaP95 !== null ? evaluateThreshold(konvaP95, THRESHOLDS.p95FrameMs) : '',
      magnitude: cmp?.magnitude ?? 'unknown',
      winner: cmp ? (cmp.magnitude === 'negligible' ? 'tie' : cmp.winner) : null,
      diffPct: cmp?.diffPercent ?? 0,
    };
  })
);

const decisions = computed(() => {
  const d: { condition: string; result: string; resultClass: string; evidence: string }[] = [];

  const liveMed = store.getComparisonSummary('W-LIVE-MED');
  const pan = store.getComparisonSummary('W-PAN');

  if (liveMed && liveMed.magnitude === 'significant' || liveMed?.magnitude === 'dominant') {
    d.push({
      condition: 'Konva p95 significantly lower than SVG at W-LIVE-MED',
      result: 'Choose Konva for Monitor module',
      resultClass: 'konva',
      evidence: `SVG: ${liveMed.svgP95.toFixed(1)}ms, Konva: ${liveMed.konvaP95.toFixed(1)}ms (${liveMed.diffPercent.toFixed(1)}% difference)`,
    });
  } else if (liveMed && liveMed.magnitude === 'negligible') {
    d.push({
      condition: 'Performance difference < 10% at realistic load',
      result: 'Choose based on maintainability, not performance',
      resultClass: 'neutral',
      evidence: `Difference: ${Math.abs(liveMed.diffPercent).toFixed(1)}% — not architecture-defining`,
    });
  }

  if (pan) {
    d.push({
      condition: `Pan workload: ${pan.winner} wins by ${Math.abs(pan.diffPercent).toFixed(1)}%`,
      result: pan.magnitude === 'negligible' ? 'Pan performance parity' : `${pan.winner} better for pan-heavy workflows`,
      resultClass: pan.magnitude === 'negligible' ? 'neutral' : pan.winner,
      evidence: `SVG: ${pan.svgP95.toFixed(1)}ms, Konva: ${pan.konvaP95.toFixed(1)}ms`,
    });
  }

  d.push({
    condition: 'Control overlay density > C-30 during pan/zoom',
    result: 'Use contextual controls (C-CTX) regardless of renderer',
    resultClass: 'neutral',
    evidence: 'Control density analysis from density benchmark required',
  });

  return d;
});

const findings = computed(() => {
  const f: string[] = [];

  const liveMed = store.getComparisonSummary('W-LIVE-MED');
  if (liveMed) {
    f.push(
      `At realistic update rate (20/s), ${liveMed.winner} delivers ${Math.abs(liveMed.diffPercent).toFixed(1)}% lower p95 frame time. This is classified as ${liveMed.magnitude}.`
    );
  }

  f.push('DOM overlay repositioning cost scales linearly with visible control count. Run the C-10/C-30/C-60 density test to find the crossover point.');
  f.push('Long-session stability (W-LONG) must confirm no monotonic memory growth before either renderer is approved for the monitor module.');

  return f;
});

const uniqueWorkloads = computed(() => {
  const wls = new Set(store.allResults.map(r => r.config.workloadId));
  return [...wls];
});

const graphicsFinding = computed(() => {
  const cmp = store.getComparisonSummary('W-LIVE-MED');
  if (!cmp) return 'Insufficient data — run A vs B comparison first.';
  return `${cmp.winner} achieved ${Math.abs(cmp.diffPercent).toFixed(1)}% lower p95 at realistic load (${cmp.magnitude} difference). SVG: ${cmp.svgP95.toFixed(1)}ms, Konva: ${cmp.konvaP95.toFixed(1)}ms.`;
});

const interactionFinding = computed(() => {
  return 'require click-to-highlight and click-to-control-open latency data from W-INTERACT runs.';
});

const recommendation = computed(() => {
  const cmp = store.getComparisonSummary('W-LIVE-MED');
  if (!cmp) return 'Collect data from full A vs B comparison before making a recommendation.';
  if (cmp.magnitude === 'negligible' || cmp.magnitude === 'minor') {
    return 'Performance difference is not architecture-defining. Recommend choosing based on developer familiarity, debugging ergonomics, and maintainability. SVG offers DOM-native interaction and CSS styling; Konva offers layered canvas with potentially better scaling at higher element counts.';
  }
  return `Recommend ${cmp.winner} for the Monitor module based on ${cmp.magnitude} performance advantage at realistic load. Verify with long-session stability test before final commitment.`;
});
</script>

<style scoped>
.compare-view {
  padding: 24px 32px;
  max-width: 1200px;
  margin: 0 auto;
}

.compare-header h1 {
  font-size: 22px;
  font-weight: 700;
}

.subtitle {
  font-size: 13px;
  color: #6b7084;
  margin-top: 4px;
  margin-bottom: 24px;
}

.empty-state {
  text-align: center;
  padding: 60px;
  color: #6b7084;
}

.summary-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 12px;
  margin-bottom: 24px;
}

.summary-card {
  background: #181a22;
  border: 1px solid #2a2d38;
  border-radius: 10px;
  padding: 16px;
}

.summary-title {
  font-size: 12px;
  font-weight: 600;
  color: #8b90a0;
  margin-bottom: 12px;
}

.summary-values {
  display: flex;
  gap: 16px;
  margin-bottom: 10px;
}

.sv-item { display: flex; flex-direction: column; }
.sv-label { font-size: 9px; color: #6b7084; text-transform: uppercase; }
.sv-value { font-size: 16px; font-weight: 700; font-variant-numeric: tabular-nums; }
.sv-value.pass { color: #66BB6A; }
.sv-value.warning { color: #FFA726; }
.sv-value.fail { color: #EF5350; }

.summary-verdict {
  display: flex;
  align-items: center;
  gap: 8px;
}

.magnitude {
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 3px;
  text-transform: uppercase;
  font-weight: 600;
}

.magnitude.negligible { background: rgba(158,158,158,0.15); color: #9E9E9E; }
.magnitude.minor { background: rgba(255,152,0,0.15); color: #FFA726; }
.magnitude.significant { background: rgba(91,141,239,0.15); color: #5b8def; }
.magnitude.dominant { background: rgba(244,67,54,0.15); color: #EF5350; }

.winner {
  font-size: 11px;
  font-weight: 600;
}
.winner.svg { color: #66BB6A; }
.winner.konva { color: #5b8def; }
.winner.tie { color: #9E9E9E; }

.card {
  background: #181a22;
  border: 1px solid #2a2d38;
  border-radius: 10px;
  padding: 20px 24px;
  margin-bottom: 20px;
}

.card h2 {
  font-size: 15px;
  font-weight: 600;
  color: #c5cad6;
  margin-bottom: 16px;
}

.decision-tree {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.decision-node {
  padding: 14px 16px;
  background: #1e2029;
  border-radius: 8px;
  border-left: 3px solid #2a2d38;
}

.decision-node:has(.decision-result.konva) { border-left-color: #5b8def; }
.decision-node:has(.decision-result.svg) { border-left-color: #66BB6A; }
.decision-node:has(.decision-result.neutral) { border-left-color: #9E9E9E; }

.decision-condition {
  font-size: 12px;
  color: #8b90a0;
  margin-bottom: 6px;
}

.decision-result {
  font-size: 14px;
  font-weight: 600;
  margin-bottom: 4px;
}

.decision-result.konva { color: #5b8def; }
.decision-result.svg { color: #66BB6A; }
.decision-result.neutral { color: #c5cad6; }

.decision-evidence {
  font-size: 11px;
  color: #6b7084;
  font-style: italic;
}

.finding {
  margin-bottom: 10px;
  font-size: 13px;
  color: #c5cad6;
  line-height: 1.5;
}

.finding-num {
  font-weight: 700;
  color: #5b8def;
  margin-right: 6px;
}

.recommendation-card {
  border-color: #5b8def;
}

.recommendation-text {
  font-size: 13px;
  color: #c5cad6;
  line-height: 1.6;
}

.recommendation-text p {
  margin-bottom: 12px;
}

.recommendation-text strong {
  color: #e1e4ea;
}
</style>
