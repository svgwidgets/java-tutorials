import type {
  VariantConfig,
  VariantId,
  WorkloadId,
  ControlDensityId,
  BenchmarkMatrixConfig,
  SceneSize,
} from '../../types';

// ── Variant Definitions (§4) ──
export const VARIANTS: Record<VariantId, VariantConfig> = {
  A: { id: 'A', renderer: 'svg',   controlStrategy: 'none',    label: 'SVG Only' },
  B: { id: 'B', renderer: 'konva', controlStrategy: 'none',    label: 'Konva Only' },
  C: { id: 'C', renderer: 'svg',   controlStrategy: 'overlay', label: 'SVG + DOM Overlay' },
  D: { id: 'D', renderer: 'konva', controlStrategy: 'overlay', label: 'Konva + DOM Overlay' },
  E: { id: 'E', renderer: 'svg',   controlStrategy: 'pseudo',  label: 'SVG + Pseudo Controls' },
  F: { id: 'F', renderer: 'konva', controlStrategy: 'pseudo',  label: 'Konva + Pseudo Controls' },
};

export const VARIANT_IDS: VariantId[] = ['A', 'B', 'C', 'D', 'E', 'F'];

// ── Workload Definitions (§7) ──
export const WORKLOAD_IDS: WorkloadId[] = [
  'W-INIT',
  'W-SWITCH',
  'W-PAN',
  'W-ZOOM',
  'W-LIVE-LO',
  'W-LIVE-MED',
  'W-LIVE-HI',
  'W-LIVE-STRESS',
  'W-ALARM',
  'W-INTERACT',
  'W-LONG',
  'W-MIXED',
];

export const WORKLOAD_LABELS: Record<WorkloadId, string> = {
  'W-INIT':        'Initial Render',
  'W-SWITCH':      'Sub-Diagram Switch',
  'W-PAN':         'Pan (3000px / 3s)',
  'W-ZOOM':        'Zoom (100%→30%→100%→200%→100%)',
  'W-LIVE-LO':     'Live Update – Low (5/s)',
  'W-LIVE-MED':    'Live Update – Realistic (20/s)',
  'W-LIVE-HI':     'Live Update – Burst (60/s)',
  'W-LIVE-STRESS': 'Live Update – Stress (120/s)',
  'W-ALARM':       'Alarm Burst (40 simultaneous)',
  'W-INTERACT':    'Interaction Under Load',
  'W-LONG':        'Long-Session Stability (4h sim)',
  'W-MIXED':       'Mixed Operator Workflow',
};

// ── Control Density Definitions (§6) ──
export const CONTROL_DENSITY_IDS: ControlDensityId[] = [
  'C-0', 'C-10', 'C-30', 'C-60', 'C-CTX', 'C-PSEUDO',
];

export interface ControlDensityConfig {
  id: ControlDensityId;
  visibleCount: number;
  strategy: 'none' | 'overlay' | 'contextual' | 'pseudo';
  label: string;
}

export const CONTROL_DENSITIES: Record<ControlDensityId, ControlDensityConfig> = {
  'C-0':      { id: 'C-0',      visibleCount: 0,   strategy: 'none',        label: 'No controls' },
  'C-10':     { id: 'C-10',     visibleCount: 10,  strategy: 'overlay',     label: '10 real overlays' },
  'C-30':     { id: 'C-30',     visibleCount: 30,  strategy: 'overlay',     label: '30 real overlays' },
  'C-60':     { id: 'C-60',     visibleCount: 60,  strategy: 'overlay',     label: '60 real overlays' },
  'C-CTX':    { id: 'C-CTX',    visibleCount: 3,   strategy: 'contextual',  label: 'Contextual (1-3)' },
  'C-PSEUDO': { id: 'C-PSEUDO', visibleCount: 30,  strategy: 'pseudo',      label: '30 pseudo controls' },
};

// ── Scene Sizes (§5) ──
export const SCENE_SIZES: SceneSize[] = ['small', 'medium', 'large'];

// ── Default Benchmark Matrix (§9.3) ──
export const DEFAULT_MATRIX: BenchmarkMatrixConfig = {
  runsPerConfig: 10,
  warmUpRuns: 2,
  warmUpMs: 500,
  variants: Object.values(VARIANTS),
  workloads: WORKLOAD_IDS,
  controlDensities: CONTROL_DENSITY_IDS,
  sceneSizes: SCENE_SIZES,
};

// ── Acceptance Thresholds (§12) ──
export interface ThresholdLevel {
  acceptable: number;
  warning: number;
  fail: number;
}

export const THRESHOLDS = {
  p95FrameMs:          { acceptable: 16.7, warning: 25,   fail: 33   } as ThresholdLevel,
  p99FrameMs:          { acceptable: 25,   warning: 33,   fail: 50   } as ThresholdLevel,
  droppedFramesPerMin: { acceptable: 1,    warning: 5,    fail: 10   } as ThresholdLevel,
  clickHighlightMs:    { acceptable: 50,   warning: 100,  fail: 200  } as ThresholdLevel,
  clickControlOpenMs:  { acceptable: 100,  warning: 200,  fail: 400  } as ThresholdLevel,
  subDiagramSwitchMs:  { acceptable: 200,  warning: 400,  fail: 800  } as ThresholdLevel,
  memoryGrowthPct:     { acceptable: 15,   warning: 30,   fail: 50   } as ThresholdLevel,
  cpuPercent:          { acceptable: 30,   warning: 60,   fail: 90   } as ThresholdLevel,
};

export type ThresholdStatus = 'pass' | 'warning' | 'fail';

export function evaluateThreshold(value: number, threshold: ThresholdLevel): ThresholdStatus {
  if (value <= threshold.acceptable) return 'pass';
  if (value <= threshold.warning) return 'warning';
  return 'fail';
}

// ── Pan/Zoom Workload Parameters ──
export const PAN_CONFIG = {
  distancePx: 3000,
  durationMs: 3000,
  direction: 'horizontal' as const,
};

export const ZOOM_CONFIG = {
  phases: [
    { from: 1.0, to: 0.3, durationMs: 1000 },
    { from: 0.3, to: 1.0, durationMs: 1000 },
    { from: 1.0, to: 2.0, durationMs: 1000 },
    { from: 2.0, to: 1.0, durationMs: 1000 },
  ],
};
