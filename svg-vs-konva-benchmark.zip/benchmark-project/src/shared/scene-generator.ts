/**
 * Canonical Scene Model Generator
 *
 * Generates deterministic, reproducible P&ID scene models at three scale tiers.
 * Both SVG and Konva variants MUST consume the identical output from this generator.
 *
 * Element counts per tier:
 *   Small:  122 total (12 equipment, 30 sensors, 35 connectors, 20 labels, 15 alarm, 10 command)
 *   Medium: 315 total (30 equipment, 80 sensors, 90 connectors, 55 labels, 35 alarm, 25 command)
 *   Large:  700 total (60 equipment, 180 sensors, 200 connectors, 120 labels, 80 alarm, 60 command)
 */

import type {
  SceneModel,
  SceneElement,
  SceneSize,
  ElementCategory,
  EquipmentSubtype,
  SensorSubtype,
  ControlType,
  AlarmLevel,
  OperationalStatus,
  VisualPrimitive,
  Waypoint,
} from '../../types';

// ── Deterministic PRNG (Mulberry32) ──
function mulberry32(seed: number): () => number {
  return () => {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const SCENE_CONFIGS: Record<SceneSize, {
  equipment: number; sensor: number; connector: number;
  label: number; alarm: number; command: number;
  canvasWidth: number; canvasHeight: number;
}> = {
  small:  { equipment: 12, sensor: 30, connector: 35, label: 20, alarm: 15, command: 10, canvasWidth: 2400, canvasHeight: 1600 },
  medium: { equipment: 30, sensor: 80, connector: 90, label: 55, alarm: 35, command: 25, canvasWidth: 4800, canvasHeight: 3200 },
  large:  { equipment: 60, sensor: 180, connector: 200, label: 120, alarm: 80, command: 60, canvasWidth: 8000, canvasHeight: 5000 },
};

const EQUIPMENT_SUBTYPES: EquipmentSubtype[] = [
  'pump', 'valve', 'tank', 'heat_exchanger', 'motor', 'compressor', 'filter', 'vessel',
];

const SENSOR_SUBTYPES: SensorSubtype[] = [
  'temperature', 'pressure', 'flow', 'level', 'ph', 'conductivity',
];

const CONTROL_TYPES: ControlType[] = [
  'toggle', 'numeric_stepper', 'text_input', 'dropdown', 'push_button',
];

const STATUS_COLORS: Record<OperationalStatus, { fill: string; stroke: string }> = {
  running:     { fill: '#4CAF50', stroke: '#2E7D32' },
  stopped:     { fill: '#9E9E9E', stroke: '#616161' },
  fault:       { fill: '#F44336', stroke: '#C62828' },
  maintenance: { fill: '#FF9800', stroke: '#E65100' },
  standby:     { fill: '#2196F3', stroke: '#1565C0' },
};

const ALARM_COLORS: Record<AlarmLevel, { fill: string; stroke: string }> = {
  none:      { fill: '#E0E0E0', stroke: '#9E9E9E' },
  info:      { fill: '#BBDEFB', stroke: '#1976D2' },
  warning:   { fill: '#FFF9C4', stroke: '#F9A825' },
  critical:  { fill: '#FFCDD2', stroke: '#D32F2F' },
  emergency: { fill: '#FF1744', stroke: '#B71C1C' },
};

// ── Symbol Primitive Generators (3-5 primitives each) ──

function pumpPrimitives(): VisualPrimitive[] {
  return [
    { type: 'circle', x: 25, y: 25, r: 22, fill: '#E3F2FD', stroke: '#1565C0', strokeWidth: 2 },
    { type: 'polygon', x: 0, y: 0, points: [5, 25, 25, 8, 25, 42], fill: '#1565C0', stroke: '#0D47A1', strokeWidth: 1.5 },
    { type: 'line', x: 0, y: 0, points: [47, 25, 55, 25], fill: 'none', stroke: '#1565C0', strokeWidth: 2 },
    { type: 'rect', x: 47, y: 18, width: 8, height: 14, fill: '#1565C0', stroke: '#0D47A1', strokeWidth: 1 },
  ];
}

function valvePrimitives(): VisualPrimitive[] {
  return [
    { type: 'polygon', x: 0, y: 0, points: [0, 0, 25, 20, 0, 40], fill: '#FFF3E0', stroke: '#E65100', strokeWidth: 2 },
    { type: 'polygon', x: 0, y: 0, points: [50, 0, 25, 20, 50, 40], fill: '#FFF3E0', stroke: '#E65100', strokeWidth: 2 },
    { type: 'line', x: 0, y: 0, points: [25, 20, 25, 0], fill: 'none', stroke: '#E65100', strokeWidth: 2 },
    { type: 'rect', x: 18, y: -8, width: 14, height: 8, fill: '#E65100', stroke: '#BF360C', strokeWidth: 1 },
  ];
}

function tankPrimitives(): VisualPrimitive[] {
  return [
    { type: 'rect', x: 5, y: 10, width: 50, height: 60, fill: '#E8EAF6', stroke: '#283593', strokeWidth: 2 },
    { type: 'ellipse', x: 30, y: 12, rx: 25, ry: 8, fill: '#C5CAE9', stroke: '#283593', strokeWidth: 2 },
    { type: 'ellipse', x: 30, y: 68, rx: 25, ry: 8, fill: '#E8EAF6', stroke: '#283593', strokeWidth: 2 },
    { type: 'rect', x: 15, y: 30, width: 30, height: 20, fill: '#42A5F5', stroke: 'none', strokeWidth: 0 },
    { type: 'line', x: 0, y: 0, points: [5, 50, 55, 50], fill: 'none', stroke: '#1565C0', strokeWidth: 1 },
  ];
}

function heatExchangerPrimitives(): VisualPrimitive[] {
  return [
    { type: 'circle', x: 30, y: 30, r: 28, fill: '#FBE9E7', stroke: '#BF360C', strokeWidth: 2 },
    { type: 'line', x: 0, y: 0, points: [8, 15, 52, 45], fill: 'none', stroke: '#BF360C', strokeWidth: 2 },
    { type: 'line', x: 0, y: 0, points: [8, 45, 52, 15], fill: 'none', stroke: '#BF360C', strokeWidth: 2 },
    { type: 'circle', x: 30, y: 30, r: 4, fill: '#BF360C', stroke: '#8D2304', strokeWidth: 1 },
  ];
}

function motorPrimitives(): VisualPrimitive[] {
  return [
    { type: 'circle', x: 25, y: 25, r: 22, fill: '#E8F5E9', stroke: '#2E7D32', strokeWidth: 2 },
    { type: 'path', x: 0, y: 0, d: 'M 15 18 L 25 25 L 15 32', fill: 'none', stroke: '#2E7D32', strokeWidth: 2.5 },
    { type: 'line', x: 0, y: 0, points: [47, 25, 56, 25], fill: 'none', stroke: '#2E7D32', strokeWidth: 2 },
  ];
}

function compressorPrimitives(): VisualPrimitive[] {
  return [
    { type: 'polygon', x: 0, y: 0, points: [0, 0, 50, 10, 50, 40, 0, 50], fill: '#EDE7F6', stroke: '#4527A0', strokeWidth: 2 },
    { type: 'line', x: 0, y: 0, points: [15, 15, 35, 25, 15, 35], fill: 'none', stroke: '#4527A0', strokeWidth: 2 },
    { type: 'circle', x: 25, y: 25, r: 5, fill: '#4527A0', stroke: '#311B92', strokeWidth: 1 },
  ];
}

function filterPrimitives(): VisualPrimitive[] {
  return [
    { type: 'polygon', x: 0, y: 0, points: [0, 0, 50, 0, 35, 50, 15, 50], fill: '#FFF8E1', stroke: '#F57F17', strokeWidth: 2 },
    { type: 'line', x: 0, y: 0, points: [10, 20, 40, 20], fill: 'none', stroke: '#F57F17', strokeWidth: 1.5 },
    { type: 'line', x: 0, y: 0, points: [12, 30, 38, 30], fill: 'none', stroke: '#F57F17', strokeWidth: 1.5 },
    { type: 'line', x: 0, y: 0, points: [14, 40, 36, 40], fill: 'none', stroke: '#F57F17', strokeWidth: 1.5 },
  ];
}

function vesselPrimitives(): VisualPrimitive[] {
  return [
    { type: 'rect', x: 5, y: 15, width: 50, height: 50, fill: '#ECEFF1', stroke: '#37474F', strokeWidth: 2 },
    { type: 'ellipse', x: 30, y: 17, rx: 25, ry: 10, fill: '#CFD8DC', stroke: '#37474F', strokeWidth: 2 },
    { type: 'ellipse', x: 30, y: 63, rx: 25, ry: 10, fill: '#ECEFF1', stroke: '#37474F', strokeWidth: 2 },
    { type: 'line', x: 0, y: 0, points: [20, 30, 40, 30], fill: 'none', stroke: '#455A64', strokeWidth: 1 },
    { type: 'line', x: 0, y: 0, points: [20, 50, 40, 50], fill: 'none', stroke: '#455A64', strokeWidth: 1 },
  ];
}

const SYMBOL_GENERATORS: Record<EquipmentSubtype, () => VisualPrimitive[]> = {
  pump: pumpPrimitives,
  valve: valvePrimitives,
  tank: tankPrimitives,
  heat_exchanger: heatExchangerPrimitives,
  motor: motorPrimitives,
  compressor: compressorPrimitives,
  filter: filterPrimitives,
  vessel: vesselPrimitives,
};

const SYMBOL_SIZES: Record<EquipmentSubtype, { w: number; h: number }> = {
  pump:           { w: 60, h: 50 },
  valve:          { w: 50, h: 40 },
  tank:           { w: 60, h: 80 },
  heat_exchanger: { w: 60, h: 60 },
  motor:          { w: 56, h: 50 },
  compressor:     { w: 50, h: 50 },
  filter:         { w: 50, h: 50 },
  vessel:         { w: 60, h: 75 },
};

// ── Sensor primitive generator ──

function sensorPrimitives(subtype: SensorSubtype): VisualPrimitive[] {
  const baseColor = {
    temperature: '#E53935',
    pressure: '#1E88E5',
    flow: '#43A047',
    level: '#8E24AA',
    ph: '#FB8C00',
    conductivity: '#00ACC1',
  }[subtype];

  return [
    { type: 'circle', x: 16, y: 16, r: 14, fill: '#FAFAFA', stroke: baseColor, strokeWidth: 2 },
    { type: 'path', x: 0, y: 0, d: 'M 10 22 L 16 12 L 22 22', fill: 'none', stroke: baseColor, strokeWidth: 1.5 },
    { type: 'rect', x: 4, y: 34, width: 24, height: 14, fill: '#FAFAFA', stroke: baseColor, strokeWidth: 1 },
  ];
}

// ── Orthogonal Connector Generator ──

function generateOrthogonalWaypoints(
  sx: number, sy: number, tx: number, ty: number, rand: () => number
): Waypoint[] {
  const waypoints: Waypoint[] = [{ x: sx, y: sy }];
  const midX = (sx + tx) / 2 + (rand() - 0.5) * 40;
  const midY = (sy + ty) / 2 + (rand() - 0.5) * 40;

  // Orthogonal: go horizontal, then vertical, then horizontal
  if (Math.abs(tx - sx) > Math.abs(ty - sy)) {
    waypoints.push({ x: midX, y: sy });
    waypoints.push({ x: midX, y: ty });
  } else {
    waypoints.push({ x: sx, y: midY });
    waypoints.push({ x: tx, y: midY });
  }

  waypoints.push({ x: tx, y: ty });
  return waypoints;
}

// ── Main Generator ──

export function generateScene(size: SceneSize, seed: number = 42): SceneModel {
  const rand = mulberry32(seed);
  const cfg = SCENE_CONFIGS[size];
  const elements: SceneElement[] = [];
  let idCounter = 0;

  const nextId = (prefix: string) => `${prefix}-${String(++idCounter).padStart(4, '0')}`;

  // Grid-based placement to avoid overlaps
  const cols = Math.ceil(Math.sqrt(cfg.equipment * 2));
  const cellW = cfg.canvasWidth / (cols + 1);
  const cellH = cfg.canvasHeight / (Math.ceil(cfg.equipment / cols) + 2);

  // ── Equipment ──
  const equipmentElements: SceneElement[] = [];
  for (let i = 0; i < cfg.equipment; i++) {
    const subtype = EQUIPMENT_SUBTYPES[i % EQUIPMENT_SUBTYPES.length];
    const col = i % cols;
    const row = Math.floor(i / cols);
    const x = cellW * (col + 0.5) + (rand() - 0.5) * cellW * 0.3;
    const y = cellH * (row + 1) + (rand() - 0.5) * cellH * 0.3;
    const sz = SYMBOL_SIZES[subtype];
    const statusKeys = Object.keys(STATUS_COLORS) as OperationalStatus[];
    const status = rand() < 0.7 ? 'running' : statusKeys[Math.floor(rand() * statusKeys.length)];
    const colors = STATUS_COLORS[status];

    const el: SceneElement = {
      id: nextId('EQ'),
      category: 'equipment',
      subtype,
      x: Math.round(x),
      y: Math.round(y),
      width: sz.w,
      height: sz.h,
      rotation: [0, 0, 0, 90][Math.floor(rand() * 4)],
      primitives: SYMBOL_GENERATORS[subtype](),
      label: `${subtype.toUpperCase().slice(0, 3)}-${String(i + 1).padStart(3, '0')}`,
      fill: colors.fill,
      stroke: colors.stroke,
      status,
      alarmLevel: 'none',
      isCommandCapable: false,
      controlEnabled: true,
      visible: true,
      zIndex: 10,
    };
    elements.push(el);
    equipmentElements.push(el);
  }

  // ── Sensors ──
  const sensorElements: SceneElement[] = [];
  for (let i = 0; i < cfg.sensor; i++) {
    const subtype = SENSOR_SUBTYPES[i % SENSOR_SUBTYPES.length];
    // Place sensors near equipment
    const parentEq = equipmentElements[i % equipmentElements.length];
    const offsetX = (rand() - 0.5) * 120 + 70;
    const offsetY = (rand() - 0.5) * 80;
    const value = (rand() * 100).toFixed(1);
    const units = { temperature: '°C', pressure: 'bar', flow: 'm³/h', level: '%', ph: 'pH', conductivity: 'µS/cm' }[subtype];

    const el: SceneElement = {
      id: nextId('SN'),
      category: 'sensor',
      subtype,
      x: Math.round(parentEq.x + offsetX),
      y: Math.round(parentEq.y + offsetY),
      width: 32,
      height: 50,
      rotation: 0,
      primitives: sensorPrimitives(subtype),
      label: `${subtype.slice(0, 2).toUpperCase()}-${String(i + 1).padStart(3, '0')}`,
      value,
      units,
      fill: '#FAFAFA',
      stroke: '#757575',
      status: 'running',
      alarmLevel: 'none',
      isCommandCapable: false,
      controlEnabled: true,
      visible: true,
      zIndex: 15,
    };
    elements.push(el);
    sensorElements.push(el);
  }

  // ── Connectors (orthogonal) ──
  const connectable = [...equipmentElements, ...sensorElements];
  for (let i = 0; i < cfg.connector; i++) {
    const srcIdx = Math.floor(rand() * connectable.length);
    let tgtIdx = Math.floor(rand() * connectable.length);
    if (tgtIdx === srcIdx) tgtIdx = (tgtIdx + 1) % connectable.length;

    const src = connectable[srcIdx];
    const tgt = connectable[tgtIdx];
    const sx = src.x + src.width / 2;
    const sy = src.y + src.height / 2;
    const tx = tgt.x + tgt.width / 2;
    const ty = tgt.y + tgt.height / 2;
    const waypoints = generateOrthogonalWaypoints(sx, sy, tx, ty, rand);
    const flatPoints = waypoints.flatMap(w => [w.x, w.y]);

    const el: SceneElement = {
      id: nextId('CN'),
      category: 'connector',
      x: Math.min(sx, tx),
      y: Math.min(sy, ty),
      width: Math.abs(tx - sx),
      height: Math.abs(ty - sy),
      rotation: 0,
      primitives: [
        { type: 'line', x: 0, y: 0, points: flatPoints, fill: 'none', stroke: '#546E7A', strokeWidth: 2 },
      ],
      label: '',
      fill: 'none',
      stroke: '#546E7A',
      status: 'running',
      alarmLevel: 'none',
      isCommandCapable: false,
      controlEnabled: true,
      visible: true,
      connectorRouting: {
        sourceId: src.id,
        targetId: tgt.id,
        waypoints,
      },
      zIndex: 5,
    };
    elements.push(el);
  }

  // ── Labels ──
  for (let i = 0; i < cfg.label; i++) {
    const parentEq = equipmentElements[i % equipmentElements.length];
    const el: SceneElement = {
      id: nextId('LB'),
      category: 'label',
      x: Math.round(parentEq.x + (rand() - 0.5) * 60),
      y: Math.round(parentEq.y - 20 - rand() * 15),
      width: 80,
      height: 18,
      rotation: 0,
      primitives: [
        { type: 'rect', x: 0, y: 0, width: 80, height: 18, fill: '#FFFFFF', stroke: '#BDBDBD', strokeWidth: 0.5 },
      ],
      label: `AREA-${Math.floor(i / 4 + 1)}-TAG-${i + 1}`,
      fill: '#FFFFFF',
      stroke: '#BDBDBD',
      status: 'running',
      alarmLevel: 'none',
      isCommandCapable: false,
      controlEnabled: true,
      visible: true,
      zIndex: 20,
    };
    elements.push(el);
  }

  // ── Alarm-capable elements ──
  for (let i = 0; i < cfg.alarm; i++) {
    const parent = sensorElements[i % sensorElements.length];
    const alarmLevels: AlarmLevel[] = ['none', 'none', 'none', 'info', 'warning', 'critical'];
    const alarmLevel = alarmLevels[Math.floor(rand() * alarmLevels.length)];
    const colors = ALARM_COLORS[alarmLevel];

    const el: SceneElement = {
      id: nextId('AL'),
      category: 'alarm',
      x: Math.round(parent.x + 35),
      y: Math.round(parent.y - 5),
      width: 20,
      height: 20,
      rotation: 0,
      primitives: [
        { type: 'polygon', x: 0, y: 0, points: [10, 0, 20, 17, 0, 17], fill: colors.fill, stroke: colors.stroke, strokeWidth: 1.5 },
        { type: 'rect', x: 8, y: 8, width: 4, height: 6, fill: colors.stroke, stroke: 'none', strokeWidth: 0 },
        { type: 'circle', x: 10, y: 16, r: 1.5, fill: colors.stroke, stroke: 'none', strokeWidth: 0 },
      ],
      label: `ALM-${String(i + 1).padStart(3, '0')}`,
      fill: colors.fill,
      stroke: colors.stroke,
      status: 'running',
      alarmLevel,
      isCommandCapable: false,
      controlEnabled: true,
      visible: alarmLevel !== 'none',
      zIndex: 25,
    };
    elements.push(el);
  }

  // ── Command-capable elements ──
  for (let i = 0; i < cfg.command; i++) {
    const parent = equipmentElements[i % equipmentElements.length];
    const controlType = CONTROL_TYPES[i % CONTROL_TYPES.length];

    const el: SceneElement = {
      id: nextId('CMD'),
      category: 'command',
      x: Math.round(parent.x - 10),
      y: Math.round(parent.y + parent.height + 8),
      width: 40,
      height: 24,
      rotation: 0,
      primitives: [
        { type: 'rect', x: 0, y: 0, width: 40, height: 24, fill: '#E3F2FD', stroke: '#1976D2', strokeWidth: 1.5 },
        { type: 'rect', x: 4, y: 4, width: 32, height: 16, fill: '#BBDEFB', stroke: '#1565C0', strokeWidth: 1 },
        { type: 'circle', x: 20, y: 12, r: 4, fill: '#1976D2', stroke: 'none', strokeWidth: 0 },
      ],
      label: `CMD-${String(i + 1).padStart(3, '0')}`,
      fill: '#E3F2FD',
      stroke: '#1976D2',
      status: 'running',
      alarmLevel: 'none',
      isCommandCapable: true,
      controlType,
      controlOptions: controlType === 'dropdown' ? ['Auto', 'Manual', 'Off', 'Override'] : undefined,
      controlEnabled: rand() > 0.15,
      visible: true,
      zIndex: 30,
    };
    elements.push(el);
  }

  // Sort by z-index for consistent rendering order
  elements.sort((a, b) => a.zIndex - b.zIndex);

  const counts: Record<ElementCategory, number> = {
    equipment: cfg.equipment,
    sensor: cfg.sensor,
    connector: cfg.connector,
    label: cfg.label,
    alarm: cfg.alarm,
    command: cfg.command,
  };

  return {
    id: `scene-${size}-${seed}`,
    name: `P&ID Benchmark Scene (${size})`,
    version: '1.0.0',
    bounds: { width: cfg.canvasWidth, height: cfg.canvasHeight },
    elements,
    meta: {
      generatedAt: new Date().toISOString(),
      totalElements: elements.length,
      elementCounts: counts,
      sceneSize: size,
    },
  };
}

/** Generate all three standard scenes */
export function generateAllScenes(seed: number = 42): Record<SceneSize, SceneModel> {
  return {
    small: generateScene('small', seed),
    medium: generateScene('medium', seed + 1),
    large: generateScene('large', seed + 2),
  };
}
