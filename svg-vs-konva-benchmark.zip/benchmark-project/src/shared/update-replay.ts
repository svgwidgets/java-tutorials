/**
 * Update Replay Harness
 *
 * Generates deterministic update sequences matching the plan's rate tiers:
 *   Low:     5 updates/s, 5-10 elements/s
 *   Realistic: 20 updates/s, 30-60 elements/s
 *   Burst:   60 updates/s, 100-200 elements/s
 *   Stress:  120 updates/s, 300+ elements/s
 *
 * Update type distribution (per plan §7.5):
 *   50% color/status changes
 *   25% value/label updates
 *   15% alarm state changes
 *    5% control enable/disable
 *    5% visibility changes
 */

import type {
  SceneModel,
  SceneElement,
  UpdateSequence,
  UpdateEvent,
  UpdatePayload,
  UpdateType,
  UpdateRateTier,
  AlarmLevel,
  OperationalStatus,
} from '../../types';

// ── Deterministic PRNG ──
function mulberry32(seed: number): () => number {
  return () => {
    let t = (seed += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

const RATE_CONFIGS: Record<UpdateRateTier, {
  updatesPerSecond: number;
  elementsPerSecondMin: number;
  elementsPerSecondMax: number;
  durationSeconds: number;
}> = {
  low:       { updatesPerSecond: 5,   elementsPerSecondMin: 5,   elementsPerSecondMax: 10,  durationSeconds: 30 },
  realistic: { updatesPerSecond: 20,  elementsPerSecondMin: 30,  elementsPerSecondMax: 60,  durationSeconds: 30 },
  burst:     { updatesPerSecond: 60,  elementsPerSecondMin: 100, elementsPerSecondMax: 200, durationSeconds: 15 },
  stress:    { updatesPerSecond: 120, elementsPerSecondMin: 300, elementsPerSecondMax: 400, durationSeconds: 10 },
};

const UPDATE_TYPE_WEIGHTS: { type: UpdateType; weight: number }[] = [
  { type: 'color_change',     weight: 0.50 },
  { type: 'value_change',     weight: 0.25 },
  { type: 'alarm_change',     weight: 0.15 },
  { type: 'control_enable',   weight: 0.05 },
  { type: 'visibility_change', weight: 0.05 },
];

const STATUS_CYCLE: OperationalStatus[] = ['running', 'stopped', 'fault', 'maintenance', 'standby'];
const ALARM_CYCLE: AlarmLevel[] = ['none', 'info', 'warning', 'critical', 'emergency', 'critical', 'warning', 'none'];

const STATUS_COLORS: Record<OperationalStatus, { fill: string; stroke: string }> = {
  running:     { fill: '#4CAF50', stroke: '#2E7D32' },
  stopped:     { fill: '#9E9E9E', stroke: '#616161' },
  fault:       { fill: '#F44336', stroke: '#C62828' },
  maintenance: { fill: '#FF9800', stroke: '#E65100' },
  standby:     { fill: '#2196F3', stroke: '#1565C0' },
};

const ALARM_COLORS: Record<AlarmLevel, { fill: string; stroke: string }> = {
  none:      { fill: '#E0E0E0', stroke: '#9E9E9E' },
  info:      { fill: '#BBDEFB', stroke: '#1976D2' },
  warning:   { fill: '#FFF9C4', stroke: '#F9A825' },
  critical:  { fill: '#FFCDD2', stroke: '#D32F2F' },
  emergency: { fill: '#FF1744', stroke: '#B71C1C' },
};

function pickUpdateType(rand: () => number): UpdateType {
  const r = rand();
  let cumulative = 0;
  for (const { type, weight } of UPDATE_TYPE_WEIGHTS) {
    cumulative += weight;
    if (r <= cumulative) return type;
  }
  return 'color_change';
}

function generatePayload(
  type: UpdateType,
  element: SceneElement,
  rand: () => number,
  tick: number
): UpdatePayload {
  switch (type) {
    case 'color_change': {
      const status = STATUS_CYCLE[(tick + Math.floor(rand() * 3)) % STATUS_CYCLE.length];
      const colors = STATUS_COLORS[status];
      return { type: 'color_change', fill: colors.fill, stroke: colors.stroke, status };
    }
    case 'value_change': {
      const base = parseFloat(element.value || '50');
      const newVal = (base + (rand() - 0.5) * 20).toFixed(1);
      return { type: 'value_change', value: newVal };
    }
    case 'alarm_change': {
      const level = ALARM_CYCLE[(tick + Math.floor(rand() * 4)) % ALARM_CYCLE.length];
      const colors = ALARM_COLORS[level];
      return { type: 'alarm_change', alarmLevel: level, fill: colors.fill, stroke: colors.stroke };
    }
    case 'control_enable': {
      return { type: 'control_enable', enabled: rand() > 0.3 };
    }
    case 'visibility_change': {
      return { type: 'visibility_change', visible: rand() > 0.2 };
    }
  }
}

/**
 * Generate a complete update sequence for a given scene and rate tier.
 */
export function generateUpdateSequence(
  scene: SceneModel,
  rateTier: UpdateRateTier,
  seed: number = 1337
): UpdateSequence {
  const rand = mulberry32(seed);
  const cfg = RATE_CONFIGS[rateTier];
  const durationMs = cfg.durationSeconds * 1000;
  const totalUpdates = cfg.updatesPerSecond * cfg.durationSeconds;
  const intervalMs = 1000 / cfg.updatesPerSecond;

  // Build pools of updatable elements by type
  const updatableElements = scene.elements.filter(e => e.category !== 'connector' && e.category !== 'label');
  const alarmElements = scene.elements.filter(e => e.category === 'alarm' || e.alarmLevel !== undefined);
  const commandElements = scene.elements.filter(e => e.isCommandCapable);
  const visibilityElements = scene.elements.filter(e => e.category === 'alarm' || e.category === 'label');

  const events: UpdateEvent[] = [];
  let tick = 0;

  for (let t = 0; t < durationMs; t += intervalMs) {
    // Each tick may affect multiple elements
    const elementsThisTick = Math.floor(
      cfg.elementsPerSecondMin / cfg.updatesPerSecond +
      rand() * ((cfg.elementsPerSecondMax - cfg.elementsPerSecondMin) / cfg.updatesPerSecond)
    );

    for (let e = 0; e < Math.max(1, elementsThisTick); e++) {
      const type = pickUpdateType(rand);
      let pool: SceneElement[];

      switch (type) {
        case 'alarm_change':
          pool = alarmElements.length > 0 ? alarmElements : updatableElements;
          break;
        case 'control_enable':
          pool = commandElements.length > 0 ? commandElements : updatableElements;
          break;
        case 'visibility_change':
          pool = visibilityElements.length > 0 ? visibilityElements : updatableElements;
          break;
        default:
          pool = updatableElements;
      }

      const element = pool[Math.floor(rand() * pool.length)];
      const payload = generatePayload(type, element, rand, tick);

      events.push({
        timestamp: Math.round(t),
        elementId: element.id,
        type,
        payload,
      });
    }
    tick++;
  }

  // Sort by timestamp for deterministic replay
  events.sort((a, b) => a.timestamp - b.timestamp);

  const typeDistribution: Record<UpdateType, number> = {
    color_change: 0,
    value_change: 0,
    alarm_change: 0,
    control_enable: 0,
    visibility_change: 0,
  };
  events.forEach(e => typeDistribution[e.type]++);
  const total = events.length;
  for (const key of Object.keys(typeDistribution) as UpdateType[]) {
    typeDistribution[key] = Math.round((typeDistribution[key] / total) * 100);
  }

  return {
    id: `updates-${rateTier}-${seed}`,
    name: `${rateTier} update sequence`,
    rateTier,
    durationMs,
    events,
    meta: {
      updatesPerSecond: cfg.updatesPerSecond,
      elementsAffectedPerSecond: (cfg.elementsPerSecondMin + cfg.elementsPerSecondMax) / 2,
      updateTypeDistribution: typeDistribution,
    },
  };
}

/**
 * Generate alarm burst: 40 simultaneous alarm state changes.
 */
export function generateAlarmBurst(scene: SceneModel, seed: number = 9999): UpdateSequence {
  const rand = mulberry32(seed);
  const alarmCapable = scene.elements.filter(e =>
    e.category === 'alarm' || e.category === 'sensor' || e.category === 'equipment'
  );
  const events: UpdateEvent[] = [];

  for (let i = 0; i < Math.min(40, alarmCapable.length); i++) {
    const el = alarmCapable[i];
    const level: AlarmLevel = rand() > 0.5 ? 'critical' : 'emergency';
    const colors = ALARM_COLORS[level];
    events.push({
      timestamp: 0, // all simultaneous
      elementId: el.id,
      type: 'alarm_change',
      payload: { type: 'alarm_change', alarmLevel: level, fill: colors.fill, stroke: colors.stroke },
    });
  }

  return {
    id: `alarm-burst-${seed}`,
    name: 'Alarm burst (40 simultaneous)',
    rateTier: 'burst',
    durationMs: 0,
    events,
    meta: {
      updatesPerSecond: 40,
      elementsAffectedPerSecond: 40,
      updateTypeDistribution: {
        color_change: 0,
        value_change: 0,
        alarm_change: 100,
        control_enable: 0,
        visibility_change: 0,
      },
    },
  };
}

/**
 * Long-session update generator: produces 4 hours of realistic updates.
 * Returns a generator to avoid holding all events in memory.
 */
export function* generateLongSessionUpdates(
  scene: SceneModel,
  seed: number = 2024
): Generator<UpdateEvent[], void, unknown> {
  const durationMs = 4 * 60 * 60 * 1000; // 4 hours
  const intervalMs = 50; // 20 updates/s
  const rand = mulberry32(seed);
  const updatable = scene.elements.filter(e => e.category !== 'connector' && e.category !== 'label');
  let tick = 0;

  for (let t = 0; t < durationMs; t += intervalMs) {
    const batch: UpdateEvent[] = [];
    const count = 1 + Math.floor(rand() * 3);

    for (let i = 0; i < count; i++) {
      const type = pickUpdateType(rand);
      const el = updatable[Math.floor(rand() * updatable.length)];
      batch.push({
        timestamp: t,
        elementId: el.id,
        type,
        payload: generatePayload(type, el, rand, tick),
      });
    }

    yield batch;
    tick++;
  }
}

// ── Replay Controller ──

export type UpdateCallback = (events: UpdateEvent[]) => void;

export class ReplayController {
  private sequence: UpdateSequence;
  private callback: UpdateCallback;
  private timer: ReturnType<typeof setTimeout> | null = null;
  private startTime = 0;
  private eventIndex = 0;
  private _isRunning = false;
  private speedMultiplier: number;

  constructor(sequence: UpdateSequence, callback: UpdateCallback, speedMultiplier = 1) {
    this.sequence = sequence;
    this.callback = callback;
    this.speedMultiplier = speedMultiplier;
  }

  get isRunning(): boolean {
    return this._isRunning;
  }

  start(): void {
    if (this._isRunning) return;
    this._isRunning = true;
    this.startTime = performance.now();
    this.eventIndex = 0;
    this.tick();
  }

  stop(): void {
    this._isRunning = false;
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  reset(): void {
    this.stop();
    this.eventIndex = 0;
  }

  private tick(): void {
    if (!this._isRunning) return;

    const elapsed = (performance.now() - this.startTime) * this.speedMultiplier;
    const batch: UpdateEvent[] = [];

    while (
      this.eventIndex < this.sequence.events.length &&
      this.sequence.events[this.eventIndex].timestamp <= elapsed
    ) {
      batch.push(this.sequence.events[this.eventIndex]);
      this.eventIndex++;
    }

    if (batch.length > 0) {
      this.callback(batch);
    }

    if (this.eventIndex < this.sequence.events.length) {
      const nextTimestamp = this.sequence.events[this.eventIndex].timestamp;
      const delay = Math.max(1, (nextTimestamp - elapsed) / this.speedMultiplier);
      this.timer = setTimeout(() => this.tick(), delay);
    } else {
      this._isRunning = false;
    }
  }
}
