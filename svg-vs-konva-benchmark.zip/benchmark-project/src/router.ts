import { createRouter, createWebHashHistory } from 'vue-router';

const router = createRouter({
  history: createWebHashHistory(),
  routes: [
    {
      path: '/',
      name: 'dashboard',
      component: () => import('./views/DashboardView.vue'),
    },
    {
      path: '/benchmark/:variantId',
      name: 'benchmark',
      component: () => import('./views/BenchmarkView.vue'),
      props: true,
    },
    {
      path: '/results',
      name: 'results',
      component: () => import('./views/ResultsView.vue'),
    },
    {
      path: '/compare',
      name: 'compare',
      component: () => import('./views/CompareView.vue'),
    },
  ],
});

export default router;
