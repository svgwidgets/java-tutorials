/**
 * Workload Executor (§7)
 *
 * Orchestrates automated workload scenarios:
 *  W-INIT, W-SWITCH, W-PAN, W-ZOOM, W-LIVE-*, W-ALARM, W-INTERACT, W-LONG, W-MIXED
 *
 * All workloads are fully automated — no manual mouse movement.
 */

import type {
  SceneModel,
  WorkloadId,
  ViewportState,
  UpdateEvent,
} from '../../types';
import { PAN_CONFIG, ZOOM_CONFIG } from '../shared/constants';
import {
  generateUpdateSequence,
  generateAlarmBurst,
  ReplayController,
} from '../shared/update-replay';

export type ApplyUpdatesFn = (events: UpdateEvent[]) => void;
export type SetViewportFn = (state: ViewportState) => void;
export type RenderSceneFn = (scene: SceneModel) => Promise<void>;
export type ClearSceneFn = () => void;
export type SimulateClickFn = (elementId: string) => void;

export interface WorkloadContext {
  scene: SceneModel;
  smallScene: SceneModel;
  applyUpdates: ApplyUpdatesFn;
  setViewport: SetViewportFn;
  renderScene: RenderSceneFn;
  clearScene: ClearSceneFn;
  simulateClick: SimulateClickFn;
}

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function lerp(a: number, b: number, t: number): number {
  return a + (b - a) * t;
}

/**
 * Animate a value over time using requestAnimationFrame.
 */
function animate(
  durationMs: number,
  onFrame: (t: number) => void
): Promise<void> {
  return new Promise(resolve => {
    const start = performance.now();
    function step(now: number) {
      const elapsed = now - start;
      const t = Math.min(elapsed / durationMs, 1);
      onFrame(t);
      if (t < 1) {
        requestAnimationFrame(step);
      } else {
        resolve();
      }
    }
    requestAnimationFrame(step);
  });
}

// ── Workload Implementations ──

async function executeInit(ctx: WorkloadContext): Promise<{ renderMs: number }> {
  const t0 = performance.now();
  await ctx.renderScene(ctx.scene);
  const t1 = performance.now();
  return { renderMs: t1 - t0 };
}

async function executeSwitch(ctx: WorkloadContext): Promise<{ switchMs: number }> {
  // Already showing large scene
  await sleep(200);

  // Switch to small sub-diagram
  const t0 = performance.now();
  ctx.clearScene();
  await ctx.renderScene(ctx.smallScene);
  const t1 = performance.now();

  await sleep(500);

  // Switch back to large
  ctx.clearScene();
  await ctx.renderScene(ctx.scene);
  await sleep(200);

  return { switchMs: t1 - t0 };
}

async function executePan(ctx: WorkloadContext): Promise<void> {
  const startX = 0;
  const endX = -PAN_CONFIG.distancePx;

  await animate(PAN_CONFIG.durationMs, (t) => {
    ctx.setViewport({
      x: lerp(startX, endX, t),
      y: 0,
      scale: 1,
    });
  });
}

async function executeZoom(ctx: WorkloadContext): Promise<void> {
  for (const phase of ZOOM_CONFIG.phases) {
    await animate(phase.durationMs, (t) => {
      ctx.setViewport({
        x: 0,
        y: 0,
        scale: lerp(phase.from, phase.to, t),
      });
    });
  }
}

async function executeLiveUpdate(
  ctx: WorkloadContext,
  rateTier: 'low' | 'realistic' | 'burst' | 'stress'
): Promise<void> {
  const sequence = generateUpdateSequence(ctx.scene, rateTier);
  const controller = new ReplayController(sequence, ctx.applyUpdates);

  controller.start();

  // Wait for sequence to complete
  await new Promise<void>(resolve => {
    const check = setInterval(() => {
      if (!controller.isRunning) {
        clearInterval(check);
        resolve();
      }
    }, 100);
  });
}

async function executeAlarmBurst(ctx: WorkloadContext): Promise<void> {
  const burst = generateAlarmBurst(ctx.scene);
  // Apply all 40 alarm changes at once
  ctx.applyUpdates(burst.events);
  // Wait for recovery
  await sleep(2000);
}

async function executeInteractUnderLoad(ctx: WorkloadContext): Promise<void> {
  // Start realistic live updates
  const sequence = generateUpdateSequence(ctx.scene, 'realistic');
  const controller = new ReplayController(sequence, ctx.applyUpdates);
  controller.start();

  // Wait for updates to stabilize
  await sleep(1000);

  // Perform interactions while updates are running
  const commandElements = ctx.scene.elements.filter(e => e.isCommandCapable);
  for (let i = 0; i < Math.min(5, commandElements.length); i++) {
    ctx.simulateClick(commandElements[i].id);
    await sleep(500);
  }

  controller.stop();
}

async function executeLongSession(ctx: WorkloadContext): Promise<void> {
  // 4 hours simulated at 10x speed = 24 minutes
  // For benchmark purposes, we run 2 minutes of wall-clock time at 10x speed
  const sequence = generateUpdateSequence(ctx.scene, 'realistic', 7777);
  const controller = new ReplayController(sequence, ctx.applyUpdates, 10);

  controller.start();

  // Run for the sequence duration (divided by speed multiplier)
  const wallClockDuration = sequence.durationMs / 10;
  await sleep(wallClockDuration);

  controller.stop();
}

async function executeMixedWorkflow(ctx: WorkloadContext): Promise<void> {
  // Start background live updates
  const sequence = generateUpdateSequence(ctx.scene, 'realistic', 5555);
  const controller = new ReplayController(sequence, ctx.applyUpdates);
  controller.start();

  // 1. Pan to section A
  await animate(1000, (t) => {
    ctx.setViewport({ x: lerp(0, -800, t), y: lerp(0, -400, t), scale: 1 });
  });

  // 2. Zoom in
  await animate(800, (t) => {
    ctx.setViewport({ x: -800, y: -400, scale: lerp(1, 1.8, t) });
  });

  await sleep(500);

  // 3. Interact with a control
  const cmdElements = ctx.scene.elements.filter(e => e.isCommandCapable);
  if (cmdElements.length > 0) {
    ctx.simulateClick(cmdElements[0].id);
  }

  await sleep(800);

  // 4. Receive alarm (simulated)
  const alarmBurst = generateAlarmBurst(ctx.scene, 3333);
  ctx.applyUpdates(alarmBurst.events.slice(0, 5)); // 5 alarms

  await sleep(500);

  // 5. Pan to alarm source
  await animate(1000, (t) => {
    ctx.setViewport({ x: lerp(-800, -1500, t), y: lerp(-400, -200, t), scale: 1.8 });
  });

  await sleep(500);

  // 6. Zoom out
  await animate(800, (t) => {
    ctx.setViewport({ x: -1500, y: -200, scale: lerp(1.8, 0.6, t) });
  });

  // 7. Switch to sub-diagram
  ctx.clearScene();
  await ctx.renderScene(ctx.smallScene);

  await sleep(1000);

  // 8. Switch back
  ctx.clearScene();
  await ctx.renderScene(ctx.scene);

  await sleep(500);

  controller.stop();
}

// ── Main Executor ──

export async function executeWorkload(
  workloadId: WorkloadId,
  ctx: WorkloadContext
): Promise<Record<string, number | undefined>> {
  const extraMetrics: Record<string, number | undefined> = {};

  switch (workloadId) {
    case 'W-INIT': {
      const result = await executeInit(ctx);
      extraMetrics.initialRenderMs = result.renderMs;
      break;
    }
    case 'W-SWITCH': {
      const result = await executeSwitch(ctx);
      extraMetrics.subDiagramSwitchMs = result.switchMs;
      break;
    }
    case 'W-PAN':
      await executePan(ctx);
      break;
    case 'W-ZOOM':
      await executeZoom(ctx);
      break;
    case 'W-LIVE-LO':
      await executeLiveUpdate(ctx, 'low');
      break;
    case 'W-LIVE-MED':
      await executeLiveUpdate(ctx, 'realistic');
      break;
    case 'W-LIVE-HI':
      await executeLiveUpdate(ctx, 'burst');
      break;
    case 'W-LIVE-STRESS':
      await executeLiveUpdate(ctx, 'stress');
      break;
    case 'W-ALARM':
      await executeAlarmBurst(ctx);
      break;
    case 'W-INTERACT':
      await executeInteractUnderLoad(ctx);
      break;
    case 'W-LONG':
      await executeLongSession(ctx);
      break;
    case 'W-MIXED':
      await executeMixedWorkflow(ctx);
      break;
  }

  return extraMetrics;
}
