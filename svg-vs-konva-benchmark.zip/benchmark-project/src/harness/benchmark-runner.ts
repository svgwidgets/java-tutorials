/**
 * Benchmark Runner (§9.3, §17)
 *
 * Orchestrates the full benchmark matrix:
 *   6 variants × workloads × control densities × scene sizes × 10 runs each
 *
 * Manages warm-up, run sequencing, metrics collection, and result export.
 */

import type {
  VariantId,
  WorkloadId,
  ControlDensityId,
  SceneSize,
  BenchmarkRunConfig,
  RunMetrics,
} from '../../types';
import { ref, reactive } from 'vue';
import { MetricsCollector, metricsToCSV } from '../instrumentation/metrics';

export interface BenchmarkProgress {
  totalConfigs: number;
  completedConfigs: number;
  currentConfig: string;
  currentRun: number;
  totalRuns: number;
  phase: 'idle' | 'warmup' | 'running' | 'cooldown' | 'complete';
  allResults: RunMetrics[];
}

export interface RunRequest {
  variantId: VariantId;
  workloadId: WorkloadId;
  controlDensity: ControlDensityId;
  sceneSize: SceneSize;
}

export type ExecuteRunFn = (config: BenchmarkRunConfig, collector: MetricsCollector) => Promise<void>;

export class BenchmarkRunner {
  private runsPerConfig: number;
  private warmUpRuns: number;
  private warmUpMs: number;
  private allResults: RunMetrics[] = [];

  public progress = reactive<BenchmarkProgress>({
    totalConfigs: 0,
    completedConfigs: 0,
    currentConfig: '',
    currentRun: 0,
    totalRuns: 0,
    phase: 'idle',
    allResults: [],
  });

  constructor(runsPerConfig = 10, warmUpRuns = 2, warmUpMs = 500) {
    this.runsPerConfig = runsPerConfig;
    this.warmUpRuns = warmUpRuns;
    this.warmUpMs = warmUpMs;
  }

  /**
   * Run a single benchmark configuration (all runs).
   */
  async runSingle(
    request: RunRequest,
    executeFn: ExecuteRunFn
  ): Promise<RunMetrics[]> {
    const results: RunMetrics[] = [];

    this.progress.totalRuns = this.runsPerConfig;
    this.progress.currentConfig = `${request.variantId}-${request.workloadId}-${request.controlDensity}-${request.sceneSize}`;

    for (let run = 0; run < this.runsPerConfig; run++) {
      const isWarmUp = run < this.warmUpRuns;
      this.progress.currentRun = run + 1;
      this.progress.phase = isWarmUp ? 'warmup' : 'running';

      const config: BenchmarkRunConfig = {
        variantId: request.variantId,
        workloadId: request.workloadId,
        controlDensity: request.controlDensity,
        sceneSize: request.sceneSize,
        runIndex: run,
        warmUpMs: this.warmUpMs,
        isWarmUp,
      };

      const collector = new MetricsCollector();
      collector.configure(config);

      // Warm-up pause
      await this.sleep(this.warmUpMs);

      // Execute the workload with instrumentation
      collector.startCollection();
      await executeFn(config, collector);
      const metrics = collector.stopCollection();

      results.push(metrics);
      this.allResults.push(metrics);

      // Cooldown between runs
      this.progress.phase = 'cooldown';
      await this.sleep(200);

      collector.reset();
    }

    this.progress.completedConfigs++;
    return results;
  }

  /**
   * Run the full benchmark matrix for a set of requests.
   */
  async runMatrix(
    requests: RunRequest[],
    executeFn: ExecuteRunFn
  ): Promise<RunMetrics[]> {
    this.progress.totalConfigs = requests.length;
    this.progress.completedConfigs = 0;
    this.progress.phase = 'running';
    this.allResults = [];

    for (const request of requests) {
      await this.runSingle(request, executeFn);
    }

    this.progress.phase = 'complete';
    this.progress.allResults = this.allResults;
    return this.allResults;
  }

  /**
   * Get valid (non-warmup) results only.
   */
  getValidResults(): RunMetrics[] {
    return this.allResults.filter(r => !r.config.isWarmUp);
  }

  /**
   * Export all results as CSV.
   */
  exportCSV(): string {
    return metricsToCSV(this.allResults);
  }

  /**
   * Export valid results as CSV.
   */
  exportValidCSV(): string {
    return metricsToCSV(this.getValidResults());
  }

  /**
   * Download CSV file in browser.
   */
  downloadCSV(filename = 'benchmark-results.csv'): void {
    const csv = this.exportCSV();
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  reset(): void {
    this.allResults = [];
    this.progress.totalConfigs = 0;
    this.progress.completedConfigs = 0;
    this.progress.currentConfig = '';
    this.progress.currentRun = 0;
    this.progress.totalRuns = 0;
    this.progress.phase = 'idle';
    this.progress.allResults = [];
  }

  private sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// ── Quick Benchmark Presets ──

export function createQuickBenchmarkRequests(
  variantId: VariantId,
  sceneSize: SceneSize = 'large'
): RunRequest[] {
  const coreWorkloads: WorkloadId[] = [
    'W-INIT', 'W-PAN', 'W-ZOOM', 'W-LIVE-MED', 'W-ALARM',
  ];
  const density: ControlDensityId = 'C-0';

  return coreWorkloads.map(workloadId => ({
    variantId,
    workloadId,
    controlDensity: density,
    sceneSize,
  }));
}

export function createFullComparisonRequests(sceneSize: SceneSize = 'large'): RunRequest[] {
  const requests: RunRequest[] = [];
  const variants: VariantId[] = ['A', 'B'];
  const workloads: WorkloadId[] = [
    'W-INIT', 'W-PAN', 'W-ZOOM',
    'W-LIVE-LO', 'W-LIVE-MED', 'W-LIVE-HI', 'W-LIVE-STRESS',
    'W-ALARM',
  ];

  for (const variantId of variants) {
    for (const workloadId of workloads) {
      requests.push({
        variantId,
        workloadId,
        controlDensity: 'C-0',
        sceneSize,
      });
    }
  }

  return requests;
}

export function createControlDensityRequests(): RunRequest[] {
  const requests: RunRequest[] = [];
  const variants: VariantId[] = ['C', 'D'];
  const densities: ControlDensityId[] = ['C-0', 'C-10', 'C-30', 'C-60', 'C-CTX'];
  const workloads: WorkloadId[] = ['W-PAN', 'W-ZOOM'];

  for (const variantId of variants) {
    for (const density of densities) {
      for (const workloadId of workloads) {
        requests.push({
          variantId,
          workloadId,
          controlDensity: density,
          sceneSize: 'large',
        });
      }
    }
  }

  return requests;
}
