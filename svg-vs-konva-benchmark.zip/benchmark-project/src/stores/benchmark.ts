import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import type { SceneModel, SceneSize, RunMetrics, VariantId, WorkloadId, ControlDensityId } from '../../types';
import { generateScene } from '../shared/scene-generator';
import { computeStats } from '../instrumentation/metrics';

export const useBenchmarkStore = defineStore('benchmark', () => {
  // ── Scenes ──
  const scenes = ref<Record<SceneSize, SceneModel>>({
    small: generateScene('small', 42),
    medium: generateScene('medium', 43),
    large: generateScene('large', 44),
  });

  const activeSceneSize = ref<SceneSize>('large');
  const activeScene = computed(() => scenes.value[activeSceneSize.value]);

  // ── Results ──
  const allResults = ref<RunMetrics[]>([]);
  const isRunning = ref(false);
  const currentVariant = ref<VariantId | null>(null);

  function addResults(results: RunMetrics[]) {
    allResults.value.push(...results);
  }

  function clearResults() {
    allResults.value = [];
  }

  // ── Result Queries ──
  function getResults(
    variantId?: VariantId,
    workloadId?: WorkloadId,
    controlDensity?: ControlDensityId,
    sceneSize?: SceneSize,
    excludeWarmUp = true
  ): RunMetrics[] {
    return allResults.value.filter(r => {
      if (excludeWarmUp && r.config.isWarmUp) return false;
      if (variantId && r.config.variantId !== variantId) return false;
      if (workloadId && r.config.workloadId !== workloadId) return false;
      if (controlDensity && r.config.controlDensity !== controlDensity) return false;
      if (sceneSize && r.config.sceneSize !== sceneSize) return false;
      return true;
    });
  }

  function getAggregatedP95FrameTime(
    variantId: VariantId,
    workloadId: WorkloadId,
    controlDensity: ControlDensityId = 'C-0',
    sceneSize: SceneSize = 'large'
  ): number | null {
    const results = getResults(variantId, workloadId, controlDensity, sceneSize);
    if (results.length === 0) return null;
    const p95Values = results.map(r => r.frameStats.p95);
    return computeStats(p95Values).median;
  }

  function getComparisonSummary(workloadId: WorkloadId, sceneSize: SceneSize = 'large') {
    const svgP95 = getAggregatedP95FrameTime('A', workloadId, 'C-0', sceneSize);
    const konvaP95 = getAggregatedP95FrameTime('B', workloadId, 'C-0', sceneSize);

    if (svgP95 === null || konvaP95 === null) return null;

    const diff = ((svgP95 - konvaP95) / svgP95) * 100;
    return {
      svgP95,
      konvaP95,
      diffPercent: Math.round(diff * 10) / 10,
      winner: konvaP95 < svgP95 ? 'konva' as const : 'svg' as const,
      magnitude: Math.abs(diff) < 10 ? 'negligible' as const
        : Math.abs(diff) < 30 ? 'minor' as const
        : Math.abs(diff) < 50 ? 'significant' as const
        : 'dominant' as const,
    };
  }

  // ── CSV Export ──
  function exportAllCSV(): string {
    const headers = [
      'variant', 'workload', 'controlDensity', 'sceneSize', 'runIndex', 'isWarmUp',
      'frameCount', 'frameMean', 'frameMedian', 'frameP95', 'frameP99',
      'frameMin', 'frameMax', 'frameStdDev', 'droppedFrames',
      'initialRenderMs', 'subDiagramSwitchMs', 'durationMs',
    ].join(',');

    const rows = allResults.value.map(m => [
      m.config.variantId, m.config.workloadId, m.config.controlDensity,
      m.config.sceneSize, m.config.runIndex, m.config.isWarmUp,
      m.frameStats.count, m.frameStats.mean.toFixed(2), m.frameStats.median.toFixed(2),
      m.frameStats.p95.toFixed(2), m.frameStats.p99.toFixed(2),
      m.frameStats.min.toFixed(2), m.frameStats.max.toFixed(2), m.frameStats.stdDev.toFixed(2),
      m.droppedFrames,
      m.initialRenderMs?.toFixed(2) ?? '', m.subDiagramSwitchMs?.toFixed(2) ?? '',
      (m.endTime - m.startTime).toFixed(0),
    ].join(','));

    return [headers, ...rows].join('\n');
  }

  function downloadCSV(filename = 'benchmark-results.csv') {
    const csv = exportAllCSV();
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
    URL.revokeObjectURL(url);
  }

  return {
    scenes,
    activeSceneSize,
    activeScene,
    allResults,
    isRunning,
    currentVariant,
    addResults,
    clearResults,
    getResults,
    getAggregatedP95FrameTime,
    getComparisonSummary,
    exportAllCSV,
    downloadCSV,
  };
});
