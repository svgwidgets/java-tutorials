/**
 * Post-hoc Analysis Script (§14)
 *
 * Run: npx ts-node scripts/analyze-results.ts results.csv
 *
 * Reads the CSV exported from the benchmark app and produces:
 *  - Graphics-only comparison table
 *  - Control density analysis
 *  - Crossover point identification
 *  - Performance gap classification
 *  - Decision tree evaluation
 */

import * as fs from 'fs';
import * as path from 'path';

interface ResultRow {
  variant: string;
  workload: string;
  controlDensity: string;
  sceneSize: string;
  runIndex: number;
  isWarmUp: boolean;
  frameCount: number;
  frameMean: number;
  frameMedian: number;
  frameP95: number;
  frameP99: number;
  frameMin: number;
  frameMax: number;
  frameStdDev: number;
  droppedFrames: number;
  initialRenderMs: number | null;
  subDiagramSwitchMs: number | null;
  durationMs: number;
}

function parseCSV(filepath: string): ResultRow[] {
  const content = fs.readFileSync(filepath, 'utf-8');
  const lines = content.trim().split('\n');
  const headers = lines[0].split(',');

  return lines.slice(1).map(line => {
    const values = line.split(',');
    return {
      variant: values[0],
      workload: values[1],
      controlDensity: values[2],
      sceneSize: values[3],
      runIndex: parseInt(values[4]),
      isWarmUp: values[5] === 'true',
      frameCount: parseInt(values[6]),
      frameMean: parseFloat(values[7]),
      frameMedian: parseFloat(values[8]),
      frameP95: parseFloat(values[9]),
      frameP99: parseFloat(values[10]),
      frameMin: parseFloat(values[11]),
      frameMax: parseFloat(values[12]),
      frameStdDev: parseFloat(values[13]),
      droppedFrames: parseInt(values[14]),
      initialRenderMs: values[21] ? parseFloat(values[21]) : null,
      subDiagramSwitchMs: values[22] ? parseFloat(values[22]) : null,
      durationMs: parseInt(values[26] || '0'),
    };
  }).filter(r => !r.isWarmUp);
}

function median(arr: number[]): number {
  const sorted = [...arr].sort((a, b) => a - b);
  return sorted[Math.floor(sorted.length / 2)] || 0;
}

function classifyGap(pctDiff: number): string {
  const abs = Math.abs(pctDiff);
  if (abs < 10) return 'NEGLIGIBLE';
  if (abs < 30) return 'MINOR';
  if (abs < 50) return 'SIGNIFICANT';
  return 'DOMINANT';
}

function analyze(rows: ResultRow[]) {
  console.log('\n' + '='.repeat(72));
  console.log('  SVG vs Vue Konva — Benchmark Analysis Report');
  console.log('='.repeat(72));

  // Group by variant + workload
  const grouped = new Map<string, ResultRow[]>();
  for (const row of rows) {
    const key = `${row.variant}|${row.workload}|${row.controlDensity}|${row.sceneSize}`;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key)!.push(row);
  }

  // §14.1 Graphics-only comparison
  console.log('\n\n─── §14.1 Graphics-Only Comparison (A vs B) ───\n');
  console.log(
    'Workload'.padEnd(20) +
    'SVG p95 (ms)'.padStart(14) +
    'Konva p95 (ms)'.padStart(16) +
    'Diff %'.padStart(10) +
    'Classification'.padStart(16) +
    'Winner'.padStart(10)
  );
  console.log('─'.repeat(86));

  const workloads = ['W-INIT', 'W-PAN', 'W-ZOOM', 'W-LIVE-LO', 'W-LIVE-MED', 'W-LIVE-HI', 'W-LIVE-STRESS', 'W-ALARM'];
  for (const wl of workloads) {
    const svgRows = grouped.get(`A|${wl}|C-0|large`) ?? [];
    const konvaRows = grouped.get(`B|${wl}|C-0|large`) ?? [];

    if (svgRows.length === 0 && konvaRows.length === 0) continue;

    const svgP95 = svgRows.length > 0 ? median(svgRows.map(r => r.frameP95)) : NaN;
    const konvaP95 = konvaRows.length > 0 ? median(konvaRows.map(r => r.frameP95)) : NaN;
    const diffPct = !isNaN(svgP95) && !isNaN(konvaP95) && svgP95 > 0
      ? ((svgP95 - konvaP95) / svgP95) * 100
      : NaN;

    const classification = !isNaN(diffPct) ? classifyGap(diffPct) : 'N/A';
    const winner = !isNaN(diffPct)
      ? (Math.abs(diffPct) < 10 ? 'TIE' : (konvaP95 < svgP95 ? 'KONVA' : 'SVG'))
      : 'N/A';

    console.log(
      wl.padEnd(20) +
      (isNaN(svgP95) ? '—' : svgP95.toFixed(1)).padStart(14) +
      (isNaN(konvaP95) ? '—' : konvaP95.toFixed(1)).padStart(16) +
      (isNaN(diffPct) ? '—' : diffPct.toFixed(1) + '%').padStart(10) +
      classification.padStart(16) +
      winner.padStart(10)
    );
  }

  // §14.2 Crossover point
  console.log('\n\n─── §14.2 Crossover Point ───\n');
  const liveTiers = ['W-LIVE-LO', 'W-LIVE-MED', 'W-LIVE-HI', 'W-LIVE-STRESS'];
  let crossover = 'Not found';
  for (const tier of liveTiers) {
    const svgRows = grouped.get(`A|${tier}|C-0|large`) ?? [];
    if (svgRows.length > 0) {
      const svgP95 = median(svgRows.map(r => r.frameP95));
      if (svgP95 > 16.7) {
        crossover = `SVG exceeds 16.7ms budget at ${tier}`;
        break;
      }
    }
  }
  console.log(`  Crossover: ${crossover}`);

  // §14.5 Performance gap summary
  console.log('\n\n─── §14.5 Performance Gap Summary ───\n');
  const liveMedSvg = grouped.get('A|W-LIVE-MED|C-0|large') ?? [];
  const liveMedKonva = grouped.get('B|W-LIVE-MED|C-0|large') ?? [];
  if (liveMedSvg.length > 0 && liveMedKonva.length > 0) {
    const svgP95 = median(liveMedSvg.map(r => r.frameP95));
    const konvaP95 = median(liveMedKonva.map(r => r.frameP95));
    const gap = ((svgP95 - konvaP95) / svgP95) * 100;
    const classification = classifyGap(gap);
    console.log(`  At W-LIVE-MED (realistic load):`);
    console.log(`    SVG p95:   ${svgP95.toFixed(1)} ms`);
    console.log(`    Konva p95: ${konvaP95.toFixed(1)} ms`);
    console.log(`    Gap:       ${Math.abs(gap).toFixed(1)}% (${classification})`);
    console.log(`    Architecture-defining: ${classification === 'SIGNIFICANT' || classification === 'DOMINANT' ? 'YES' : 'NO'}`);
  } else {
    console.log('  Insufficient data. Run A vs B with W-LIVE-MED.');
  }

  // Decision
  console.log('\n\n─── §15 Decision ───\n');
  if (liveMedSvg.length > 0 && liveMedKonva.length > 0) {
    const svgP95 = median(liveMedSvg.map(r => r.frameP95));
    const konvaP95 = median(liveMedKonva.map(r => r.frameP95));
    const gap = Math.abs(((svgP95 - konvaP95) / svgP95) * 100);

    if (gap < 20) {
      console.log('  RECOMMENDATION: Performance difference < 20%.');
      console.log('  Choose based on maintainability, ecosystem, and developer velocity.');
      console.log('  SVG advantage: DOM-native events, CSS styling, familiar debugging.');
      console.log('  Konva advantage: layered canvas, potentially better scaling.');
    } else if (konvaP95 < svgP95) {
      console.log('  RECOMMENDATION: Choose Vue Konva for the Monitor module.');
      console.log(`  Evidence: ${gap.toFixed(1)}% lower p95 at realistic load.`);
    } else {
      console.log('  RECOMMENDATION: Choose SVG for the Monitor module.');
      console.log(`  Evidence: ${gap.toFixed(1)}% lower p95 at realistic load.`);
    }
  }

  console.log('\n' + '='.repeat(72));
  console.log('  End of Analysis Report');
  console.log('='.repeat(72) + '\n');
}

// ── Main ──
const csvPath = process.argv[2];
if (!csvPath) {
  console.log('Usage: npx ts-node scripts/analyze-results.ts <results.csv>');
  process.exit(1);
}

const rows = parseCSV(path.resolve(csvPath));
console.log(`Loaded ${rows.length} valid result rows.`);
analyze(rows);
