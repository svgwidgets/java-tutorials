// ============================================================================
// SCENE MODEL TYPES
// ============================================================================

/** All element categories in the P&ID scene */
export type ElementCategory =
  | 'equipment'
  | 'sensor'
  | 'connector'
  | 'label'
  | 'alarm'
  | 'command';

/** Visual primitive types that compose equipment symbols */
export type PrimitiveType = 'rect' | 'circle' | 'ellipse' | 'path' | 'polygon' | 'line';

/** A single vector primitive within a compound symbol */
export interface VisualPrimitive {
  type: PrimitiveType;
  /** Relative position within the symbol's local coordinate space */
  x: number;
  y: number;
  width?: number;
  height?: number;
  r?: number;           // circle radius
  rx?: number;          // ellipse
  ry?: number;          // ellipse
  d?: string;           // SVG path data
  points?: number[];    // polygon / polyline points
  fill: string;
  stroke: string;
  strokeWidth: number;
}

/** Equipment subtypes for realistic symbol diversity */
export type EquipmentSubtype =
  | 'pump'
  | 'valve'
  | 'tank'
  | 'heat_exchanger'
  | 'motor'
  | 'compressor'
  | 'filter'
  | 'vessel';

/** Sensor subtypes */
export type SensorSubtype =
  | 'temperature'
  | 'pressure'
  | 'flow'
  | 'level'
  | 'ph'
  | 'conductivity';

/** Control types for command-capable elements */
export type ControlType =
  | 'toggle'
  | 'numeric_stepper'
  | 'text_input'
  | 'dropdown'
  | 'push_button';

/** Alarm severity levels */
export type AlarmLevel = 'none' | 'info' | 'warning' | 'critical' | 'emergency';

/** Operational status for equipment */
export type OperationalStatus = 'running' | 'stopped' | 'fault' | 'maintenance' | 'standby';

/** A waypoint for orthogonal connector routing */
export interface Waypoint {
  x: number;
  y: number;
}

/** A single element in the canonical scene model */
export interface SceneElement {
  id: string;
  category: ElementCategory;
  subtype?: EquipmentSubtype | SensorSubtype;
  /** Position in the global scene coordinate space */
  x: number;
  y: number;
  width: number;
  height: number;
  /** Rotation in degrees (0, 90, 180, 270) */
  rotation: number;
  /** Visual primitives composing this element's symbol */
  primitives: VisualPrimitive[];
  /** Label / tag name */
  label: string;
  /** Current display value (for sensors) */
  value?: string;
  /** Units string (for sensors) */
  units?: string;
  /** Fill color (current state) */
  fill: string;
  /** Stroke color (current state) */
  stroke: string;
  /** Current operational status */
  status: OperationalStatus;
  /** Current alarm level */
  alarmLevel: AlarmLevel;
  /** Whether this element can receive operator commands */
  isCommandCapable: boolean;
  /** Type of control to show (if command-capable) */
  controlType?: ControlType;
  /** Dropdown options (if controlType === 'dropdown') */
  controlOptions?: string[];
  /** Whether the control is currently enabled */
  controlEnabled: boolean;
  /** Whether this element is visible */
  visible: boolean;
  /** Connector routing (only for 'connector' category) */
  connectorRouting?: {
    sourceId: string;
    targetId: string;
    waypoints: Waypoint[];
  };
  /** Z-index layer hint */
  zIndex: number;
}

/** The complete canonical scene model */
export interface SceneModel {
  id: string;
  name: string;
  version: string;
  /** Canvas bounds */
  bounds: { width: number; height: number };
  /** All elements */
  elements: SceneElement[];
  /** Metadata */
  meta: {
    generatedAt: string;
    totalElements: number;
    elementCounts: Record<ElementCategory, number>;
    sceneSize: SceneSize;
  };
}

/** Scene size tiers */
export type SceneSize = 'small' | 'medium' | 'large';

// ============================================================================
// LIVE UPDATE TYPES
// ============================================================================

/** Types of property updates the replay harness can dispatch */
export type UpdateType =
  | 'color_change'
  | 'value_change'
  | 'alarm_change'
  | 'control_enable'
  | 'visibility_change';

/** A single property update event */
export interface UpdateEvent {
  timestamp: number;       // ms offset from sequence start
  elementId: string;
  type: UpdateType;
  payload: UpdatePayload;
}

export type UpdatePayload =
  | { type: 'color_change'; fill?: string; stroke?: string; status: OperationalStatus }
  | { type: 'value_change'; value: string }
  | { type: 'alarm_change'; alarmLevel: AlarmLevel; fill: string; stroke: string }
  | { type: 'control_enable'; enabled: boolean }
  | { type: 'visibility_change'; visible: boolean };

/** A complete pre-recorded update sequence */
export interface UpdateSequence {
  id: string;
  name: string;
  rateTier: UpdateRateTier;
  durationMs: number;
  events: UpdateEvent[];
  meta: {
    updatesPerSecond: number;
    elementsAffectedPerSecond: number;
    updateTypeDistribution: Record<UpdateType, number>; // percentage
  };
}

export type UpdateRateTier = 'low' | 'realistic' | 'burst' | 'stress';

// ============================================================================
// BENCHMARK CONFIGURATION TYPES
// ============================================================================

/** The six variant identifiers */
export type VariantId = 'A' | 'B' | 'C' | 'D' | 'E' | 'F';

export interface VariantConfig {
  id: VariantId;
  renderer: 'svg' | 'konva';
  controlStrategy: 'none' | 'overlay' | 'pseudo';
  label: string;
}

/** Workload scenario identifiers */
export type WorkloadId =
  | 'W-INIT'
  | 'W-SWITCH'
  | 'W-PAN'
  | 'W-ZOOM'
  | 'W-LIVE-LO'
  | 'W-LIVE-MED'
  | 'W-LIVE-HI'
  | 'W-LIVE-STRESS'
  | 'W-ALARM'
  | 'W-INTERACT'
  | 'W-LONG'
  | 'W-MIXED';

/** Control density scenario identifiers */
export type ControlDensityId = 'C-0' | 'C-10' | 'C-30' | 'C-60' | 'C-CTX' | 'C-PSEUDO';

/** A single benchmark run configuration */
export interface BenchmarkRunConfig {
  variantId: VariantId;
  workloadId: WorkloadId;
  controlDensity: ControlDensityId;
  sceneSize: SceneSize;
  runIndex: number;
  warmUpMs: number;
  /** Whether this is a warm-up run (first 2 of 10) */
  isWarmUp: boolean;
}

/** Full benchmark matrix configuration */
export interface BenchmarkMatrixConfig {
  runsPerConfig: number;
  warmUpRuns: number;
  warmUpMs: number;
  variants: VariantConfig[];
  workloads: WorkloadId[];
  controlDensities: ControlDensityId[];
  sceneSizes: SceneSize[];
}

// ============================================================================
// METRICS TYPES
// ============================================================================

/** Raw frame-time sample */
export interface FrameSample {
  timestamp: number;
  deltaMs: number;
}

/** Aggregated statistics for a metric */
export interface MetricStats {
  min: number;
  max: number;
  mean: number;
  median: number;
  p95: number;
  p99: number;
  stdDev: number;
  count: number;
}

/** Latency measurement for a single interaction */
export interface LatencySample {
  interactionType: string;
  startMs: number;
  endMs: number;
  deltaMs: number;
}

/** Memory snapshot at a point in time */
export interface MemorySnapshot {
  timestampMs: number;
  heapUsedMB: number;
  heapTotalMB: number;
  externalMB: number;
  rss?: number;
}

/** Complete metrics collection for a single benchmark run */
export interface RunMetrics {
  config: BenchmarkRunConfig;
  /** Wall-clock start/end */
  startTime: number;
  endTime: number;
  /** Frame-time data */
  frameSamples: FrameSample[];
  frameStats: MetricStats;
  droppedFrames: number;       // frames > 33ms
  /** Interaction latencies */
  latencySamples: LatencySample[];
  clickToHighlight?: MetricStats;
  clickToControlOpen?: MetricStats;
  inputFocusLatency?: MetricStats;
  /** Timing metrics */
  initialRenderMs?: number;
  subDiagramSwitchMs?: number;
  /** Resource usage */
  memorySnapshots: MemorySnapshot[];
  avgCpuPercent?: number;
  /** Overlay-specific */
  overlayRepositionCostMs?: MetricStats;
}

/** Aggregated results across valid runs for one configuration */
export interface AggregatedResult {
  variantId: VariantId;
  workloadId: WorkloadId;
  controlDensity: ControlDensityId;
  sceneSize: SceneSize;
  validRuns: number;
  frameTimeStats: MetricStats;
  droppedFramesPerMin: MetricStats;
  clickToHighlight?: MetricStats;
  clickToControlOpen?: MetricStats;
  initialRenderMs?: MetricStats;
  subDiagramSwitchMs?: MetricStats;
  memoryGrowthPercent?: number;
  avgCpuPercent?: MetricStats;
}

// ============================================================================
// VIEWPORT / INTERACTION TYPES
// ============================================================================

export interface ViewportState {
  x: number;
  y: number;
  scale: number;
}

export interface InteractionEvent {
  type: 'click' | 'hover' | 'pan_start' | 'pan_move' | 'pan_end' | 'zoom';
  x: number;
  y: number;
  elementId?: string;
  timestamp: number;
}

// ============================================================================
// ELECTRON API BRIDGE
// ============================================================================

declare global {
  interface Window {
    electronAPI?: {
      getProcessMemory: () => Promise<NodeJS.MemoryUsage>;
      getRendererMetrics: () => Promise<Electron.ProcessMemoryInfo | null>;
    };
  }
}
