import { contextBridge, ipcRenderer } from 'electron';

contextBridge.exposeInMainWorld('electronAPI', {
  getProcessMemory: () => ipcRenderer.invoke('get-process-memory'),
  getRendererMetrics: () => ipcRenderer.invoke('get-renderer-metrics'),
});
