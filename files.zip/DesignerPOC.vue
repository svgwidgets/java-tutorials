<template>
  <!--
    P&ID Designer POC — Static Concept Demo
    =========================================
    Drop this file into your Vue project at: src/demo/DesignerPOC.vue
    Import your library components from wherever they live.
    
    This is a STATIC demo for showing peers the consumer app vision.
    All positions are hardcoded. No drag/drop yet. That's intentional —
    this proves the rendering pipeline and data model before adding interaction.
  -->
  <div class="designer">
    <!-- ─── Header / Toolbar ─── -->
    <header class="toolbar">
      <div class="toolbar-left">
        <span class="toolbar-logo">⬡ P&amp;ID Designer</span>
        <span class="toolbar-divider" />
        <span class="toolbar-filename">{{ diagram.name }}</span>
        <span class="toolbar-badge">POC</span>
      </div>

      <div class="toolbar-center">
        <button
          v-for="tool in tools"
          :key="tool.id"
          class="tool-btn"
          :class="{ active: activeTool === tool.id }"
          :title="tool.label"
          @click="activeTool = tool.id"
        >
          {{ tool.icon }}
          <span class="tool-label">{{ tool.label }}</span>
        </button>
        <span class="toolbar-divider" />
        <button class="tool-btn" title="Snap to Grid" :class="{ active: gridEnabled }" @click="gridEnabled = !gridEnabled">
          ⊞ <span class="tool-label">Grid</span>
        </button>
      </div>

      <div class="toolbar-right">
        <button class="action-btn" @click="handleValidate">✓ Validate</button>
        <button class="action-btn primary" @click="handleSave">↓ Save JSON</button>
        <button class="action-btn" @click="handleLoad">↑ Load</button>
      </div>
    </header>

    <div class="main-area">
      <!-- ─── Component Palette ─── -->
      <aside class="palette">
        <div class="palette-section">
          <div class="palette-heading">Components</div>
          <div class="palette-grid">
            <div
              v-for="item in paletteItems"
              :key="item.id"
              class="palette-item"
              :class="{ selected: selectedPaletteItem === item.id }"
              @click="selectedPaletteItem = item.id"
            >
              <svg :viewBox="item.viewBox" class="palette-preview">
                <g v-html="item.preview" />
              </svg>
              <span class="palette-item-name">{{ item.name }}</span>
              <span class="palette-item-io">{{ item.ioType }}</span>
            </div>
          </div>
        </div>

        <div class="palette-section">
          <div class="palette-heading">Connections</div>
          <div class="palette-grid">
            <div class="palette-item" :class="{ selected: selectedPaletteItem === 'pipe' }" @click="selectedPaletteItem = 'pipe'">
              <svg viewBox="0 0 60 20" class="palette-preview">
                <line x1="5" y1="10" x2="55" y2="10" stroke="#8b949e" stroke-width="3" />
                <line x1="5" y1="10" x2="55" y2="10" stroke="#58a6ff" stroke-width="2" stroke-dasharray="6 4" opacity="0.7" />
              </svg>
              <span class="palette-item-name">Pipe</span>
              <span class="palette-item-io">conn</span>
            </div>
            <div class="palette-item" :class="{ selected: selectedPaletteItem === 'junction-tee' }" @click="selectedPaletteItem = 'junction-tee'">
              <svg viewBox="0 0 30 30" class="palette-preview">
                <circle cx="15" cy="15" r="5" fill="#8b949e" stroke="#ccc" stroke-width="1.5" />
                <line x1="5" y1="15" x2="10" y2="15" stroke="#8b949e" stroke-width="2" />
                <line x1="20" y1="15" x2="25" y2="15" stroke="#8b949e" stroke-width="2" />
                <line x1="15" y1="5" x2="15" y2="10" stroke="#8b949e" stroke-width="2" />
              </svg>
              <span class="palette-item-name">Tee</span>
              <span class="palette-item-io">junction</span>
            </div>
          </div>
        </div>

        <div class="palette-section">
          <div class="palette-heading">Diagram Info</div>
          <div class="palette-info">
            <div class="info-row">
              <span class="info-label">Nodes</span>
              <span class="info-value">{{ diagram.nodes.length }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Connections</span>
              <span class="info-value">{{ diagram.connections.length }}</span>
            </div>
            <div class="info-row">
              <span class="info-label">Schema</span>
              <span class="info-value">v{{ diagram.version }}</span>
            </div>
          </div>
        </div>
      </aside>

      <!-- ─── Canvas ─── -->
      <div class="canvas-wrapper" ref="canvasWrapper">
        <svg
          class="canvas-svg"
          :viewBox="`${viewBox.x} ${viewBox.y} ${viewBox.w} ${viewBox.h}`"
          @wheel.prevent="handleWheel"
          @mousedown="handleCanvasMouseDown"
          @mousemove="handleCanvasMouseMove"
          @mouseup="handleCanvasMouseUp"
        >
          <defs>
            <!-- Grid pattern -->
            <pattern id="grid-small" :width="gridSize" :height="gridSize" patternUnits="userSpaceOnUse">
              <path :d="`M ${gridSize} 0 L 0 0 0 ${gridSize}`" fill="none" stroke="rgba(255,255,255,0.03)" stroke-width="0.5" />
            </pattern>
            <pattern id="grid-large" :width="gridSize * 5" :height="gridSize * 5" patternUnits="userSpaceOnUse">
              <rect :width="gridSize * 5" :height="gridSize * 5" fill="url(#grid-small)" />
              <path :d="`M ${gridSize * 5} 0 L 0 0 0 ${gridSize * 5}`" fill="none" stroke="rgba(255,255,255,0.06)" stroke-width="0.5" />
            </pattern>
          </defs>

          <!-- Grid background -->
          <rect
            v-if="gridEnabled"
            x="-2000" y="-2000" width="6000" height="6000"
            fill="url(#grid-large)"
          />

          <!-- ═══════════════════════════════════════════ -->
          <!--  CONNECTIONS (rendered BELOW components)    -->
          <!-- ═══════════════════════════════════════════ -->
          <g class="connections-layer">
            <g
              v-for="conn in diagram.connections"
              :key="conn.id"
              class="connection-group"
              :class="{ selected: selectedId === conn.id }"
              @click.stop="selectedId = conn.id"
            >
              <!-- Pipe background (thicker, for hit area) -->
              <path
                :d="computePipePath(conn)"
                fill="none"
                stroke="transparent"
                stroke-width="12"
                class="pipe-hitarea"
              />
              <!-- Pipe body -->
              <path
                :d="computePipePath(conn)"
                fill="none"
                :stroke="conn.props.flowing ? '#58a6ff' : '#555d66'"
                stroke-width="3"
                stroke-linecap="round"
                stroke-linejoin="round"
                class="pipe-body"
              />
              <!-- Flow animation -->
              <path
                v-if="conn.props.flowing"
                :d="computePipePath(conn)"
                fill="none"
                stroke="#8dc8ff"
                stroke-width="2"
                stroke-dasharray="8 6"
                stroke-linecap="round"
                class="pipe-flow"
              />
              <!-- Selection highlight -->
              <path
                v-if="selectedId === conn.id"
                :d="computePipePath(conn)"
                fill="none"
                stroke="rgba(88,166,255,0.3)"
                stroke-width="8"
                stroke-linecap="round"
                stroke-linejoin="round"
              />
              <!-- Pipe label -->
              <text
                v-if="conn.props.label"
                :x="computePipeMidpoint(conn).x"
                :y="computePipeMidpoint(conn).y - 8"
                text-anchor="middle"
                class="pipe-label"
              >
                {{ conn.props.label }}
              </text>
            </g>
          </g>

          <!-- ═══════════════════════════════════════════ -->
          <!--  NODES (components placed on canvas)       -->
          <!-- ═══════════════════════════════════════════ -->
          <g class="nodes-layer">
            <g
              v-for="node in diagram.nodes"
              :key="node.id"
              class="node-group"
              :class="{ selected: selectedId === node.id }"
              :transform="`translate(${node.position.x}, ${node.position.y})`"
              @click.stop="selectedId = node.id"
            >
              <!-- Selection box -->
              <rect
                v-if="selectedId === node.id"
                :x="getNodeBounds(node).x - 4"
                :y="getNodeBounds(node).y - 4"
                :width="getNodeBounds(node).w + 8"
                :height="getNodeBounds(node).h + 8"
                fill="rgba(88,166,255,0.08)"
                stroke="#58a6ff"
                stroke-width="1.5"
                stroke-dasharray="4 2"
                rx="3"
              />

              <!-- ── ManualValve ── -->
              <g v-if="node.typeId === 'manual-valve'">
                <path
                  d="M 0 0 L 20 12 L 0 24 Z"
                  :fill="node.props.state === 'open' ? '#3fb950' : '#f85149'"
                  stroke="#ccc"
                  stroke-width="1.5"
                />
                <path
                  d="M 40 0 L 20 12 L 40 24 Z"
                  :fill="node.props.state === 'open' ? '#3fb950' : '#f85149'"
                  stroke="#ccc"
                  stroke-width="1.5"
                />
                <!-- Ports -->
                <circle cx="0" cy="12" r="3" :fill="'#58a6ff'" stroke="#ccc" stroke-width="1" class="port" />
                <circle cx="40" cy="12" r="3" :fill="'#d29922'" stroke="#ccc" stroke-width="1" class="port" />
                <!-- Label -->
                <text x="20" y="-6" text-anchor="middle" class="node-label">{{ node.label }}</text>
                <!-- State badge -->
                <text x="20" y="36" text-anchor="middle" class="node-state" :fill="node.props.state === 'open' ? '#3fb950' : '#f85149'">
                  {{ node.props.state?.toUpperCase() }}
                </text>
              </g>

              <!-- ── CentrifugalPump ── -->
              <g v-else-if="node.typeId === 'centrifugal-pump'">
                <circle
                  cx="20" cy="20" r="18"
                  :fill="node.props.state === 'running' ? '#3fb950' : '#555d66'"
                  stroke="#ccc"
                  stroke-width="1.5"
                />
                <!-- Impeller blades -->
                <g :class="{ 'rotating': node.props.state === 'running' }" style="transform-origin: 20px 20px;">
                  <line x1="20" y1="6" x2="20" y2="34" stroke="#fff" stroke-width="2" opacity="0.6" />
                  <line x1="6" y1="20" x2="34" y2="20" stroke="#fff" stroke-width="2" opacity="0.6" />
                  <line x1="10" y1="10" x2="30" y2="30" stroke="#fff" stroke-width="1.5" opacity="0.4" />
                  <line x1="30" y1="10" x2="10" y2="30" stroke="#fff" stroke-width="1.5" opacity="0.4" />
                </g>
                <!-- Discharge nozzle -->
                <rect x="36" y="14" width="8" height="12" :fill="node.props.state === 'running' ? '#3fb950' : '#555d66'" stroke="#ccc" stroke-width="1" />
                <!-- Ports -->
                <circle cx="0" cy="20" r="3" fill="#58a6ff" stroke="#ccc" stroke-width="1" class="port" />
                <circle cx="44" cy="20" r="3" fill="#d29922" stroke="#ccc" stroke-width="1" class="port" />
                <!-- Label -->
                <text x="22" y="-6" text-anchor="middle" class="node-label">{{ node.label }}</text>
                <text x="22" y="52" text-anchor="middle" class="node-state" :fill="node.props.state === 'running' ? '#3fb950' : '#f85149'">
                  {{ node.props.state === 'running' ? 'RUNNING' : 'STOPPED' }}
                </text>
              </g>

              <!-- ── VerticalTank ── -->
              <g v-else-if="node.typeId === 'vertical-tank'">
                <!-- Tank outline -->
                <rect x="0" y="0" width="60" height="120" rx="4" fill="none" stroke="#ccc" stroke-width="1.5" />
                <!-- Liquid fill -->
                <rect
                  x="1.5" :y="120 - (node.props.level / 100 * 117) - 1.5"
                  width="57" :height="node.props.level / 100 * 117"
                  rx="2"
                  :fill="levelColor(node.props.level)"
                  opacity="0.7"
                />
                <!-- Level text -->
                <text x="30" y="65" text-anchor="middle" class="tank-level-text">
                  {{ Math.round(node.props.level) }}%
                </text>
                <!-- Ports -->
                <circle cx="30" cy="0" r="3" fill="#58a6ff" stroke="#ccc" stroke-width="1" class="port" />
                <circle cx="30" cy="120" r="3" fill="#d29922" stroke="#ccc" stroke-width="1" class="port" />
                <circle cx="60" cy="60" r="3" fill="#d29922" stroke="#ccc" stroke-width="1" class="port" />
                <!-- Label -->
                <text x="30" y="-10" text-anchor="middle" class="node-label">{{ node.label }}</text>
              </g>

              <!-- ── PressureSensor ── -->
              <g v-else-if="node.typeId === 'pressure-sensor'">
                <circle
                  cx="16" cy="16" r="14"
                  fill="#21262d"
                  :stroke="sensorAlarmColor(node.props.alarm)"
                  stroke-width="2"
                />
                <text x="16" y="13" text-anchor="middle" class="sensor-value">
                  {{ formatValue(node.props.value, 1) }}
                </text>
                <text x="16" y="23" text-anchor="middle" class="sensor-unit">
                  {{ node.props.units }}
                </text>
                <!-- Port -->
                <circle cx="16" cy="32" r="3" fill="#58a6ff" stroke="#ccc" stroke-width="1" class="port" />
                <!-- Label -->
                <text x="16" y="-6" text-anchor="middle" class="node-label">{{ node.label }}</text>
              </g>

              <!-- ── TemperatureSensor ── -->
              <g v-else-if="node.typeId === 'temperature-sensor'">
                <circle
                  cx="16" cy="16" r="14"
                  fill="#21262d"
                  :stroke="sensorAlarmColor(node.props.alarm)"
                  stroke-width="2"
                />
                <text x="16" y="13" text-anchor="middle" class="sensor-value">
                  {{ formatValue(node.props.value, 1) }}
                </text>
                <text x="16" y="23" text-anchor="middle" class="sensor-unit">
                  {{ node.props.units }}
                </text>
                <!-- Port -->
                <circle cx="16" cy="32" r="3" fill="#58a6ff" stroke="#ccc" stroke-width="1" class="port" />
                <!-- Label -->
                <text x="16" y="-6" text-anchor="middle" class="node-label">{{ node.label }}</text>
              </g>

              <!-- ── Junction Tee ── -->
              <g v-else-if="node.typeId === 'junction-tee'">
                <circle cx="5" cy="5" r="4" fill="#8b949e" stroke="#ccc" stroke-width="1" />
                <!-- Ports -->
                <circle cx="0" cy="5" r="2.5" fill="#58a6ff" stroke="#ccc" stroke-width="0.5" class="port" />
                <circle cx="10" cy="5" r="2.5" fill="#d29922" stroke="#ccc" stroke-width="0.5" class="port" />
                <circle cx="5" cy="0" r="2.5" fill="#d29922" stroke="#ccc" stroke-width="0.5" class="port" />
              </g>
            </g>
          </g>

          <!-- ═══════════════════════════════════════════ -->
          <!--  ANNOTATIONS (flow arrows, labels, etc.)   -->
          <!-- ═══════════════════════════════════════════ -->
          <g class="annotations-layer">
            <!-- Title block -->
            <g transform="translate(680, 520)">
              <rect x="0" y="0" width="260" height="60" fill="#161b22" stroke="#30363d" stroke-width="1" rx="3" />
              <text x="130" y="20" text-anchor="middle" class="title-block-title">{{ diagram.name }}</text>
              <text x="130" y="36" text-anchor="middle" class="title-block-sub">Schema v{{ diagram.version }} · {{ diagram.nodes.length }} nodes · {{ diagram.connections.length }} connections</text>
              <text x="130" y="50" text-anchor="middle" class="title-block-date">{{ diagram.updatedAt }}</text>
            </g>
          </g>
        </svg>

        <!-- Zoom controls -->
        <div class="zoom-controls">
          <button class="zoom-btn" @click="zoomIn" title="Zoom In">+</button>
          <span class="zoom-level">{{ Math.round(zoomLevel * 100) }}%</span>
          <button class="zoom-btn" @click="zoomOut" title="Zoom Out">−</button>
          <button class="zoom-btn" @click="zoomFit" title="Fit to View">⊡</button>
        </div>
      </div>

      <!-- ─── Property Panel ─── -->
      <aside class="properties">
        <div v-if="selectedNode" class="prop-panel">
          <div class="prop-header">
            <span class="prop-type">{{ selectedNode.typeId }}</span>
            <span class="prop-id">{{ selectedNode.id }}</span>
          </div>

          <div class="prop-section">
            <div class="prop-section-title">Identity</div>
            <div class="prop-row">
              <label class="prop-label">Label</label>
              <input class="prop-input" :value="selectedNode.label" readonly />
            </div>
            <div class="prop-row">
              <label class="prop-label">Position</label>
              <div class="prop-pos">
                <span class="prop-coord">X: {{ selectedNode.position.x }}</span>
                <span class="prop-coord">Y: {{ selectedNode.position.y }}</span>
              </div>
            </div>
            <div class="prop-row">
              <label class="prop-label">Rotation</label>
              <span class="prop-value">{{ selectedNode.rotation }}°</span>
            </div>
          </div>

          <div class="prop-section">
            <div class="prop-section-title">Properties</div>
            <div v-for="(val, key) in selectedNode.props" :key="key" class="prop-row">
              <label class="prop-label">{{ key }}</label>
              <span class="prop-value" :class="propValueClass(key as string, val)">{{ val }}</span>
            </div>
          </div>

          <div class="prop-section">
            <div class="prop-section-title">Ports</div>
            <div v-for="port in getNodePorts(selectedNode)" :key="port.id" class="prop-row">
              <label class="prop-label">{{ port.id }}</label>
              <span class="prop-value port-connected" v-if="isPortConnected(selectedNode.id, port.id)">● connected</span>
              <span class="prop-value port-free" v-else>○ free</span>
            </div>
          </div>
        </div>

        <div v-else-if="selectedConnection" class="prop-panel">
          <div class="prop-header">
            <span class="prop-type">Pipe</span>
            <span class="prop-id">{{ selectedConnection.id }}</span>
          </div>
          <div class="prop-section">
            <div class="prop-section-title">Endpoints</div>
            <div class="prop-row">
              <label class="prop-label">From</label>
              <span class="prop-value">{{ selectedConnection.from.nodeId }} : {{ selectedConnection.from.portId }}</span>
            </div>
            <div class="prop-row">
              <label class="prop-label">To</label>
              <span class="prop-value">{{ selectedConnection.to.nodeId }} : {{ selectedConnection.to.portId }}</span>
            </div>
          </div>
          <div class="prop-section">
            <div class="prop-section-title">Routing</div>
            <div class="prop-row">
              <label class="prop-label">Waypoints</label>
              <span class="prop-value">{{ selectedConnection.waypoints.length }}</span>
            </div>
            <div v-for="(wp, i) in selectedConnection.waypoints" :key="i" class="prop-row indent">
              <label class="prop-label">wp[{{ i }}]</label>
              <span class="prop-value">{{ wp.x }}, {{ wp.y }}</span>
            </div>
          </div>
          <div class="prop-section">
            <div class="prop-section-title">State</div>
            <div v-for="(val, key) in selectedConnection.props" :key="key" class="prop-row">
              <label class="prop-label">{{ key }}</label>
              <span class="prop-value" :class="propValueClass(key as string, val)">{{ val }}</span>
            </div>
          </div>
        </div>

        <div v-else class="prop-empty">
          <div class="prop-empty-icon">⊘</div>
          <div class="prop-empty-text">Select a component or pipe to inspect its properties</div>
        </div>

        <!-- JSON Preview -->
        <div class="json-preview">
          <div class="json-header" @click="jsonExpanded = !jsonExpanded">
            <span>{{ jsonExpanded ? '▾' : '▸' }} Diagram JSON</span>
            <button class="json-copy" @click.stop="copyJson">Copy</button>
          </div>
          <pre v-if="jsonExpanded" class="json-body">{{ diagramJson }}</pre>
        </div>
      </aside>
    </div>

    <!-- ─── Footer / Status Bar ─── -->
    <footer class="statusbar">
      <span class="status-item">Tool: <strong>{{ activeTool }}</strong></span>
      <span class="status-item">Grid: <strong>{{ gridSize }}px</strong></span>
      <span class="status-item">Zoom: <strong>{{ Math.round(zoomLevel * 100) }}%</strong></span>
      <span class="status-item" v-if="selectedId">Selected: <strong>{{ selectedId }}</strong></span>
      <span class="status-spacer" />
      <span class="status-item status-valid">
        <span class="status-dot" /> {{ validationResult }}
      </span>
    </footer>

    <!-- Toast notification -->
    <Transition name="toast">
      <div v-if="toast" class="toast" :class="toast.type">
        {{ toast.message }}
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, reactive, onMounted } from 'vue'

// ═══════════════════════════════════════════
//  TYPES (matches the proposed schema)
// ═══════════════════════════════════════════

interface Position { x: number; y: number }

interface DiagramNode {
  id: string
  typeId: string
  position: Position
  rotation: number
  label: string
  props: Record<string, any>
}

interface DiagramConnection {
  id: string
  from: { nodeId: string; portId: string }
  to: { nodeId: string; portId: string }
  waypoints: Position[]
  props: Record<string, any>
}

interface DiagramSchema {
  version: number
  id: string
  name: string
  createdAt: string
  updatedAt: string
  canvas: { width: number; height: number; gridSize: number; gridEnabled: boolean }
  nodes: DiagramNode[]
  connections: DiagramConnection[]
}

interface PortDef { id: string; position: Position; direction: string }

// ═══════════════════════════════════════════
//  PORT REGISTRY (from library)
// ═══════════════════════════════════════════

const PORT_REGISTRY: Record<string, PortDef[]> = {
  'manual-valve': [
    { id: 'inlet', position: { x: 0, y: 12 }, direction: 'left' },
    { id: 'outlet', position: { x: 40, y: 12 }, direction: 'right' },
  ],
  'centrifugal-pump': [
    { id: 'inlet', position: { x: 0, y: 20 }, direction: 'left' },
    { id: 'outlet', position: { x: 44, y: 20 }, direction: 'right' },
  ],
  'vertical-tank': [
    { id: 'top', position: { x: 30, y: 0 }, direction: 'up' },
    { id: 'bottom', position: { x: 30, y: 120 }, direction: 'down' },
    { id: 'side', position: { x: 60, y: 60 }, direction: 'right' },
  ],
  'pressure-sensor': [
    { id: 'bottom', position: { x: 16, y: 32 }, direction: 'down' },
  ],
  'temperature-sensor': [
    { id: 'bottom', position: { x: 16, y: 32 }, direction: 'down' },
  ],
  'junction-tee': [
    { id: 'a', position: { x: 0, y: 5 }, direction: 'left' },
    { id: 'b', position: { x: 10, y: 5 }, direction: 'right' },
    { id: 'c', position: { x: 5, y: 0 }, direction: 'up' },
  ],
}

function getPortWorldPosition(nodeId: string, portId: string): Position {
  const node = diagram.nodes.find(n => n.id === nodeId)
  if (!node) return { x: 0, y: 0 }
  const ports = PORT_REGISTRY[node.typeId] || []
  const port = ports.find(p => p.id === portId)
  if (!port) return { x: node.position.x, y: node.position.y }
  return {
    x: node.position.x + port.position.x,
    y: node.position.y + port.position.y,
  }
}

// ═══════════════════════════════════════════
//  DIAGRAM DATA (static demo — Water Treatment)
// ═══════════════════════════════════════════

const diagram = reactive<DiagramSchema>({
  version: 1,
  id: 'demo-water-treatment',
  name: 'Water Treatment — Stage 1',
  createdAt: '2026-02-17T10:00:00Z',
  updatedAt: '2026-02-17T14:30:00Z',
  canvas: { width: 1000, height: 600, gridSize: 10, gridEnabled: true },
  nodes: [
    // Feed tank
    { id: 'T-001', typeId: 'vertical-tank', position: { x: 60, y: 140 }, rotation: 0, label: 'T-001', props: { level: 72, units: 'L', alarm: 'none' } },
    // Inlet valve
    { id: 'V-001', typeId: 'manual-valve', position: { x: 200, y: 248 }, rotation: 0, label: 'V-001', props: { state: 'open', alarm: 'none' } },
    // Feed pump
    { id: 'P-001', typeId: 'centrifugal-pump', position: { x: 310, y: 240 }, rotation: 0, label: 'P-001', props: { state: 'running', alarm: 'none' } },
    // Process tank
    { id: 'T-002', typeId: 'vertical-tank', position: { x: 500, y: 140 }, rotation: 0, label: 'T-002', props: { level: 45, units: 'L', alarm: 'none' } },
    // Outlet valve
    { id: 'V-002', typeId: 'manual-valve', position: { x: 620, y: 248 }, rotation: 0, label: 'V-002', props: { state: 'closed', alarm: 'none' } },
    // Pressure sensor (on junction between pump and tank)
    { id: 'PT-001', typeId: 'pressure-sensor', position: { x: 418, y: 150 }, rotation: 0, label: 'PT-001', props: { value: 125.5, units: 'PSI', alarm: 'none' } },
    // Temperature sensor on process tank
    { id: 'TT-001', typeId: 'temperature-sensor', position: { x: 574, y: 70 }, rotation: 0, label: 'TT-001', props: { value: 42.3, units: '°C', alarm: 'warning' } },
    // Junction tee (branch point for pressure sensor)
    { id: 'J-001', typeId: 'junction-tee', position: { x: 429, y: 255 }, rotation: 0, label: '', props: {} },
  ],
  connections: [
    // T-001 bottom → V-001 inlet
    {
      id: 'conn-1', from: { nodeId: 'T-001', portId: 'bottom' }, to: { nodeId: 'V-001', portId: 'inlet' },
      waypoints: [{ x: 90, y: 280 }, { x: 160, y: 280 }, { x: 160, y: 260 }],
      props: { flowing: true, label: '' },
    },
    // V-001 outlet → P-001 inlet
    {
      id: 'conn-2', from: { nodeId: 'V-001', portId: 'outlet' }, to: { nodeId: 'P-001', portId: 'inlet' },
      waypoints: [],
      props: { flowing: true, label: '' },
    },
    // P-001 outlet → J-001 port a (junction)
    {
      id: 'conn-3', from: { nodeId: 'P-001', portId: 'outlet' }, to: { nodeId: 'J-001', portId: 'a' },
      waypoints: [{ x: 400, y: 260 }],
      props: { flowing: true, label: '' },
    },
    // J-001 port b → T-002 top
    {
      id: 'conn-4', from: { nodeId: 'J-001', portId: 'b' }, to: { nodeId: 'T-002', portId: 'top' },
      waypoints: [{ x: 470, y: 260 }, { x: 470, y: 120 }, { x: 530, y: 120 }],
      props: { flowing: true, label: '' },
    },
    // J-001 port c → PT-001 bottom (branch up to sensor)
    {
      id: 'conn-5', from: { nodeId: 'J-001', portId: 'c' }, to: { nodeId: 'PT-001', portId: 'bottom' },
      waypoints: [],
      props: { flowing: false, label: '' },
    },
    // T-002 side → V-002 inlet
    {
      id: 'conn-6', from: { nodeId: 'T-002', portId: 'side' }, to: { nodeId: 'V-002', portId: 'inlet' },
      waypoints: [{ x: 590, y: 200 }, { x: 590, y: 260 }],
      props: { flowing: false, label: '' },
    },
    // TT-001 → T-002 top (sensor taps into top of tank)
    {
      id: 'conn-7', from: { nodeId: 'TT-001', portId: 'bottom' }, to: { nodeId: 'T-002', portId: 'top' },
      waypoints: [{ x: 590, y: 120 }, { x: 530, y: 120 }],
      props: { flowing: false, label: '' },
    },
  ],
})

// ═══════════════════════════════════════════
//  UI STATE
// ═══════════════════════════════════════════

const selectedId = ref<string | null>(null)
const activeTool = ref('select')
const gridEnabled = ref(true)
const gridSize = ref(10)
const selectedPaletteItem = ref<string | null>(null)
const jsonExpanded = ref(false)
const toast = ref<{ message: string; type: string } | null>(null)
const zoomLevel = ref(1)
const viewBox = reactive({ x: -30, y: 30, w: 1000, h: 600 })
const isPanning = ref(false)
const panStart = reactive({ x: 0, y: 0 })

const tools = [
  { id: 'select', icon: '⊹', label: 'Select' },
  { id: 'place', icon: '⊕', label: 'Place' },
  { id: 'wire', icon: '⟜', label: 'Wire' },
  { id: 'pan', icon: '⊞', label: 'Pan' },
]

const paletteItems = [
  { id: 'manual-valve', name: 'Valve', ioType: 'digital', viewBox: '0 0 40 24', preview: '<path d="M 0 0 L 20 12 L 0 24 Z" fill="#555" stroke="#aaa" stroke-width="1"/><path d="M 40 0 L 20 12 L 40 24 Z" fill="#555" stroke="#aaa" stroke-width="1"/>' },
  { id: 'centrifugal-pump', name: 'Pump', ioType: 'digital', viewBox: '0 0 44 40', preview: '<circle cx="20" cy="20" r="16" fill="#555" stroke="#aaa" stroke-width="1"/><rect x="34" y="14" width="8" height="12" fill="#555" stroke="#aaa" stroke-width="1"/>' },
  { id: 'vertical-tank', name: 'Tank', ioType: 'analog', viewBox: '0 0 60 120', preview: '<rect x="2" y="2" width="56" height="116" rx="3" fill="none" stroke="#aaa" stroke-width="1.5"/><rect x="4" y="50" width="52" height="66" rx="2" fill="#2a5d8f" opacity="0.5"/>' },
  { id: 'pressure-sensor', name: 'Pressure', ioType: 'analog', viewBox: '0 0 32 34', preview: '<circle cx="16" cy="16" r="13" fill="#21262d" stroke="#3fb950" stroke-width="1.5"/><text x="16" y="14" text-anchor="middle" font-size="7" fill="#ccc" font-family="monospace">PSI</text>' },
  { id: 'temperature-sensor', name: 'Temp', ioType: 'analog', viewBox: '0 0 32 34', preview: '<circle cx="16" cy="16" r="13" fill="#21262d" stroke="#d29922" stroke-width="1.5"/><text x="16" y="14" text-anchor="middle" font-size="7" fill="#ccc" font-family="monospace">°C</text>' },
]

// ═══════════════════════════════════════════
//  COMPUTED
// ═══════════════════════════════════════════

const selectedNode = computed(() => diagram.nodes.find(n => n.id === selectedId.value) || null)
const selectedConnection = computed(() => diagram.connections.find(c => c.id === selectedId.value) || null)

const diagramJson = computed(() => JSON.stringify(diagram, null, 2))

const validationResult = computed(() => {
  const errors: string[] = []
  // Check for dangling connections
  for (const conn of diagram.connections) {
    if (!diagram.nodes.find(n => n.id === conn.from.nodeId)) errors.push(`Missing node: ${conn.from.nodeId}`)
    if (!diagram.nodes.find(n => n.id === conn.to.nodeId)) errors.push(`Missing node: ${conn.to.nodeId}`)
  }
  // Check duplicate IDs
  const ids = [...diagram.nodes.map(n => n.id), ...diagram.connections.map(c => c.id)]
  const dupes = ids.filter((id, i) => ids.indexOf(id) !== i)
  if (dupes.length) errors.push(`Duplicate IDs: ${dupes.join(', ')}`)
  return errors.length ? `${errors.length} error(s)` : 'Valid ✓'
})

// ═══════════════════════════════════════════
//  PIPE PATH COMPUTATION
// ═══════════════════════════════════════════

function computePipePath(conn: DiagramConnection): string {
  const start = getPortWorldPosition(conn.from.nodeId, conn.from.portId)
  const end = getPortWorldPosition(conn.to.nodeId, conn.to.portId)
  const allPoints = [start, ...conn.waypoints, end]

  if (allPoints.length < 2) return ''
  const commands = [`M ${allPoints[0].x} ${allPoints[0].y}`]
  for (let i = 1; i < allPoints.length; i++) {
    commands.push(`L ${allPoints[i].x} ${allPoints[i].y}`)
  }
  return commands.join(' ')
}

function computePipeMidpoint(conn: DiagramConnection): Position {
  const start = getPortWorldPosition(conn.from.nodeId, conn.from.portId)
  const end = getPortWorldPosition(conn.to.nodeId, conn.to.portId)
  const allPoints = [start, ...conn.waypoints, end]
  const mid = Math.floor(allPoints.length / 2)
  return allPoints[mid] || start
}

// ═══════════════════════════════════════════
//  HELPERS
// ═══════════════════════════════════════════

function levelColor(level: number): string {
  if (level > 90) return '#f85149'
  if (level > 75) return '#d29922'
  if (level > 20) return '#2a6db5'
  return '#f85149'
}

function sensorAlarmColor(alarm: string): string {
  if (alarm === 'alarm') return '#f85149'
  if (alarm === 'warning') return '#d29922'
  return '#3fb950'
}

function formatValue(val: number, precision: number): string {
  return val.toFixed(precision)
}

function getNodeBounds(node: DiagramNode): { x: number; y: number; w: number; h: number } {
  const sizes: Record<string, { w: number; h: number }> = {
    'manual-valve': { w: 40, h: 24 },
    'centrifugal-pump': { w: 44, h: 40 },
    'vertical-tank': { w: 60, h: 120 },
    'pressure-sensor': { w: 32, h: 34 },
    'temperature-sensor': { w: 32, h: 34 },
    'junction-tee': { w: 10, h: 10 },
  }
  const s = sizes[node.typeId] || { w: 40, h: 40 }
  return { x: 0, y: 0, w: s.w, h: s.h }
}

function getNodePorts(node: DiagramNode): PortDef[] {
  return PORT_REGISTRY[node.typeId] || []
}

function isPortConnected(nodeId: string, portId: string): boolean {
  return diagram.connections.some(
    c => (c.from.nodeId === nodeId && c.from.portId === portId) ||
         (c.to.nodeId === nodeId && c.to.portId === portId)
  )
}

function propValueClass(key: string, val: any): string {
  if (key === 'state') return val === 'open' || val === 'running' ? 'val-green' : 'val-red'
  if (key === 'alarm') return val === 'alarm' ? 'val-red' : val === 'warning' ? 'val-orange' : 'val-green'
  if (key === 'flowing') return val ? 'val-blue' : 'val-muted'
  return ''
}

// ═══════════════════════════════════════════
//  CANVAS INTERACTIONS
// ═══════════════════════════════════════════

function handleWheel(e: WheelEvent) {
  const factor = e.deltaY > 0 ? 1.08 : 0.92
  zoomLevel.value = Math.max(0.3, Math.min(4, zoomLevel.value * (1 / factor)))
  viewBox.w *= factor
  viewBox.h *= factor
}

function handleCanvasMouseDown(e: MouseEvent) {
  if (activeTool.value === 'pan' || e.button === 1) {
    isPanning.value = true
    panStart.x = e.clientX
    panStart.y = e.clientY
  } else {
    selectedId.value = null
  }
}

function handleCanvasMouseMove(e: MouseEvent) {
  if (isPanning.value) {
    const scale = viewBox.w / (e.target as SVGElement).getBoundingClientRect().width
    viewBox.x -= (e.clientX - panStart.x) * scale
    viewBox.y -= (e.clientY - panStart.y) * scale
    panStart.x = e.clientX
    panStart.y = e.clientY
  }
}

function handleCanvasMouseUp() {
  isPanning.value = false
}

function zoomIn() {
  zoomLevel.value = Math.min(4, zoomLevel.value * 1.2)
  viewBox.w /= 1.2
  viewBox.h /= 1.2
}

function zoomOut() {
  zoomLevel.value = Math.max(0.3, zoomLevel.value / 1.2)
  viewBox.w *= 1.2
  viewBox.h *= 1.2
}

function zoomFit() {
  zoomLevel.value = 1
  viewBox.x = -30
  viewBox.y = 30
  viewBox.w = 1000
  viewBox.h = 600
}

// ═══════════════════════════════════════════
//  TOOLBAR ACTIONS
// ═══════════════════════════════════════════

function showToast(message: string, type: string = 'info') {
  toast.value = { message, type }
  setTimeout(() => { toast.value = null }, 2500)
}

function handleValidate() {
  const errors = []
  for (const conn of diagram.connections) {
    if (!diagram.nodes.find(n => n.id === conn.from.nodeId)) errors.push(`Dangling: ${conn.id} → from ${conn.from.nodeId}`)
    if (!diagram.nodes.find(n => n.id === conn.to.nodeId)) errors.push(`Dangling: ${conn.id} → to ${conn.to.nodeId}`)
  }
  if (errors.length) {
    showToast(`Validation failed: ${errors.length} error(s)`, 'error')
  } else {
    showToast(`Diagram valid — ${diagram.nodes.length} nodes, ${diagram.connections.length} connections`, 'success')
  }
}

function handleSave() {
  const json = JSON.stringify(diagram, null, 2)
  const blob = new Blob([json], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${diagram.id}.json`
  a.click()
  URL.revokeObjectURL(url)
  showToast('Diagram saved as JSON', 'success')
}

function handleLoad() {
  showToast('Load from file — coming in POC v0.2', 'info')
}

function copyJson() {
  navigator.clipboard?.writeText(diagramJson.value)
  showToast('JSON copied to clipboard', 'success')
}

onMounted(() => {
  showToast('Static demo loaded — click components to inspect', 'info')
})
</script>

<style scoped>
/* ═══════════════════════════════════════════ */
/*  LAYOUT                                     */
/* ═══════════════════════════════════════════ */
.designer {
  display: grid;
  grid-template-rows: 44px 1fr 28px;
  height: 100vh;
  width: 100vw;
  overflow: hidden;
  font-family: 'IBM Plex Sans', -apple-system, BlinkMacSystemFont, sans-serif;
  background: #0e1117;
  color: #e6edf3;
  font-size: 13px;
}

.main-area {
  display: grid;
  grid-template-columns: 200px 1fr 250px;
  overflow: hidden;
}

/* ═══════════════════════════════════════════ */
/*  TOOLBAR                                    */
/* ═══════════════════════════════════════════ */
.toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px;
  background: #161b22;
  border-bottom: 1px solid #30363d;
}
.toolbar-left, .toolbar-center, .toolbar-right { display: flex; align-items: center; gap: 8px; }
.toolbar-logo { font-weight: 600; font-size: 13px; letter-spacing: -0.01em; }
.toolbar-divider { width: 1px; height: 18px; background: #30363d; margin: 0 4px; }
.toolbar-filename { font-size: 12px; color: #8b949e; }
.toolbar-badge {
  font-size: 9px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.06em;
  padding: 2px 6px; background: rgba(88,166,255,0.12); color: #58a6ff;
  border: 1px solid rgba(88,166,255,0.25); border-radius: 10px;
}
.tool-btn {
  display: flex; align-items: center; gap: 4px;
  padding: 4px 8px; background: transparent; border: 1px solid transparent;
  color: #8b949e; font-size: 12px; font-family: inherit; border-radius: 4px;
  cursor: pointer; transition: all 0.12s;
}
.tool-btn:hover { background: #282e36; color: #e6edf3; border-color: #30363d; }
.tool-btn.active { background: rgba(88,166,255,0.12); color: #58a6ff; border-color: rgba(88,166,255,0.3); }
.tool-label { font-size: 11px; }
.action-btn {
  padding: 4px 10px; background: #21262d; border: 1px solid #30363d;
  color: #e6edf3; font-size: 11px; font-family: inherit; border-radius: 4px;
  cursor: pointer; transition: all 0.12s;
}
.action-btn:hover { background: #282e36; border-color: #3d444d; }
.action-btn.primary { background: rgba(88,166,255,0.15); border-color: rgba(88,166,255,0.3); color: #58a6ff; }
.action-btn.primary:hover { background: rgba(88,166,255,0.25); }

/* ═══════════════════════════════════════════ */
/*  PALETTE                                    */
/* ═══════════════════════════════════════════ */
.palette {
  background: #161b22;
  border-right: 1px solid #30363d;
  overflow-y: auto;
  padding: 10px;
}
.palette-section { margin-bottom: 14px; }
.palette-heading {
  font-size: 10px; font-weight: 600; text-transform: uppercase;
  letter-spacing: 0.07em; color: #656d76; margin-bottom: 6px; padding: 0 2px;
}
.palette-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 5px; }
.palette-item {
  display: flex; flex-direction: column; align-items: center; gap: 3px;
  padding: 8px 4px 6px; background: #1c2129; border: 1px solid #30363d;
  border-radius: 6px; cursor: grab; transition: all 0.12s; position: relative;
}
.palette-item:hover { border-color: #58a6ff; background: #282e36; transform: translateY(-1px); }
.palette-item.selected { border-color: #58a6ff; background: rgba(88,166,255,0.1); box-shadow: 0 0 0 1px #58a6ff; }
.palette-preview { width: 36px; height: 28px; }
.palette-item-name { font-size: 10px; color: #8b949e; font-weight: 500; }
.palette-item-io {
  position: absolute; top: 2px; right: 3px;
  font-size: 7px; font-family: 'IBM Plex Mono', monospace;
  color: #656d76; background: #21262d; padding: 1px 3px; border-radius: 2px;
}
.palette-info { padding: 8px; background: #1c2129; border: 1px solid #30363d; border-radius: 6px; }
.info-row { display: flex; justify-content: space-between; padding: 3px 0; }
.info-label { font-size: 11px; color: #656d76; }
.info-value { font-size: 11px; color: #8b949e; font-family: 'IBM Plex Mono', monospace; }

/* ═══════════════════════════════════════════ */
/*  CANVAS                                     */
/* ═══════════════════════════════════════════ */
.canvas-wrapper {
  position: relative; background: #0e1117; overflow: hidden;
  cursor: crosshair;
}
.canvas-svg { width: 100%; height: 100%; display: block; }

/* SVG elements */
.node-group { cursor: pointer; }
.node-group:hover { filter: brightness(1.1); }
.node-label { font-size: 10px; font-weight: 600; fill: #e6edf3; font-family: 'IBM Plex Sans', sans-serif; }
.node-state { font-size: 8px; font-weight: 600; font-family: 'IBM Plex Mono', monospace; }
.tank-level-text { font-size: 14px; font-weight: 700; fill: #e6edf3; font-family: 'IBM Plex Mono', monospace; }
.sensor-value { font-size: 9px; font-weight: 600; fill: #e6edf3; font-family: 'IBM Plex Mono', monospace; }
.sensor-unit { font-size: 7px; fill: #8b949e; font-family: 'IBM Plex Mono', monospace; }
.pipe-label { font-size: 8px; fill: #8b949e; font-family: 'IBM Plex Mono', monospace; }
.port { opacity: 0.6; transition: opacity 0.15s; }
.node-group:hover .port { opacity: 1; }
.connection-group { cursor: pointer; }
.pipe-hitarea { pointer-events: stroke; }
.title-block-title { font-size: 11px; font-weight: 600; fill: #e6edf3; font-family: 'IBM Plex Sans', sans-serif; }
.title-block-sub { font-size: 8px; fill: #8b949e; font-family: 'IBM Plex Mono', monospace; }
.title-block-date { font-size: 7px; fill: #656d76; font-family: 'IBM Plex Mono', monospace; }

/* Flow animation */
.pipe-flow {
  animation: pipeFlow 1.2s linear infinite;
}
@keyframes pipeFlow {
  from { stroke-dashoffset: 0; }
  to { stroke-dashoffset: -28; }
}

/* Pump rotation */
.rotating {
  animation: rotate 2s linear infinite;
}
@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}

/* Zoom controls */
.zoom-controls {
  position: absolute; bottom: 12px; right: 12px;
  display: flex; align-items: center; gap: 4px;
  background: #161b22; border: 1px solid #30363d; border-radius: 6px;
  padding: 4px 6px;
}
.zoom-btn {
  width: 26px; height: 26px; display: flex; align-items: center; justify-content: center;
  background: transparent; border: 1px solid transparent; color: #8b949e;
  font-size: 14px; font-family: inherit; border-radius: 4px; cursor: pointer;
}
.zoom-btn:hover { background: #282e36; color: #e6edf3; }
.zoom-level { font-size: 10px; color: #656d76; font-family: 'IBM Plex Mono', monospace; min-width: 36px; text-align: center; }

/* ═══════════════════════════════════════════ */
/*  PROPERTY PANEL                             */
/* ═══════════════════════════════════════════ */
.properties {
  background: #161b22;
  border-left: 1px solid #30363d;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
}
.prop-panel { flex: 1; padding: 10px; }
.prop-header { margin-bottom: 12px; padding-bottom: 8px; border-bottom: 1px solid #30363d; }
.prop-type {
  display: inline-block; font-size: 9px; font-weight: 600; text-transform: uppercase;
  letter-spacing: 0.06em; color: #58a6ff; background: rgba(88,166,255,0.1);
  padding: 2px 6px; border-radius: 3px; margin-bottom: 4px;
}
.prop-id { display: block; font-size: 11px; color: #656d76; font-family: 'IBM Plex Mono', monospace; margin-top: 4px; }
.prop-section { margin-bottom: 12px; }
.prop-section-title {
  font-size: 9px; font-weight: 600; text-transform: uppercase;
  letter-spacing: 0.06em; color: #656d76; margin-bottom: 6px;
}
.prop-row { display: flex; justify-content: space-between; align-items: center; padding: 3px 0; }
.prop-row.indent { padding-left: 12px; }
.prop-label { font-size: 11px; color: #8b949e; }
.prop-value { font-size: 11px; color: #e6edf3; font-family: 'IBM Plex Mono', monospace; }
.prop-input {
  background: #21262d; border: 1px solid #30363d; color: #e6edf3;
  font-size: 11px; font-family: 'IBM Plex Mono', monospace;
  padding: 3px 6px; border-radius: 3px; width: 110px; text-align: right;
}
.prop-pos { display: flex; gap: 8px; }
.prop-coord { font-size: 10px; color: #8b949e; font-family: 'IBM Plex Mono', monospace; }
.val-green { color: #3fb950; }
.val-red { color: #f85149; }
.val-orange { color: #d29922; }
.val-blue { color: #58a6ff; }
.val-muted { color: #656d76; }
.port-connected { color: #3fb950; }
.port-free { color: #656d76; }

.prop-empty {
  flex: 1; display: flex; flex-direction: column;
  align-items: center; justify-content: center; padding: 20px; gap: 8px;
}
.prop-empty-icon { font-size: 28px; opacity: 0.2; }
.prop-empty-text { font-size: 11px; color: #656d76; text-align: center; line-height: 1.5; }

/* JSON preview */
.json-preview {
  border-top: 1px solid #30363d; font-size: 10px;
}
.json-header {
  display: flex; justify-content: space-between; align-items: center;
  padding: 6px 10px; cursor: pointer; color: #8b949e;
}
.json-header:hover { background: #1c2129; }
.json-copy {
  font-size: 9px; padding: 2px 6px; background: #21262d; border: 1px solid #30363d;
  color: #8b949e; border-radius: 3px; cursor: pointer;
}
.json-copy:hover { color: #e6edf3; border-color: #3d444d; }
.json-body {
  padding: 8px 10px; background: #0e1117; color: #8b949e;
  font-family: 'IBM Plex Mono', monospace; font-size: 9px;
  line-height: 1.5; max-height: 200px; overflow-y: auto;
  white-space: pre; margin: 0;
}

/* ═══════════════════════════════════════════ */
/*  STATUS BAR                                 */
/* ═══════════════════════════════════════════ */
.statusbar {
  display: flex; align-items: center; gap: 16px;
  padding: 0 12px; background: #161b22; border-top: 1px solid #30363d;
  font-size: 11px; color: #656d76;
}
.statusbar strong { color: #8b949e; font-weight: 500; }
.status-spacer { flex: 1; }
.status-valid { display: flex; align-items: center; gap: 4px; }
.status-dot {
  width: 6px; height: 6px; background: #3fb950; border-radius: 50%;
}

/* ═══════════════════════════════════════════ */
/*  TOAST                                      */
/* ═══════════════════════════════════════════ */
.toast {
  position: fixed; bottom: 48px; left: 50%; transform: translateX(-50%);
  padding: 8px 16px; border-radius: 6px; font-size: 12px; font-weight: 500;
  z-index: 100; box-shadow: 0 8px 32px rgba(0,0,0,0.4);
}
.toast.info { background: #161b22; border: 1px solid #30363d; color: #e6edf3; }
.toast.success { background: rgba(63,185,80,0.15); border: 1px solid rgba(63,185,80,0.3); color: #3fb950; }
.toast.error { background: rgba(248,81,73,0.15); border: 1px solid rgba(248,81,73,0.3); color: #f85149; }
.toast-enter-active, .toast-leave-active { transition: all 0.3s ease; }
.toast-enter-from, .toast-leave-to { opacity: 0; transform: translateX(-50%) translateY(10px); }
</style>
