# P&ID Component Library — Architecture Review & POC Design

**Reviewer Role:** Principal Software Architect + P&ID Domain Engineer  
**Date:** February 17, 2026  
**Scope:** Library reuse analysis, Consumer Designer POC, Pipe & Junction strategy

---

## 1. Library Analysis Summary

### What You Have (Honest Assessment)

**Strengths:**

Your library has made the single most important architectural decision correctly: **dumb, props-driven components**. The `ManualValve :state="valveState"` pattern is exactly right. You avoided the trap of baking IOComponent classes into the rendering layer — a mistake that would have permanently coupled your components to a single state management pattern.

Concrete inventory of what works:

- 5 SVG components (ManualValve, CentrifugalPump, VerticalTank, PressureSensor, GeneralPipe) with clean prop interfaces
- Port system with a registry (`getPortDefinition('vertical-tank', 'bottom')`) — this is the correct foundation for a connection engine
- GeneralPipe with waypoints using SVG path `M/L` commands — solid, standard approach
- Flow animation via CSS `stroke-dashoffset` — works with polyline paths automatically
- Connection data model referencing `componentId + portId` rather than absolute coordinates — this is critical and correct
- TypeScript types for all prop interfaces
- ~400 lines total — appropriately small for a presentation library

**What's Missing for Real Multi-Project Reuse:**

| Gap | Severity | Why It Matters |
|-----|----------|---------------|
| No npm package / build output | **Critical** | Cannot be consumed as a dependency. Every project copies files. |
| No component metadata registry | **High** | Consumer apps (palettes, editors) can't enumerate available components, their ports, default sizes, or categories at runtime. |
| No bounding box / hit-test info | **High** | Editor can't implement click-to-select without knowing component geometry. |
| No rotation support in port system | **Medium** | Ports are defined at 0° rotation only. Rotating a valve 90° means ports are wrong. |
| No versioned schema for save/load | **Medium** | Breaking changes to the JSON format will corrupt saved diagrams. |
| No theme/style tokens | **Medium** | Colors are hardcoded (`#4CAF50`, `#F44336`). Different projects can't brand. |
| No event contract for interactions | **Low** | Components emit `click` but there's no standard `@select`, `@port-click`, `@context-menu` contract. |

**Risk Areas:**

1. **Tight coupling to SVG coordinate space.** Port positions like `{ x: 30, y: 200 }` are pixel-level. If someone renders a tank at 2x scale, ports are wrong. Ports should be normalized (0–1 range) or scale-aware.

2. **No serialization versioning.** Your diagram JSON has no `version` field. The moment you add a property (e.g., `rotation`, `zIndex`), old diagrams fail silently.

3. **Scaling/performance.** Pure SVG with Vue reactivity is fine for <200 components. At 500+, you'll need virtualization (only render visible viewport). Not a problem now, but the architecture should not block this later.

4. **Testing gap.** The old `tests/` directory tested `DigitalIO` / `AnalogIO` classes you've since removed. There are no tests for the current dumb components, port registry, or pipe path generation.

---

## 2. Multi-Project Reuse Recommendations

### Proposed Package Structure

```
@pid-library/
├── core/                          # npm package: @pid-library/core
│   ├── src/
│   │   ├── components/
│   │   │   ├── valves/
│   │   │   │   └── ManualValve.vue
│   │   │   ├── pumps/
│   │   │   │   └── CentrifugalPump.vue
│   │   │   ├── tanks/
│   │   │   │   └── VerticalTank.vue
│   │   │   ├── sensors/
│   │   │   │   └── PressureSensor.vue
│   │   │   ├── connectors/
│   │   │   │   └── GeneralPipe.vue
│   │   │   └── index.ts           # barrel export
│   │   │
│   │   ├── registry/
│   │   │   ├── ComponentRegistry.ts    # NEW: runtime component catalog
│   │   │   ├── PortRegistry.ts         # existing, enhanced
│   │   │   └── index.ts
│   │   │
│   │   ├── types/
│   │   │   ├── components.ts      # prop interfaces
│   │   │   ├── diagram.ts         # NEW: save/load schema types
│   │   │   ├── ports.ts           # port types
│   │   │   └── index.ts
│   │   │
│   │   ├── theme/
│   │   │   ├── tokens.ts          # NEW: color/size tokens
│   │   │   ├── ThemeProvider.vue   # NEW: provide/inject theme
│   │   │   └── index.ts
│   │   │
│   │   ├── utils/
│   │   │   ├── colors.ts
│   │   │   ├── geometry.ts        # NEW: hit-test, bounds, transforms
│   │   │   └── index.ts
│   │   │
│   │   └── index.ts               # main barrel
│   │
│   ├── package.json
│   ├── vite.config.ts             # library build mode
│   └── tsconfig.json
│
├── editor/                        # npm package: @pid-library/editor (future)
│   └── ...                        # Canvas, palette, selection, etc.
│
└── examples/
    ├── dashboard-app/             # View-only consumer
    ├── designer-app/              # Editor consumer (the POC)
    └── scada-app/                 # Live data consumer
```

### Component Registry Strategy

This is what makes the library usable by editors, palettes, and dynamic diagram loaders:

```typescript
// registry/ComponentRegistry.ts

export interface ComponentMeta {
  // Identity
  id: string;                           // 'manual-valve'
  name: string;                         // 'Manual Valve'
  category: 'valve' | 'pump' | 'tank' | 'sensor' | 'connector' | 'junction';
  
  // Rendering
  component: Component;                 // Vue component reference
  defaultSize: { width: number; height: number };
  icon: string;                         // SVG path or emoji for palette
  
  // Ports
  ports: PortDefinition[];
  
  // Props
  defaultProps: Record<string, any>;    // sensible defaults
  propSchema: PropSchema[];             // for property panels
  
  // Behavior
  rotatable: boolean;
  resizable: boolean;
  ioType: 'digital' | 'analog' | 'none';
}

class ComponentRegistry {
  private components = new Map<string, ComponentMeta>();
  
  register(meta: ComponentMeta): void { ... }
  get(id: string): ComponentMeta | undefined { ... }
  getByCategory(cat: string): ComponentMeta[] { ... }
  getAll(): ComponentMeta[] { ... }
  
  // For dynamic diagram loading
  resolve(typeId: string): Component { ... }
}

export const componentRegistry = new ComponentRegistry();
```

Registration happens at library init:

```typescript
// components/valves/index.ts
import ManualValve from './ManualValve.vue';
import { componentRegistry } from '../../registry';

componentRegistry.register({
  id: 'manual-valve',
  name: 'Manual Valve',
  category: 'valve',
  component: ManualValve,
  defaultSize: { width: 40, height: 24 },
  icon: '◇',
  ports: [
    { id: 'inlet', position: { x: 0, y: 12 }, direction: 'left' },
    { id: 'outlet', position: { x: 40, y: 12 }, direction: 'right' },
  ],
  defaultProps: { state: 'closed', alarm: 'none' },
  propSchema: [
    { key: 'state', type: 'enum', options: ['open', 'closed'] },
    { key: 'alarm', type: 'enum', options: ['none', 'warning', 'alarm'] },
  ],
  rotatable: true,
  resizable: false,
  ioType: 'digital',
});
```

### API Surface (What the Library Exports)

```typescript
// @pid-library/core main export

// Components
export { ManualValve, CentrifugalPump, VerticalTank, PressureSensor, GeneralPipe };

// Registry
export { componentRegistry, type ComponentMeta };
export { getPortDefinition, getPortWorldPosition, type PortDefinition };

// Types
export type { DiagramSchema, DiagramNode, DiagramConnection, Position };
export type { DigitalComponentProps, AnalogComponentProps, PipeProps };

// Theme
export { ThemeProvider, defaultTheme, type PidTheme };

// Utilities
export { getAlarmColor, formatValue, computePipePath, getComponentBounds };

// Schema
export { DIAGRAM_SCHEMA_VERSION, validateDiagram, migrateDiagram };
```

### Versioning Strategy

- Library version: semver (`1.0.0`, `1.1.0`, `2.0.0`)
- Diagram schema version: integer (`1`, `2`, `3`) — embedded in every saved file
- Breaking component prop changes → major version bump
- New optional props → minor version bump
- Port position changes → major version bump (breaks saved diagrams)
- Include a `migrateDiagram(oldJson)` function that upgrades old schemas

---

## 3. Consumer P&ID Designer POC

### Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                     Designer Application                         │
│                                                                  │
│  ┌─────────┐  ┌──────────────────────────────────┐  ┌────────┐ │
│  │ Palette  │  │          Canvas                   │  │Property│ │
│  │          │  │  ┌──────────────────────────┐    │  │ Panel  │ │
│  │ [Valve]  │  │  │   SVG Viewport           │    │  │        │ │
│  │ [Pump]   │  │  │   (pan + zoom)           │    │  │ State: │ │
│  │ [Tank]   │  │  │                          │    │  │ [open] │ │
│  │ [Sensor] │  │  │   Components + Pipes     │    │  │        │ │
│  │ [Pipe]   │  │  │   rendered here          │    │  │ Label: │ │
│  │          │  │  │                          │    │  │ [V001] │ │
│  │          │  │  └──────────────────────────┘    │  │        │ │
│  └─────────┘  └──────────────────────────────────┘  └────────┘ │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────────┐│
│  │  Toolbar: [Save] [Load] [Validate] [Undo] [Redo] [Grid]    ││
│  └──────────────────────────────────────────────────────────────┘│
│                                                                  │
│  State Management (Pinia)                                        │
│  ┌──────────┐ ┌────────────┐ ┌──────────┐ ┌──────────────────┐ │
│  │ Diagram  │ │ Selection  │ │ History  │ │ Interaction      │ │
│  │ Store    │ │ Store      │ │ Store    │ │ State Machine    │ │
│  │          │ │            │ │(undo/do) │ │(idle/placing/    │ │
│  │ nodes[] │ │ selected[] │ │ stack[]  │ │ dragging/wiring) │ │
│  │ conns[] │ │ hovered    │ │ pointer  │ │                  │ │
│  └──────────┘ └────────────┘ └──────────┘ └──────────────────┘ │
└──────────────────────────────────────────────────────────────────┘
```

### Module Responsibilities

| Module | Responsibility | Key Files |
|--------|---------------|-----------|
| **DiagramStore** | Source of truth for nodes and connections | `stores/diagram.ts` |
| **SelectionStore** | What's selected, hovered, multi-select | `stores/selection.ts` |
| **HistoryStore** | Undo/redo via command pattern (snapshot-based) | `stores/history.ts` |
| **InteractionStateMachine** | Current tool mode (idle, placing, wiring, dragging, panning) | `composables/useInteraction.ts` |
| **Canvas** | SVG viewport with pan/zoom transform | `components/Canvas.vue` |
| **ComponentRenderer** | Dynamic rendering of placed components from diagram data | `components/ComponentRenderer.vue` |
| **PipeRenderer** | Renders all connections as GeneralPipe instances | `components/PipeRenderer.vue` |
| **Palette** | Lists available components from registry, drag-to-place | `components/Palette.vue` |
| **PropertyPanel** | Edit props of selected component | `components/PropertyPanel.vue` |
| **Serializer** | Save/load diagram JSON with schema version | `services/serializer.ts` |
| **Validator** | Check diagram integrity (dangling pipes, etc.) | `services/validator.ts` |

### Features: POC vs Future

| Feature | POC (v0.1) | Future |
|---------|-----------|--------|
| Place components from palette | ✅ Click to place | Drag-and-drop |
| Select / move components | ✅ Click + drag | Multi-select, lasso |
| Connect via ports | ✅ Click port → click port | Drag wire preview |
| Pipes with waypoints | ✅ Auto-generate L-shape | Interactive waypoint editing |
| Save to JSON | ✅ Download file | Cloud save, autosave |
| Load from JSON | ✅ File upload | Recent files, gallery |
| Pan / zoom | ✅ Wheel zoom + drag pan | Minimap, fit-to-view |
| Snap to grid | ✅ Optional 10px grid | Smart guides |
| Validation | ✅ Dangling connections check | Flow simulation |
| Undo / redo | ❌ (v0.2) | Full command history |
| Rotation | ❌ (v0.2) | 90° increments |
| Copy / paste | ❌ | ✅ |
| Pipe labels / tags | ❌ | ✅ |
| Flow direction arrows | ❌ | ✅ |
| Auto-routing | ❌ | ✅ |
| Junction / tee points | ❌ (v0.2) | ✅ |

### Save/Load JSON Schema

```typescript
// types/diagram.ts

export interface DiagramSchema {
  // Metadata — ALWAYS PRESENT
  version: 1;                          // Schema version (integer, for migrations)
  id: string;                          // UUID
  name: string;
  description?: string;
  createdAt: string;                   // ISO 8601
  updatedAt: string;

  // Canvas settings
  canvas: {
    width: number;
    height: number;
    gridSize: number;
    gridEnabled: boolean;
  };

  // Placed components
  nodes: DiagramNode[];

  // Pipe connections
  connections: DiagramConnection[];
}

export interface DiagramNode {
  id: string;                          // UUID (e.g., "node-a1b2c3")
  typeId: string;                      // Registry key (e.g., "manual-valve")
  position: { x: number; y: number }; // Top-left corner on canvas
  rotation: number;                    // Degrees (0, 90, 180, 270)
  label: string;                       // Display tag (e.g., "V-001")
  props: Record<string, any>;         // Component-specific props
  zIndex?: number;
}

export interface DiagramConnection {
  id: string;                          // UUID
  from: { nodeId: string; portId: string };
  to: { nodeId: string; portId: string };
  waypoints: Array<{ x: number; y: number }>;  // always present, may be empty
  props: {
    flowing?: boolean;
    strokeWidth?: number;
    label?: string;
    flowDirection?: 'forward' | 'reverse';
  };
}
```

**Example saved diagram:**

```json
{
  "version": 1,
  "id": "diag-001",
  "name": "Water Treatment - Stage 1",
  "createdAt": "2026-02-17T10:00:00Z",
  "updatedAt": "2026-02-17T14:30:00Z",
  "canvas": {
    "width": 1200,
    "height": 800,
    "gridSize": 10,
    "gridEnabled": true
  },
  "nodes": [
    {
      "id": "node-1",
      "typeId": "vertical-tank",
      "position": { "x": 100, "y": 100 },
      "rotation": 0,
      "label": "T-001",
      "props": { "level": 75, "units": "L", "alarm": "none" }
    },
    {
      "id": "node-2",
      "typeId": "manual-valve",
      "position": { "x": 300, "y": 288 },
      "rotation": 0,
      "label": "V-001",
      "props": { "state": "open", "alarm": "none" }
    },
    {
      "id": "node-3",
      "typeId": "centrifugal-pump",
      "position": { "x": 450, "y": 275 },
      "rotation": 0,
      "label": "P-001",
      "props": { "state": "running", "alarm": "none" }
    },
    {
      "id": "node-4",
      "typeId": "pressure-sensor",
      "position": { "x": 200, "y": 50 },
      "rotation": 0,
      "label": "PT-001",
      "props": { "value": 125.5, "units": "PSI", "alarm": "none" }
    }
  ],
  "connections": [
    {
      "id": "conn-1",
      "from": { "nodeId": "node-1", "portId": "bottom" },
      "to": { "nodeId": "node-2", "portId": "inlet" },
      "waypoints": [
        { "x": 130, "y": 310 },
        { "x": 300, "y": 310 }
      ],
      "props": { "flowing": true }
    },
    {
      "id": "conn-2",
      "from": { "nodeId": "node-2", "portId": "outlet" },
      "to": { "nodeId": "node-3", "portId": "inlet" },
      "waypoints": [],
      "props": { "flowing": true }
    }
  ]
}
```

### POC Development Plan

| Milestone | Duration | Deliverable |
|-----------|----------|-------------|
| **M1: Static Canvas** | 3 days | SVG canvas with pan/zoom. Render hardcoded components at fixed positions. Prove the rendering pipeline works. |
| **M2: Palette + Place** | 3 days | Component palette from registry. Click palette → click canvas → component appears. DiagramStore holds state. |
| **M3: Select + Move** | 2 days | Click component to select (blue outline). Drag to reposition. Position snaps to grid. |
| **M4: Port Wiring** | 3 days | Click a port → click another port → connection created. GeneralPipe rendered between them. Auto-generate simple L-shaped waypoints. |
| **M5: Save + Load** | 2 days | Export diagram JSON (download). Import diagram JSON (file upload). Schema validation on load. |
| **M6: Validation** | 1 day | "Validate" button checks: no dangling connections, no duplicate IDs, all referenced nodes exist. Display errors. |
| **M7: Polish** | 2 days | Property panel for selected node. Delete key removes selected. Keyboard shortcuts. Visual feedback. |
| **Total** | ~16 days | Functional POC |

---

## 4. Pipe Strategy (Mentor Critique)

### Your Idea: Multiple Preset Pipe Shapes

You're considering separate types: horizontal, Z-shaped, mirror-Z, top-Z, bottom-Z, extender-in-center.

**My verdict: Don't do this.**

Here's why, and I'll be direct:

**Problem 1: Combinatorial explosion.** You listed 5–6 shapes. Add diagonal variants, different entry/exit directions, different component orientations — you're looking at 20+ preset types. Each needs its own component, its own tests, its own edge cases. You cannot enumerate all possible pipe routes between arbitrary component positions.

**Problem 2: The "almost right" trap.** A preset Z-shape will be perfect when components are aligned. The moment a user drags a component 15 pixels off-grid, the Z-shape looks wrong. Now you need a "Z-shape with offset correction" — another type. This never converges.

**Problem 3: You already have the right answer.** Your `GeneralPipe` with waypoints IS the universal solution. A Z-shape is just `[start, {x: start.x, y: end.y}, end]`. A mirror-Z is `[start, {x: end.x, y: start.y}, end]`. They're all special cases of a polyline.

### What To Do Instead

**Keep ONE pipe component.** Your `GeneralPipe` with `startPosition`, `endPosition`, and `waypoints[]`. This is correct.

**Add intelligent waypoint generators** — functions (not components) that calculate waypoints for common patterns:

```typescript
// utils/routing.ts — pure functions, not components

/**
 * Generate orthogonal waypoints between two ports.
 * This replaces all your "Z-shape", "mirror-Z", etc. presets.
 */
export function generateOrthogonalRoute(
  start: Position,
  startDirection: Direction,    // 'left' | 'right' | 'up' | 'down'
  end: Position,
  endDirection: Direction,
  options?: { minSegmentLength?: number; preferHorizontalFirst?: boolean }
): Position[] {
  const MIN_SEG = options?.minSegmentLength ?? 20;
  
  // Case 1: Same Y, horizontal ports facing each other → no waypoints
  if (Math.abs(start.y - end.y) < 2 && startDirection === 'right' && endDirection === 'left') {
    return [];
  }
  
  // Case 2: Exit right, enter left, different Y → L-shape or Z-shape
  if (startDirection === 'right' && endDirection === 'left') {
    const midX = (start.x + end.x) / 2;
    if (midX > start.x + MIN_SEG && midX < end.x - MIN_SEG) {
      // Z-shape: exit right, go to midX, jog vertically, enter left
      return [
        { x: midX, y: start.y },
        { x: midX, y: end.y },
      ];
    }
    // Fallback: U-route around
    const offsetX = Math.max(start.x, end.x) + MIN_SEG * 3;
    return [
      { x: offsetX, y: start.y },
      { x: offsetX, y: end.y },
    ];
  }
  
  // Case 3: Exit right, enter top → L-shape
  if (startDirection === 'right' && endDirection === 'up') {
    return [{ x: end.x, y: start.y }];
  }
  
  // ... more cases based on direction pairs
  // Total: ~8 direction pair combinations, not 20 components
  
  // Fallback: simple L-shape
  return [{ x: end.x, y: start.y }];
}
```

**The key insight:** Your "Z-shape" is not a component type — it's a **routing algorithm output**. The routing function generates waypoints, and the same `GeneralPipe` renders them all.

### How to Support Interactive Dragging

This is the "extender in center" concept you described — and it's the right UX idea, just wrong implementation. Don't make it a separate component. Make it an interaction mode on the existing pipe:

```
User interaction flow:
1. Pipe exists with waypoints: start → [w1, w2] → end
2. User hovers pipe segment between w1 and w2
3. Cursor changes to ↕ (vertical) or ↔ (horizontal)
4. User drags → w1.x and w2.x both move (for vertical segment)
   OR → w1.y and w2.y both move (for horizontal segment)
5. Waypoints update → GeneralPipe re-renders reactively
```

Implementation:

```typescript
// composables/usePipeEditing.ts

interface SegmentDrag {
  pipeId: string;
  segmentIndex: number;          // which segment (0 = start→w1, 1 = w1→w2, etc.)
  axis: 'x' | 'y';              // which axis is being dragged
  startMousePos: Position;
  originalWaypoints: Position[];
}

function onSegmentDrag(drag: SegmentDrag, mousePos: Position) {
  const delta = mousePos[drag.axis] - drag.startMousePos[drag.axis];
  const newWaypoints = [...drag.originalWaypoints];
  
  // Move both endpoints of this segment along the drag axis
  // Segment i connects point[i] to point[i+1]
  // For an orthogonal segment, moving it means adjusting the shared coordinate
  const allPoints = [startPos, ...newWaypoints, endPos];
  const p1Index = drag.segmentIndex;      // index in allPoints
  const p2Index = drag.segmentIndex + 1;
  
  // Only move waypoints (not start/end, which are anchored to ports)
  if (p1Index > 0 && p1Index <= newWaypoints.length) {
    newWaypoints[p1Index - 1][drag.axis] += delta;
  }
  if (p2Index > 0 && p2Index <= newWaypoints.length) {
    newWaypoints[p2Index - 1][drag.axis] += delta;
  }
  
  diagramStore.updateConnectionWaypoints(drag.pipeId, newWaypoints);
}
```

**Waypoint insertion/removal:**

```
- Double-click on segment → inserts two new waypoints (creating a draggable jog)
- Double-click on waypoint → removes it (merges adjacent segments)
- Drag waypoint near adjacent waypoint → auto-merge (simplification)
```

### Auto-Routing (Future-Proofing)

Don't implement auto-routing now. But structure your code so it's addable:

```typescript
// The interface is the same: (start, end, obstacles) → waypoints[]
interface Router {
  route(
    start: Position,
    startDir: Direction,
    end: Position,
    endDir: Direction,
    obstacles: BoundingBox[]
  ): Position[];
}

// Today: SimpleOrthogonalRouter (your generateOrthogonalRoute function)
// Future: AStarOrthogonalRouter, ChannelRouter, etc.
// The pipe component doesn't change. Only the waypoint generator changes.
```

### Summary: Pipe Strategy

| Approach | Verdict |
|----------|---------|
| Multiple preset pipe components (Z, mirror-Z, etc.) | **❌ Reject.** Combinatorial explosion, doesn't scale, premature complexity. |
| One flexible polyline with waypoints | **✅ Keep.** You already have this. It's correct. |
| Smart waypoint generators (functions) | **✅ Add.** Replace presets with routing algorithms that output waypoints. |
| Interactive segment dragging | **✅ Add in editor.** Interaction mode, not a component type. |
| Separate "extender in center" component | **❌ Reject.** It's an editing interaction, not a component. |

---

## 5. Junction / Branching Strategy (Mentor Critique)

### Your Two Ideas

**Idea A:** Dummy circle component with multiple ports (tee/cross).  
**Idea B:** Special pipe components with built-in junction geometry.

**My verdict:** Idea A is closer to correct, but needs refinement. Idea B is wrong — don't build junction logic into pipes.

### The Right Model: Junction as a First-Class Node

A junction (tee, cross, wye) should be a **component in the diagram** — a node with its own ID, position, and ports. Not a pipe feature. Not implicit. Explicit.

**Why explicit nodes, not pipe features:**

1. **Serialization clarity.** A junction is a vertex in a graph. If it's implicit (just a coordinate where pipes happen to meet), you can't reliably serialize it, validate it, or reason about flow direction.

2. **Port semantics matter.** A tee junction has 3 ports. A cross has 4. Each port has a direction. When you add flow direction arrows later, you need to know which ports are inlets and which are outlets. This is per-junction metadata — it doesn't belong on a pipe.

3. **Visual representation.** ISA/IEC P&ID standards show junctions as explicit dots or circles. This is industry standard. Users expect to see them.

4. **Click/select/delete behavior.** Users need to be able to select a junction, move it, delete it (which deletes all connected pipes). This is component behavior, not pipe behavior.

### Implementation

```typescript
// Register junction as a component type
componentRegistry.register({
  id: 'junction-tee',
  name: 'Tee Junction',
  category: 'junction',
  component: JunctionTee,        // renders a small filled circle or T symbol
  defaultSize: { width: 10, height: 10 },
  ports: [
    { id: 'a', position: { x: 0, y: 5 }, direction: 'left' },
    { id: 'b', position: { x: 10, y: 5 }, direction: 'right' },
    { id: 'c', position: { x: 5, y: 0 }, direction: 'up' },
  ],
  defaultProps: {},
  rotatable: true,
  resizable: false,
  ioType: 'none',
});

componentRegistry.register({
  id: 'junction-cross',
  name: 'Cross Junction',
  category: 'junction',
  component: JunctionCross,
  defaultSize: { width: 10, height: 10 },
  ports: [
    { id: 'a', position: { x: 0, y: 5 }, direction: 'left' },
    { id: 'b', position: { x: 10, y: 5 }, direction: 'right' },
    { id: 'c', position: { x: 5, y: 0 }, direction: 'up' },
    { id: 'd', position: { x: 5, y: 10 }, direction: 'down' },
  ],
  defaultProps: {},
  rotatable: false,
  resizable: false,
  ioType: 'none',
});
```

The junction component itself is trivially simple:

```vue
<!-- JunctionTee.vue -->
<template>
  <g class="junction-tee">
    <circle cx="5" cy="5" r="4" :fill="fillColor" stroke="#333" stroke-width="1.5" />
  </g>
</template>

<script setup lang="ts">
const props = defineProps<{ alarm?: 'none' | 'warning' | 'alarm' }>();
const fillColor = computed(() => props.alarm === 'alarm' ? '#F44336' : '#333');
</script>
```

### Data Model Representation

In the diagram JSON, a junction is just a node. A branching pipe is just two connections that share a junction node:

```json
{
  "nodes": [
    { "id": "node-v1", "typeId": "manual-valve", "position": {"x": 100, "y": 200}, "label": "V-001" },
    { "id": "node-v2", "typeId": "manual-valve", "position": {"x": 500, "y": 200}, "label": "V-002" },
    { "id": "node-jt", "typeId": "junction-tee",  "position": {"x": 295, "y": 197}, "label": "" },
    { "id": "node-pt", "typeId": "pressure-sensor","position": {"x": 280, "y": 50},  "label": "PT-001" }
  ],
  "connections": [
    {
      "id": "conn-1",
      "from": { "nodeId": "node-v1", "portId": "outlet" },
      "to":   { "nodeId": "node-jt", "portId": "a" },
      "waypoints": []
    },
    {
      "id": "conn-2", 
      "from": { "nodeId": "node-jt", "portId": "b" },
      "to":   { "nodeId": "node-v2", "portId": "inlet" },
      "waypoints": []
    },
    {
      "id": "conn-3",
      "from": { "nodeId": "node-jt", "portId": "c" },
      "to":   { "nodeId": "node-pt", "portId": "bottom" },
      "waypoints": [{ "x": 300, "y": 100 }]
    }
  ]
}
```

This is a **graph**: nodes connected by edges. Junctions are degree-3+ vertices. Clean, standard, no special cases.

### UI Interaction: Creating a Branch

**POC approach (simple, good enough):**

1. User selects "Tee Junction" from palette
2. Clicks on canvas to place it
3. Wires ports manually (click port → click port, three times)

**Future approach (slick UX):**

1. User is in "branch" tool mode
2. Clicks on an existing pipe segment
3. System automatically:
   - Splits the pipe at that point into two pipes
   - Inserts a tee junction node at the click point
   - Leaves the third port unconnected (highlighted, ready to wire)
4. User clicks on target component's port → third pipe is created

Implementation of the split operation:

```typescript
function splitPipeWithJunction(
  connectionId: string, 
  clickPoint: Position,
  diagramStore: DiagramStore
): string /* junctionId */ {
  const conn = diagramStore.getConnection(connectionId);
  
  // 1. Find which segment was clicked
  const allPoints = [getPortWorldPos(conn.from), ...conn.waypoints, getPortWorldPos(conn.to)];
  const segIndex = findNearestSegment(allPoints, clickPoint);
  
  // 2. Calculate snap point on segment
  const snapPoint = projectPointOnSegment(allPoints[segIndex], allPoints[segIndex + 1], clickPoint);
  
  // 3. Create junction node at snap point
  const junctionId = diagramStore.addNode({
    typeId: 'junction-tee',
    position: { x: snapPoint.x - 5, y: snapPoint.y - 5 },
    label: '',
    props: {},
  });
  
  // 4. Split waypoints into before/after the split point
  const waypointsBefore = conn.waypoints.slice(0, segIndex);
  const waypointsAfter = conn.waypoints.slice(segIndex);
  
  // 5. Remove original connection
  diagramStore.removeConnection(connectionId);
  
  // 6. Create two new connections through the junction
  diagramStore.addConnection({
    from: conn.from,
    to: { nodeId: junctionId, portId: 'a' },
    waypoints: waypointsBefore,
  });
  
  diagramStore.addConnection({
    from: { nodeId: junctionId, portId: 'b' },
    to: conn.to,
    waypoints: waypointsAfter,
  });
  
  // 7. Port 'c' is free — return junction ID so UI can start wiring from it
  return junctionId;
}
```

### What About "Smart Snapping to Pipe Midpoints"?

In the future branch-tool UX, you need hit-testing against pipe segments:

```typescript
function findNearestPipeSegment(
  mousePos: Position,
  connections: DiagramConnection[],
  threshold: number = 8   // pixels
): { connectionId: string; segIndex: number; snapPoint: Position } | null {
  let best = null;
  let bestDist = threshold;
  
  for (const conn of connections) {
    const allPoints = [getPortWorldPos(conn.from), ...conn.waypoints, getPortWorldPos(conn.to)];
    for (let i = 0; i < allPoints.length - 1; i++) {
      const proj = projectPointOnSegment(allPoints[i], allPoints[i+1], mousePos);
      const dist = distance(proj, mousePos);
      if (dist < bestDist) {
        bestDist = dist;
        best = { connectionId: conn.id, segIndex: i, snapPoint: proj };
      }
    }
  }
  
  return best;
}
```

This highlights the pipe segment under the cursor — visual feedback that says "click here to branch."

### Preventing Messy Graphs

Rules for the validator:

1. **No port can have more than one connection.** (Use junctions for branching — don't allow two pipes to connect to the same port.)
2. **Junctions must have at least 2 connected ports.** (A junction with 1 or 0 connections is useless — warn or auto-delete.)
3. **No self-loops.** (A pipe cannot connect a port to itself.)
4. **No duplicate connections.** (Two pipes between the same two ports.)

### Future Features: Flow Direction, Tags, Instrument Loops

Because junctions are nodes, extending is straightforward:

- **Flow direction arrows:** A `flowDirection: 'forward' | 'reverse'` prop on each connection. The `GeneralPipe` renders an arrowhead at the midpoint. No junction changes needed.

- **Pipe tags/labels:** A `label` prop on connections, rendered as SVG `<text>` at the pipe midpoint. Already in the proposed schema.

- **Instrument loops:** A higher-level concept — a named group of nodes. Add a `loops` array to the diagram schema:
  ```json
  { "loops": [{ "id": "loop-1", "name": "FIC-101", "nodeIds": ["node-ft", "node-cv", "node-fc"] }] }
  ```
  Components in a loop get a visual indicator (shared color, dashed border, etc.). No changes to the node/connection model.

### Summary: Junction Strategy

| Approach | Verdict |
|----------|---------|
| Junction as a pipe feature (implicit) | **❌ Reject.** Can't serialize, can't select, can't reason about flow. |
| Special pipe components with built-in junction | **❌ Reject.** Conflates two concerns. Pipes are edges. Junctions are vertices. |
| Dummy circle component with multiple ports | **✅ Accept, refined.** Register junction types (tee, cross) as real components in the registry. Explicit nodes in the graph. |
| Pipe splitting UX to insert junction | **✅ Future.** Great UX, implement after POC. |

---

## 6. Concrete Next Steps

Ordered by priority and dependency:

### Task 1: Add `version` field to diagram schema (Day 1)
Every saved diagram must include `"version": 1`. Write a `validateDiagram()` function and a `migrateDiagram()` stub. This costs 30 minutes and prevents months of pain later.

### Task 2: Build ComponentRegistry (Day 1–2)
Implement the `ComponentMeta` interface and registry class. Register all 5 existing components with their ports, default sizes, and prop schemas. This is the foundation for the palette and dynamic rendering.

### Task 3: Add `direction` to port definitions (Day 2)
Every port needs a `direction: 'left' | 'right' | 'up' | 'down'`. Without this, the routing function can't generate smart waypoints, and rotation support is impossible.

### Task 4: Implement `generateOrthogonalRoute()` (Day 3)
Write the pure function that generates waypoints given two ports with positions and directions. Test with unit tests. This replaces all your "Z-shape" thinking with one function.

### Task 5: Build POC Canvas with pan/zoom (Day 3–5)
SVG viewport with `viewBox` manipulation for pan/zoom. Render hardcoded test diagram. Prove the rendering pipeline works end-to-end.

### Task 6: Implement Place + Select + Move (Day 5–8)
Palette → click to place. Click to select. Drag to move. Snap to grid. This is where the interaction state machine lives.

### Task 7: Implement Port Wiring (Day 8–11)
Click port → click port → connection created → pipe rendered. Use `generateOrthogonalRoute()` for initial waypoints. This completes the core editing loop.

### Task 8: Save/Load with schema validation (Day 11–13)
Export button → downloads JSON. Import button → file picker → validates schema → loads diagram. Include the `version` field and validate on load.

### Task 9: Create JunctionTee component (Day 13–14)
Register tee junction. Place from palette. Wire manually. Prove that branching works in the data model and rendering.

### Task 10: Package library as npm-publishable (Day 14–16)
Configure Vite in library mode. Set up `package.json` exports. Create a `dist/` build that consuming projects can `npm install`. This is what makes multi-project reuse real.

---

## Final Remarks

Your library's foundation is sound. The dumb-component philosophy is the right call, and the port-based connection model is correct. The main risks are:

1. **Don't proliferate component types for what should be algorithmic variation** (pipes, routing shapes).
2. **Don't make junctions implicit** — they're nodes in a graph.
3. **Version your schema from day one** — it's free now, expensive to retrofit.
4. **Ship the npm package early** — until it's a real dependency, it's just a folder of files.

The POC is achievable in 16 working days. Resist the urge to add undo/redo, auto-routing, or fancy UX before the core editing loop (place → wire → save → load) works end-to-end.
