// Main library exports

// Components
export * from './components';

// Types
export type {
  AlarmLevel,
  DigitalState,
  BaseComponentProps,
  DigitalComponentProps,
  AnalogComponentProps,
  ComponentEvents,
} from './types';

// Utils
export { getAlarmColor, getStateColor, getComponentColor, formatValue } from './utils';

// Constants
export { COLORS, DIMENSIONS } from './constants';

// Visuals (optional - if you want to use definitions)
export type { VisualDefinition } from './visuals';
export { VALVE_VISUALS, PUMP_VISUALS, SENSOR_VISUALS, getVisual } from './visuals';

// Animations (optional - if you want to use helpers)
export { shouldAnimate, applyRotation, ANIMATION_CLASSES } from './animations';
