/**
 * Simple Animation Helpers
 * 
 * This is the GOOD part from your animation system - simplified
 */

/**
 * Check if element should animate based on state
 */
export function shouldAnimate(state: string): boolean {
  return state === 'running' || state === 'on' || state === 'open';
}

/**
 * Apply rotation animation to element
 * For pumps, motors, etc.
 */
export function applyRotation(element: SVGElement, isAnimating: boolean): void {
  if (isAnimating) {
    element.classList.add('rotating');
  } else {
    element.classList.remove('rotating');
  }
}

/**
 * CSS Animation Classes
 * Add these to your component styles
 */
export const ANIMATION_CLASSES = {
  ROTATION: `
    .rotating {
      animation: rotate 2s linear infinite;
      transform-origin: center;
    }
    
    @keyframes rotate {
      from { transform: rotate(0deg); }
      to { transform: rotate(360deg); }
    }
  `,
  
  PULSE: `
    .pulsing {
      animation: pulse 1s ease-in-out infinite;
    }
    
    @keyframes pulse {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.7; }
    }
  `,
  
  BLINK: `
    .blinking {
      animation: blink 1s ease-in-out infinite;
    }
    
    @keyframes blink {
      0%, 100% { opacity: 1; }
      50% { opacity: 0.3; }
    }
  `,
} as const;
