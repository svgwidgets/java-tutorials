/**
 * Visual Definitions (Simplified)
 * 
 * SVG path definitions for components
 * This is the GOOD part from your existing code - let's keep it simple
 */

/**
 * Visual definition interface
 */
export interface VisualDefinition {
  id: string;
  name: string;
  viewBox: { width: number; height: number };
  paths: string[];
}

/**
 * Valve visual definitions
 */
export const VALVE_VISUALS = {
  MANUAL: {
    id: 'manual-valve',
    name: 'Manual Valve',
    viewBox: { width: 40, height: 24 },
    paths: [
      'M 0 0 L 20 12 L 0 24 Z',      // Left triangle
      'M 40 0 L 20 12 L 40 24 Z',    // Right triangle
    ],
  },
  
  // Add more valve types as needed
  CONTROL: {
    id: 'control-valve',
    name: 'Control Valve',
    viewBox: { width: 40, height: 32 },
    paths: [
      'M 0 8 L 20 16 L 0 24 Z',      // Left triangle
      'M 40 8 L 20 16 L 40 24 Z',    // Right triangle
      'M 16 16 L 24 16 L 24 0',      // Stem
    ],
  },
} as const;

/**
 * Pump visual definitions
 */
export const PUMP_VISUALS = {
  CENTRIFUGAL: {
    id: 'centrifugal-pump',
    name: 'Centrifugal Pump',
    viewBox: { width: 48, height: 48 },
    // Circle body is rendered directly in component
    // Impeller lines can be defined here if needed
  },
} as const;

/**
 * Sensor visual definitions
 */
export const SENSOR_VISUALS = {
  PRESSURE: {
    id: 'pressure-sensor',
    name: 'Pressure Sensor',
    viewBox: { width: 32, height: 32 },
    // Circle is rendered directly in component
  },
  
  TEMPERATURE: {
    id: 'temperature-sensor',
    name: 'Temperature Sensor',
    viewBox: { width: 32, height: 32 },
    // Circle is rendered directly in component
  },
} as const;

/**
 * Get visual definition by ID
 */
export function getVisual(id: string): VisualDefinition | undefined {
  // Simple lookup - can be expanded as needed
  const allVisuals = {
    ...VALVE_VISUALS,
    ...PUMP_VISUALS,
    ...SENSOR_VISUALS,
  };
  
  return Object.values(allVisuals).find(v => v.id === id) as VisualDefinition | undefined;
}
