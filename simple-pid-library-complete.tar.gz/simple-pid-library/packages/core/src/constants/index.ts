/**
 * Simple Constants
 * 
 * @packageDocumentation
 */

/**
 * Standard colors
 */
export const COLORS = {
  // Alarms
  NORMAL: '#4CAF50',    // Green
  WARNING: '#FF9800',   // Orange
  ALARM: '#F44336',     // Red
  
  // States
  OPEN: '#4CAF50',      // Green
  CLOSED: '#F44336',    // Red
  ON: '#4CAF50',        // Green
  OFF: '#9E9E9E',       // Gray
  RUNNING: '#4CAF50',   // Green
  STOPPED: '#9E9E9E',   // Gray
  
  // UI
  STROKE: '#333333',
  TEXT: '#333333',
} as const;

/**
 * Component dimensions (viewBox)
 */
export const DIMENSIONS = {
  VALVE: { width: 40, height: 24 },
  PUMP: { width: 48, height: 48 },
  TANK: { width: 60, height: 80 },
  SENSOR: { width: 32, height: 32 },
} as const;
