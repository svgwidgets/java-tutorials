/**
 * Simple Utility Functions
 * 
 * @packageDocumentation
 */

import { COLORS } from '../constants';
import type { AlarmLevel, DigitalState } from '../types';

/**
 * Get color for alarm level
 */
export function getAlarmColor(alarm: AlarmLevel): string {
  switch (alarm) {
    case 'alarm': return COLORS.ALARM;
    case 'warning': return COLORS.WARNING;
    default: return COLORS.NORMAL;
  }
}

/**
 * Get color for digital state
 */
export function getStateColor(state: DigitalState): string {
  switch (state) {
    case 'open': return COLORS.OPEN;
    case 'closed': return COLORS.CLOSED;
    case 'on': return COLORS.ON;
    case 'off': return COLORS.OFF;
    case 'running': return COLORS.RUNNING;
    case 'stopped': return COLORS.STOPPED;
    default: return COLORS.NORMAL;
  }
}

/**
 * Get component color (alarm takes priority)
 */
export function getComponentColor(alarm: AlarmLevel, state: DigitalState): string {
  if (alarm !== 'none') {
    return getAlarmColor(alarm);
  }
  return getStateColor(state);
}

/**
 * Format numeric value
 */
export function formatValue(value: number, precision: number = 1, units?: string): string {
  const formatted = value.toFixed(precision);
  return units ? `${formatted} ${units}` : formatted;
}
