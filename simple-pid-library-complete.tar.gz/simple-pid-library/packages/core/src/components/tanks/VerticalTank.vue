<!--
  VerticalTank Component
  
  Shows tank with animated liquid level
-->

<template>
  <g 
    class="vertical-tank"
    :data-alarm="alarm"
    @click="handleClick"
  >
    <!-- Tank outline -->
    <rect
      x="0"
      y="0"
      :width="width"
      :height="height"
      fill="none"
      stroke="#333"
      stroke-width="2"
    />
    
    <!-- Liquid fill (animated) -->
    <rect
      class="tank-liquid"
      x="2"
      :y="liquidY"
      :width="width - 4"
      :height="liquidHeight"
      :fill="tankColor"
      opacity="0.7"
    />
    
    <!-- Level lines (10%, 50%, 90%) -->
    <g class="level-markers">
      <line x1="0" :y1="height * 0.1" :x2="width" :y2="height * 0.1" stroke="#999" stroke-width="1" stroke-dasharray="2,2" />
      <line x1="0" :y1="height * 0.5" :x2="width" :y2="height * 0.5" stroke="#999" stroke-width="1" stroke-dasharray="2,2" />
      <line x1="0" :y1="height * 0.9" :x2="width" :y2="height * 0.9" stroke="#999" stroke-width="1" stroke-dasharray="2,2" />
    </g>
    
    <!-- Alarm indicator -->
    <circle
      v-if="alarm !== 'none'"
      :cx="width / 2"
      cy="-8"
      r="4"
      :fill="alarmColor"
    />
    
    <!-- Level text -->
    <text
      :x="width / 2"
      :y="height / 2"
      text-anchor="middle"
      font-size="14"
      font-weight="bold"
      fill="#333"
    >{{ level.toFixed(0) }}%</text>
    
    <!-- Volume text (optional) -->
    <text
      v-if="currentVolume !== undefined && units"
      :x="width / 2"
      :y="height / 2 + 15"
      text-anchor="middle"
      font-size="10"
      fill="#666"
    >{{ currentVolume.toFixed(0) }} {{ units }}</text>
    
    <!-- Label -->
    <text
      v-if="showLabel && label"
      :x="width / 2"
      y="-12"
      text-anchor="middle"
      font-size="10"
      font-weight="bold"
      fill="#333"
    >{{ label }}</text>
  </g>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { getAlarmColor } from '../../utils';
import { COLORS } from '../../constants';
import type { BaseComponentProps, AlarmLevel, ComponentEvents } from '../../types';

interface Props extends BaseComponentProps {
  /**
   * Level as percentage (0-100)
   */
  level: number;
  
  /**
   * Optional: Current volume (for display)
   */
  currentVolume?: number;
  
  /**
   * Optional: Volume units (e.g., "L", "gal")
   */
  units?: string;
  
  /**
   * Tank width
   * @default 60
   */
  width?: number;
  
  /**
   * Tank height
   * @default 80
   */
  height?: number;
}

const props = withDefaults(defineProps<Props>(), {
  showLabel: true,
  alarm: 'none',
  width: 60,
  height: 80,
});

const emit = defineEmits<ComponentEvents>();

// Clamp level to 0-100
const clampedLevel = computed(() => {
  return Math.max(0, Math.min(100, props.level));
});

// Calculate liquid height and position
const liquidHeight = computed(() => {
  return (props.height - 4) * (clampedLevel.value / 100);
});

const liquidY = computed(() => {
  return props.height - liquidHeight.value - 2;
});

// Colors
const tankColor = computed(() => {
  if (props.alarm !== 'none') {
    return getAlarmColor(props.alarm);
  }
  return COLORS.NORMAL;
});

const alarmColor = computed(() => getAlarmColor(props.alarm));

function handleClick() {
  emit('click');
}
</script>

<style scoped>
.vertical-tank {
  cursor: pointer;
}

.vertical-tank:hover {
  filter: brightness(1.1);
}

/* Smooth fill animation */
.tank-liquid {
  transition: y 0.5s ease-out, height 0.5s ease-out;
}
</style>
