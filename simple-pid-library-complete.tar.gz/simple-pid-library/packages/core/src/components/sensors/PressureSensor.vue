<!--
  PressureSensor Component
  
  Displays pressure value with alarm indication
-->

<template>
  <g 
    class="pressure-sensor"
    :data-alarm="alarm"
    @click="handleClick"
  >
    <!-- Circle body -->
    <circle
      cx="16"
      cy="16"
      r="14"
      :fill="sensorColor"
      stroke="#333"
      stroke-width="2"
    />
    
    <!-- Tag (e.g., "PT") -->
    <text
      x="16"
      y="14"
      text-anchor="middle"
      font-size="10"
      font-weight="bold"
      fill="#fff"
    >PT</text>
    
    <!-- Value -->
    <text
      x="16"
      y="24"
      text-anchor="middle"
      font-size="8"
      fill="#fff"
    >{{ formattedValue }}</text>
    
    <!-- Label -->
    <text
      v-if="showLabel && label"
      x="16"
      y="-8"
      text-anchor="middle"
      font-size="10"
      font-weight="bold"
      fill="#333"
    >{{ label }}</text>
  </g>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { getAlarmColor, formatValue } from '../../utils';
import { COLORS } from '../../constants';
import type { AnalogComponentProps, ComponentEvents } from '../../types';

const props = withDefaults(defineProps<AnalogComponentProps>(), {
  showLabel: true,
  alarm: 'none',
  units: 'PSI',
});

const emit = defineEmits<ComponentEvents>();

const sensorColor = computed(() => {
  if (props.alarm !== 'none') {
    return getAlarmColor(props.alarm);
  }
  return COLORS.NORMAL;
});

const formattedValue = computed(() => {
  return formatValue(props.value, 1, props.units);
});

function handleClick() {
  emit('click');
}
</script>

<style scoped>
.pressure-sensor {
  cursor: pointer;
}

.pressure-sensor:hover {
  filter: brightness(1.1);
}
</style>
