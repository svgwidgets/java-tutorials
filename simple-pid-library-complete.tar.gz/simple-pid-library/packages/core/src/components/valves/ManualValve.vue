<!--
  ManualValve Component
  
  Simple two-way valve showing open/closed state
-->

<template>
  <g 
    class="manual-valve"
    :data-state="state"
    :data-alarm="alarm"
    @click="handleClick"
  >
    <!-- Left triangle -->
    <path
      :d="leftPath"
      :fill="valveColor"
      stroke="#333"
      stroke-width="2"
    />
    
    <!-- Right triangle -->
    <path
      :d="rightPath"
      :fill="valveColor"
      stroke="#333"
      stroke-width="2"
    />
    
    <!-- Alarm indicator -->
    <circle
      v-if="alarm !== 'none'"
      cx="20"
      cy="-8"
      r="4"
      :fill="alarmColor"
    />
    
    <!-- Label -->
    <text
      v-if="showLabel && label"
      x="20"
      y="-12"
      text-anchor="middle"
      font-size="10"
      font-weight="bold"
      fill="#333"
    >{{ label }}</text>
  </g>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { getComponentColor, getAlarmColor } from '../../utils';
import type { DigitalComponentProps, ComponentEvents } from '../../types';

const props = withDefaults(defineProps<DigitalComponentProps>(), {
  showLabel: true,
  alarm: 'none',
});

const emit = defineEmits<ComponentEvents>();

// Paths for valve triangles (40x24 viewBox)
const leftPath = 'M 0 0 L 20 12 L 0 24 Z';
const rightPath = 'M 40 0 L 20 12 L 40 24 Z';

// Colors
const valveColor = computed(() => getComponentColor(props.alarm, props.state));
const alarmColor = computed(() => getAlarmColor(props.alarm));

function handleClick() {
  emit('click');
}
</script>

<style scoped>
.manual-valve {
  cursor: pointer;
}

.manual-valve:hover {
  filter: brightness(1.1);
}
</style>
