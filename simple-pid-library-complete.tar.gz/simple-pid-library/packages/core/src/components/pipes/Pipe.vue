<!--
  Pipe Component
  
  Straight pipe with optional flow animation
-->

<template>
  <g class="pipe">
    <!-- Pipe line -->
    <line
      :x1="x1"
      :y1="y1"
      :x2="x2"
      :y2="y2"
      :stroke="pipeColor"
      :stroke-width="strokeWidth"
    />
    
    <!-- Flow animation dots -->
    <g v-if="flowing" class="flow-animation">
      <circle
        v-for="dot in flowDots"
        :key="dot.id"
        :cx="dot.x"
        :cy="dot.y"
        r="3"
        fill="#2196F3"
        opacity="0.7"
      >
        <animateMotion
          :dur="`${animationDuration}s`"
          repeatCount="indefinite"
        >
          <mpath :href="`#${pathId}`" />
        </animateMotion>
      </circle>
    </g>
    
    <!-- Hidden path for animation -->
    <defs>
      <path
        :id="pathId"
        :d="`M ${x1} ${y1} L ${x2} ${y2}`"
        fill="none"
      />
    </defs>
  </g>
</template>

<script setup lang="ts">
import { computed, ref } from 'vue';
import { COLORS } from '../../constants';

interface Props {
  /**
   * Start X coordinate
   */
  x1: number;
  
  /**
   * Start Y coordinate
   */
  y1: number;
  
  /**
   * End X coordinate
   */
  x2: number;
  
  /**
   * End Y coordinate
   */
  y2: number;
  
  /**
   * Whether fluid is flowing
   * @default false
   */
  flowing?: boolean;
  
  /**
   * Pipe stroke width
   * @default 4
   */
  strokeWidth?: number;
  
  /**
   * Pipe color
   * @default COLORS.STROKE
   */
  color?: string;
  
  /**
   * Number of flow dots
   * @default 3
   */
  flowDots?: number;
  
  /**
   * Animation duration in seconds
   * @default 2
   */
  animationDuration?: number;
}

const props = withDefaults(defineProps<Props>(), {
  flowing: false,
  strokeWidth: 4,
  flowDots: 3,
  animationDuration: 2,
});

// Unique ID for animation path
const pathId = ref(`pipe-path-${Math.random().toString(36).substr(2, 9)}`);

// Pipe color
const pipeColor = computed(() => props.color ?? COLORS.STROKE);

// Create flow dots array
const flowDots = computed(() => {
  if (!props.flowing) return [];
  
  return Array.from({ length: props.flowDots }, (_, i) => ({
    id: i,
    x: props.x1,
    y: props.y1,
  }));
});
</script>

<style scoped>
.pipe {
  pointer-events: none;
}

.flow-animation circle {
  animation: flow-fade 2s ease-in-out infinite;
}

.flow-animation circle:nth-child(1) {
  animation-delay: 0s;
}

.flow-animation circle:nth-child(2) {
  animation-delay: 0.66s;
}

.flow-animation circle:nth-child(3) {
  animation-delay: 1.33s;
}

@keyframes flow-fade {
  0%, 100% { opacity: 0.3; }
  50% { opacity: 0.8; }
}
</style>
