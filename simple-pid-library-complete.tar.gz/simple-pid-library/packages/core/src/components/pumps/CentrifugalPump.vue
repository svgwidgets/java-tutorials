<!--
  CentrifugalPump Component
  
  Shows pump running/stopped state
-->

<template>
  <g 
    class="centrifugal-pump"
    :data-state="state"
    :data-alarm="alarm"
    @click="handleClick"
  >
    <!-- Pump body (circle) -->
    <circle
      cx="24"
      cy="24"
      r="20"
      :fill="pumpColor"
      stroke="#333"
      stroke-width="2"
    />
    
    <!-- Impeller (simple cross) -->
    <g class="impeller" :class="{ 'rotating': state === 'running' }">
      <line x1="24" y1="8" x2="24" y2="40" stroke="#333" stroke-width="3" />
      <line x1="8" y1="24" x2="40" y2="24" stroke="#333" stroke-width="3" />
    </g>
    
    <!-- Alarm indicator -->
    <circle
      v-if="alarm !== 'none'"
      cx="24"
      cy="4"
      r="4"
      :fill="alarmColor"
    />
    
    <!-- Label -->
    <text
      v-if="showLabel && label"
      x="24"
      y="-8"
      text-anchor="middle"
      font-size="10"
      font-weight="bold"
      fill="#333"
    >{{ label }}</text>
  </g>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import { getComponentColor, getAlarmColor } from '../../utils';
import type { DigitalComponentProps, ComponentEvents } from '../../types';

const props = withDefaults(defineProps<DigitalComponentProps>(), {
  showLabel: true,
  alarm: 'none',
});

const emit = defineEmits<ComponentEvents>();

const pumpColor = computed(() => getComponentColor(props.alarm, props.state));
const alarmColor = computed(() => getAlarmColor(props.alarm));

function handleClick() {
  emit('click');
}
</script>

<style scoped>
.centrifugal-pump {
  cursor: pointer;
}

.centrifugal-pump:hover {
  filter: brightness(1.1);
}

.impeller.rotating {
  animation: rotate 2s linear infinite;
  transform-origin: 24px 24px;
}

@keyframes rotate {
  from { transform: rotate(0deg); }
  to { transform: rotate(360deg); }
}
</style>
