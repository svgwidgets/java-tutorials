/**
 * Simple Component Props Type Definitions
 * 
 * @packageDocumentation
 */

/**
 * Alarm levels
 */
export type AlarmLevel = 'none' | 'warning' | 'alarm';

/**
 * Digital component states - simple on/off
 */
export type DigitalState = 'open' | 'closed' | 'on' | 'off' | 'running' | 'stopped';

/**
 * Base props for all components
 */
export interface BaseComponentProps {
  /**
   * Component label/ID
   */
  label?: string;
  
  /**
   * Whether to show the label
   * @default true
   */
  showLabel?: boolean;
  
  /**
   * Alarm state
   * @default 'none'
   */
  alarm?: AlarmLevel;
}

/**
 * Props for digital (on/off) components
 */
export interface DigitalComponentProps extends BaseComponentProps {
  /**
   * Current state
   */
  state: DigitalState;
}

/**
 * Props for analog (numeric) components
 */
export interface AnalogComponentProps extends BaseComponentProps {
  /**
   * Numeric value
   */
  value: number;
  
  /**
   * Engineering unit (e.g., "PSI", "°C")
   */
  units?: string;
}

/**
 * Events emitted by components
 */
export interface ComponentEvents {
  click: [];
}
