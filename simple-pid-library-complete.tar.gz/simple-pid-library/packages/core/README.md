# @pid-library/core

> Simple P&ID component library for Vue 3

## Installation

```bash
npm install @pid-library/core
```

## Quick Start

```vue
<template>
  <svg width="600" height="400" viewBox="0 0 600 400">
    <g transform="translate(100, 150)">
      <PressureSensor
        :value="pressure"
        :alarm="pressureAlarm"
        units="PSI"
        label="PT-001"
      />
    </g>
    
    <g transform="translate(300, 150)">
      <ManualValve
        :state="valveState"
        :alarm="valveAlarm"
        label="V-001"
        @click="toggleValve"
      />
    </g>
    
    <g transform="translate(500, 150)">
      <CentrifugalPump
        :state="pumpState"
        label="P-001"
      />
    </g>
  </svg>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { PressureSensor, ManualValve, CentrifugalPump } from '@pid-library/core';

const pressure = ref(125.5);
const valveState = ref<'open' | 'closed'>('closed');
const pumpState = ref<'running' | 'stopped'>('stopped');

const pressureAlarm = computed(() => {
  if (pressure.value < 10 || pressure.value > 190) return 'alarm';
  if (pressure.value < 20 || pressure.value > 180) return 'warning';
  return 'none';
});

const valveAlarm = computed(() => 'none');

function toggleValve() {
  valveState.value = valveState.value === 'open' ? 'closed' : 'open';
}
</script>
```

## Components

- `ManualValve` - Two-way valve (open/closed)
- `PressureSensor` - Pressure sensor with value display
- `CentrifugalPump` - Pump (running/stopped with rotation)

## Component Props

### Digital Components (Valve, Pump)

```typescript
{
  state: 'open' | 'closed' | 'running' | 'stopped',
  alarm?: 'none' | 'warning' | 'alarm',
  label?: string,
  showLabel?: boolean
}
```

### Analog Components (Sensor)

```typescript
{
  value: number,
  units?: string,
  alarm?: 'none' | 'warning' | 'alarm',
  label?: string,
  showLabel?: boolean
}
```

## Integration Example

```typescript
// Your adapter handles data
adapter.subscribe('valves.V001.state', (value: boolean) => {
  valveState.value = value ? 'open' : 'closed';
});

// Components are just presentation
<ManualValve :state="valveState" @click="handleClick" />
```

## License

MIT
