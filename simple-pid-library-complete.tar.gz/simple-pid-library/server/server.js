/**
 * Simple WebSocket Server - Simulates a PLC/SCADA System
 * 
 * Run: node server.js
 */

const WebSocket = require('ws');

const wss = new WebSocket.Server({ port: 8080 });

console.log('🚀 WebSocket server running on ws://localhost:8080');

// Simulated PLC state
let plcState = {
  pressure: 125.5,
  valveV001: false,      // closed
  pump: false,           // stopped
  tankLevel: 50,
  valveV002: false,      // closed
};

// Start simulation
setInterval(() => {
  // Simulate pressure fluctuations
  plcState.pressure += (Math.random() - 0.5) * 5;
  plcState.pressure = Math.max(0, Math.min(200, plcState.pressure));
  
  // Simulate tank level changes
  if (plcState.pump && plcState.valveV001) {
    // Pump is running and inlet valve is open -> fill tank
    plcState.tankLevel = Math.min(100, plcState.tankLevel + 0.5);
  }
  
  if (plcState.valveV002 && plcState.tankLevel > 0) {
    // Outlet valve is open -> drain tank
    plcState.tankLevel = Math.max(0, plcState.tankLevel - 0.3);
  }
  
  // Broadcast to all clients
  broadcastState();
}, 100); // 10 Hz update rate

function broadcastState() {
  const message = JSON.stringify({
    type: 'state-update',
    data: plcState,
    timestamp: Date.now(),
  });
  
  wss.clients.forEach(client => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(message);
    }
  });
}

wss.on('connection', (ws) => {
  console.log('✅ Client connected');
  
  // Send initial state
  ws.send(JSON.stringify({
    type: 'state-update',
    data: plcState,
    timestamp: Date.now(),
  }));
  
  // Handle commands from client
  ws.on('message', (message) => {
    try {
      const command = JSON.parse(message);
      console.log('📥 Received command:', command);
      
      if (command.type === 'command') {
        handleCommand(command);
      }
    } catch (error) {
      console.error('❌ Error parsing message:', error);
    }
  });
  
  ws.on('close', () => {
    console.log('👋 Client disconnected');
  });
});

function handleCommand(command) {
  const { target, value } = command;
  
  switch (target) {
    case 'valveV001':
      plcState.valveV001 = value;
      console.log(`🔧 Valve V-001: ${value ? 'OPEN' : 'CLOSED'}`);
      break;
      
    case 'pump':
      plcState.pump = value;
      console.log(`🔧 Pump: ${value ? 'RUNNING' : 'STOPPED'}`);
      break;
      
    case 'valveV002':
      plcState.valveV002 = value;
      console.log(`🔧 Valve V-002: ${value ? 'OPEN' : 'CLOSED'}`);
      break;
      
    case 'tankLevel':
      plcState.tankLevel = Math.max(0, Math.min(100, value));
      console.log(`🔧 Tank level manually set: ${value}%`);
      break;
      
    default:
      console.warn('⚠️ Unknown command target:', target);
  }
  
  // Broadcast updated state
  broadcastState();
}

process.on('SIGINT', () => {
  console.log('\n👋 Shutting down server...');
  wss.close();
  process.exit(0);
});
