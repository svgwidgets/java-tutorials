# Simple P&ID Library - v1.0 (Minimal Viable Product)

## ✅ What We Built

A **minimal, working P&ID component library** that can grow based on real requirements.

---

## 📦 Library Structure

```
packages/core/
├── src/
│   ├── components/
│   │   ├── valves/
│   │   │   └── ManualValve.vue         # 2-state valve (open/closed)
│   │   ├── pumps/
│   │   │   └── CentrifugalPump.vue     # 2-state pump (running/stopped)
│   │   ├── sensors/
│   │   │   └── PressureSensor.vue      # Analog sensor
│   │   └── index.ts
│   │
│   ├── types/
│   │   └── index.ts                    # Simple type definitions
│   │
│   ├── utils/
│   │   └── index.ts                    # 4 basic functions
│   │
│   ├── constants/
│   │   └── index.ts                    # Colors + dimensions
│   │
│   └── index.ts                        # Main export
│
├── package.json
└── README.md
```

---

## 🎯 Core Principles

1. **Simple States:** 
   - Digital: `open/closed`, `on/off`, `running/stopped` (NO transitioning, NO mismatch)
   - Analog: Just `value` (NO setpoint, NO deviation)

2. **Minimal Props:**
   - `state` or `value`
   - `alarm` ('none' | 'warning' | 'alarm')
   - `label` (optional)
   - That's it!

3. **Dumb Components:**
   - NO data fetching
   - NO protocol knowledge
   - NO complex logic
   - Just: props in → SVG out → events emitted

4. **No Over-Engineering:**
   - NO validation (trust TypeScript)
   - NO complex state management
   - NO performance optimizations (not needed yet)
   - NO accessibility features (add when needed)
   - NO theming system (use simple color constants)

---

## 📝 Type Definitions (Simple)

```typescript
// types/index.ts

export type AlarmLevel = 'none' | 'warning' | 'alarm';
export type DigitalState = 'open' | 'closed' | 'on' | 'off' | 'running' | 'stopped';

export interface BaseComponentProps {
  label?: string;
  showLabel?: boolean;
  alarm?: AlarmLevel;
}

export interface DigitalComponentProps extends BaseComponentProps {
  state: DigitalState;
}

export interface AnalogComponentProps extends BaseComponentProps {
  value: number;
  units?: string;
}

export interface ComponentEvents {
  click: [];
}
```

**That's all the types you need!**

---

## 🎨 Components

### 1. ManualValve (45 lines)

```vue
<ManualValve
  state="open"
  alarm="none"
  label="V-001"
  @click="handleClick"
/>
```

**Features:**
- 2 triangles (SVG paths)
- Color based on alarm/state
- Small alarm indicator circle
- Label on top
- Click event

### 2. PressureSensor (50 lines)

```vue
<PressureSensor
  :value="125.5"
  units="PSI"
  alarm="warning"
  label="PT-001"
/>
```

**Features:**
- Circle with "PT" text
- Shows formatted value
- Color based on alarm
- Label on top

### 3. CentrifugalPump (55 lines)

```vue
<CentrifugalPump
  state="running"
  label="P-001"
/>
```

**Features:**
- Circle body
- Cross impeller (rotates when running)
- Color based on state
- Simple CSS animation

---

## 🛠️ Utilities (4 Functions)

```typescript
// utils/index.ts

getAlarmColor(alarm)        // Returns hex color
getStateColor(state)        // Returns hex color
getComponentColor(alarm, state)  // Alarm takes priority
formatValue(value, precision, units)  // "125.5 PSI"
```

---

## 🎨 Constants

```typescript
// constants/index.ts

COLORS = {
  NORMAL: '#4CAF50',
  WARNING: '#FF9800',
  ALARM: '#F44336',
  OPEN: '#4CAF50',
  CLOSED: '#F44336',
  // ... etc
}

DIMENSIONS = {
  VALVE: { width: 40, height: 24 },
  PUMP: { width: 48, height: 48 },
  SENSOR: { width: 32, height: 32 },
}
```

---

## 📖 Usage Example

```vue
<template>
  <svg width="800" height="400">
    <g transform="translate(100, 150)">
      <PressureSensor :value="pressure" units="PSI" label="PT-001" />
    </g>
    
    <g transform="translate(300, 150)">
      <ManualValve :state="valveState" label="V-001" @click="toggleValve" />
    </g>
    
    <g transform="translate(500, 150)">
      <CentrifugalPump :state="pumpState" label="P-001" />
    </g>
  </svg>
</template>

<script setup lang="ts">
import { ref } from 'vue';
import { PressureSensor, ManualValve, CentrifugalPump } from '@pid-library/core';

const pressure = ref(125.5);
const valveState = ref<'open' | 'closed'>('closed');
const pumpState = ref<'running' | 'stopped'>('stopped');

function toggleValve() {
  valveState.value = valveState.value === 'open' ? 'closed' : 'open';
}
</script>
```

---

## 🚀 What Can Be Added Later (When Needed)

### Phase 2 (When user asks):
- More components (Tank, TemperatureSensor, ControlValve)
- More valve types (ThreeWay, CheckValve)
- Pipe component with flow animation

### Phase 3 (When complexity grows):
- Mismatch detection (commanded vs actual)
- Transitioning states
- Data quality indicators
- Tooltips/faceplates

### Phase 4 (When performance matters):
- Validation
- Error boundaries
- Performance monitoring
- Complex animations

### Phase 5 (When polish needed):
- Accessibility (ARIA, keyboard)
- Theming system
- Scaling support
- Custom colors per component

---

## ✅ What This Gives You

**TODAY:**
- ✅ Working library (3 components)
- ✅ Clean TypeScript types
- ✅ Works with any protocol
- ✅ Easy to understand
- ✅ Easy to extend
- ✅ Production-ready for simple cases

**Benefits of Simple Approach:**
1. **Fast to build** - Done in hours, not weeks
2. **Easy to modify** - See requirements → add features
3. **No waste** - Only code that's actually used
4. **Clear architecture** - Easy for team to understand
5. **Room to grow** - Add complexity when needed, not before

---

## 📂 File Sizes

```
ManualValve.vue       ~45 lines
PressureSensor.vue    ~50 lines
CentrifugalPump.vue   ~55 lines
types/index.ts        ~30 lines
utils/index.ts        ~25 lines
constants/index.ts    ~20 lines
----------------------------
TOTAL                 ~225 lines
```

**vs. over-engineered version: ~2000+ lines** 😅

---

## 🎯 Next Steps

1. **Use it** - Build your first screen
2. **Learn** - See what's actually needed
3. **Add** - Add features based on real requirements
4. **Iterate** - Keep it simple, add complexity only when justified

---

## 💡 Remember

> "Premature optimization is the root of all evil" - Donald Knuth

Start simple. Add complexity when you **need** it, not when you **might** need it.

This library is **ready to use** and **ready to grow**.
