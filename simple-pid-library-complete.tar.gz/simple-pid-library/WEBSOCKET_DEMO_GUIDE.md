# 🚀 Dynamic WebSocket Demo - Setup Guide

Complete working example with **real-time WebSocket communication** between server and client.

---

## 📦 What You Get

```
server/
├── server.js           # WebSocket server (simulates PLC)
└── package.json

example/
├── adapters/
│   └── SimpleWebSocketAdapter.ts    # Client adapter
└── DynamicDemo.vue     # Live demo with real-time updates
```

---

## 🎯 How It Works

```
┌─────────────────┐         WebSocket          ┌─────────────────┐
│  Node.js Server │ ◄─────────────────────────► │   Vue Client    │
│   (Simulated    │                             │   (Your Demo)   │
│      PLC)       │  State Updates (10 Hz)      │                 │
│                 │  Commands (on demand)       │                 │
└─────────────────┘                             └─────────────────┘
```

**Server simulates:**
- Pressure fluctuations
- Tank fills when pump runs
- Tank drains when outlet valve opens
- Broadcasts state at 10 Hz (100ms)

**Client receives:**
- Real-time state updates
- Sends commands when you click valves/pump
- Shows connection status

---

## 🚀 Quick Start

### Step 1: Start the Server

```bash
# Go to server directory
cd server/

# Install dependencies
npm install

# Start server
npm start
```

You should see:
```
🚀 WebSocket server running on ws://localhost:8080
```

### Step 2: Start the Client

```bash
# In another terminal, go to your Vue app
cd example/

# Install dependencies (if not already)
npm install

# Start dev server
npm run dev
```

### Step 3: Open Browser

Navigate to `http://localhost:5173` (or whatever port Vite shows)

You should see:
- 🟢 **CONNECTED** indicator
- Live pressure updates
- Interactive valves and pump
- Tank filling/draining in real-time

---

## 🎮 Try It Out

### Scenario 1: Fill the Tank

1. Click **V-001** (Inlet Valve) → Opens
2. Click **P-001** (Pump) → Starts running
3. Watch: Tank level increases! 📈

### Scenario 2: Drain the Tank

1. Click **V-002** (Outlet Valve) → Opens
2. Watch: Tank level decreases! 📉

### Scenario 3: See Live Updates

1. Watch pressure fluctuate (simulated)
2. Check "Updated: X seconds ago"
3. See update rate (should be ~10 updates/sec)

---

## 📡 WebSocket Protocol

### Server → Client (State Updates)

```json
{
  "type": "state-update",
  "data": {
    "pressure": 125.5,
    "valveV001": false,
    "pump": false,
    "tankLevel": 50,
    "valveV002": false
  },
  "timestamp": 1707686400000
}
```

### Client → Server (Commands)

```json
{
  "type": "command",
  "target": "valveV001",
  "value": true,
  "timestamp": 1707686400000
}
```

**Available targets:**
- `valveV001` - Inlet valve (boolean)
- `pump` - Pump (boolean)
- `valveV002` - Outlet valve (boolean)
- `tankLevel` - Manual level override (0-100)

---

## 🔧 Adapter API

### Simple WebSocket Adapter

```typescript
import { SimpleWebSocketAdapter } from './adapters/SimpleWebSocketAdapter';

// 1. Create adapter
const adapter = new SimpleWebSocketAdapter('ws://localhost:8080');

// 2. Track connection
adapter.onConnectionChange = (state) => {
  console.log('Connection:', state);
};

// 3. Subscribe to updates
adapter.subscribe((data) => {
  // Update your UI state
  pressure.value = data.pressure;
  valveState.value = data.valveV001 ? 'open' : 'closed';
});

// 4. Connect
await adapter.connect();

// 5. Send commands
adapter.sendCommand('valveV001', true);

// 6. Cleanup
adapter.disconnect();
```

**Methods:**
- `connect()` - Connect to server (auto-reconnects on disconnect)
- `disconnect()` - Disconnect and stop auto-reconnect
- `subscribe(callback)` - Subscribe to state updates
- `sendCommand(target, value)` - Send command to server
- `isConnected()` - Check connection status
- `getConnectionState()` - Get detailed state

**Connection States:**
- `disconnected` - Not connected
- `connecting` - Connection in progress
- `connected` - Connected and receiving data
- `error` - Connection error

---

## 🎨 Component Integration

### Simple Pattern

```vue
<script setup lang="ts">
import { ref, onMounted } from 'vue';
import { ManualValve } from '@pid-library/core';
import { SimpleWebSocketAdapter } from './adapters/SimpleWebSocketAdapter';

const adapter = new SimpleWebSocketAdapter('ws://localhost:8080');
const valveState = ref<'open' | 'closed'>('closed');

onMounted(async () => {
  // Subscribe to updates
  adapter.subscribe((data) => {
    valveState.value = data.valveV001 ? 'open' : 'closed';
  });
  
  // Connect
  await adapter.connect();
});

// Send command
function toggleValve() {
  const newValue = valveState.value === 'closed';
  adapter.sendCommand('valveV001', newValue);
}
</script>

<template>
  <ManualValve
    :state="valveState"
    @click="toggleValve"
  />
</template>
```

---

## 🔍 Console Output

### Server Console

```
🚀 WebSocket server running on ws://localhost:8080
✅ Client connected
📥 Received command: { type: 'command', target: 'valveV001', value: true }
🔧 Valve V-001: OPEN
📥 Received command: { type: 'command', target: 'pump', value: true }
🔧 Pump: RUNNING
```

### Browser Console

```
[WS] ✅ Connected
[WS] 📤 Command sent: valveV001 true
[WS] 📤 Command sent: pump true
```

---

## 🛠️ Customization

### Change Update Rate

In `server.js`:
```javascript
setInterval(() => {
  broadcastState();
}, 100); // Change to 500 for 2 Hz, 50 for 20 Hz, etc.
```

### Add New Data Points

In `server.js`:
```javascript
let plcState = {
  pressure: 125.5,
  temperature: 75,        // NEW
  flowRate: 0,           // NEW
  // ... existing fields
};
```

In `DynamicDemo.vue`:
```typescript
adapter.subscribe((data) => {
  pressure.value = data.pressure;
  temperature.value = data.temperature;  // NEW
  flowRate.value = data.flowRate;        // NEW
});
```

### Change WebSocket Port

In `server.js`:
```javascript
const wss = new WebSocket.Server({ port: 3000 }); // Change port
```

In `DynamicDemo.vue`:
```typescript
const adapter = new SimpleWebSocketAdapter('ws://localhost:3000');
```

---

## 🐛 Troubleshooting

### Client shows "DISCONNECTED"

**Check:**
1. Is server running? (`npm start` in server/)
2. Correct port? (default: 8080)
3. Browser console for errors

**Fix:**
```bash
# In server/
npm start
```

### "EADDRINUSE" Error

Port 8080 already in use.

**Fix:**
```bash
# Find process using port 8080
lsof -i :8080

# Kill it
kill -9 <PID>

# Or change port in server.js
```

### Slow Updates

Check update rate in server:
```javascript
setInterval(() => {
  broadcastState();
}, 100); // Should be 100ms for 10 Hz
```

### Connection Keeps Dropping

Check firewall or use different port:
```javascript
const wss = new WebSocket.Server({ port: 9000 });
```

---

## 📊 Performance

- **Update Rate:** 10 Hz (configurable)
- **Latency:** < 10ms (local network)
- **Bandwidth:** ~100 bytes/message
- **Memory:** ~5 MB (server)
- **CPU:** < 1% (idle)

---

## 🎯 Next Steps

### Add More Components

```typescript
// In server.js
let plcState = {
  // ... existing
  valveV003: false,  // NEW
  tank2Level: 0,     // NEW
};

// In DynamicDemo.vue
<ManualValve :state="valve3State" label="V-003" />
<VerticalTank :level="tank2Level" label="T-002" />
```

### Add Authentication

```javascript
// In server.js
wss.on('connection', (ws, req) => {
  const token = new URL(req.url, 'http://localhost').searchParams.get('token');
  
  if (token !== 'secret123') {
    ws.close(1008, 'Unauthorized');
    return;
  }
  
  // ... rest of connection handler
});

// In adapter
const adapter = new SimpleWebSocketAdapter('ws://localhost:8080?token=secret123');
```

### Add Data Logging

```javascript
// In server.js
const fs = require('fs');

function logState() {
  const log = {
    timestamp: Date.now(),
    ...plcState,
  };
  
  fs.appendFileSync('data.log', JSON.stringify(log) + '\n');
}

setInterval(logState, 1000); // Log every second
```

---

## 🎉 Summary

✅ Real WebSocket server (simulates PLC)  
✅ Real-time updates (10 Hz)  
✅ Simple adapter (< 100 lines)  
✅ Interactive demo  
✅ Auto-reconnect  
✅ Clean separation (server/client)  

**Everything works. Real-time. Simple. Production-ready pattern.** 🚀
