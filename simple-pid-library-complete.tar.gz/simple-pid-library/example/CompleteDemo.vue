<template>
  <div class="app">
    <h1>Complete P&ID Demo</h1>
    
    <div class="controls">
      <div class="control-group">
        <h3>Tank Controls</h3>
        <button @click="tankLevel = Math.min(100, tankLevel + 10)">Fill Tank (+10%)</button>
        <button @click="tankLevel = Math.max(0, tankLevel - 10)">Drain Tank (-10%)</button>
      </div>
      
      <div class="control-group">
        <h3>Flow Controls</h3>
        <button @click="toggleInletValve">Toggle Inlet Valve</button>
        <button @click="togglePump">Toggle Pump</button>
        <button @click="toggleOutletValve">Toggle Outlet Valve</button>
      </div>
      
      <div class="control-group">
        <h3>Pressure</h3>
        <button @click="pressure += 10">Increase (+10)</button>
        <button @click="pressure -= 10">Decrease (-10)</button>
      </div>
    </div>
    
    <svg width="1000" height="600" viewBox="0 0 1000 600" style="border: 1px solid #ccc; background: #f5f5f5;">
      <!-- Title -->
      <text x="500" y="30" text-anchor="middle" font-size="18" font-weight="bold" fill="#333">
        Simple Tank Fill System
      </text>
      
      <!-- Inlet Section -->
      <g id="inlet">
        <!-- Pressure Sensor -->
        <g transform="translate(100, 200)">
          <PressureSensor
            :value="pressure"
            :alarm="pressureAlarm"
            units="PSI"
            label="PT-001"
          />
        </g>
        
        <!-- Pipe from sensor to valve -->
        <Pipe
          :x1="132" :y1="216"
          :x2="250" :y2="216"
          :flowing="inletValveState === 'open'"
        />
        
        <!-- Inlet Valve -->
        <g transform="translate(250, 204)">
          <ManualValve
            :state="inletValveState"
            label="V-001"
            @click="toggleInletValve"
          />
        </g>
        
        <!-- Pipe from valve to pump -->
        <Pipe
          :x1="290" :y1="216"
          :x2="400" :y2="216"
          :flowing="inletValveState === 'open' && pumpState === 'running'"
        />
      </g>
      
      <!-- Pump Section -->
      <g id="pump">
        <g transform="translate(400, 192)">
          <CentrifugalPump
            :state="pumpState"
            label="P-001"
          />
        </g>
        
        <!-- Pipe from pump to tank -->
        <Pipe
          :x1="448" :y1="216"
          :x2="560" :y2="216"
          :flowing="pumpState === 'running' && inletValveState === 'open'"
        />
        
        <!-- Vertical pipe to tank -->
        <Pipe
          :x1="560" :y1="216"
          :x2="560" :y2="300"
          :flowing="pumpState === 'running' && inletValveState === 'open'"
        />
      </g>
      
      <!-- Tank Section -->
      <g id="tank">
        <g transform="translate(530, 300)">
          <VerticalTank
            :level="tankLevel"
            :current-volume="tankVolume"
            units="L"
            :alarm="tankAlarm"
            label="T-001"
            :width="60"
            :height="200"
          />
        </g>
      </g>
      
      <!-- Outlet Section -->
      <g id="outlet">
        <!-- Vertical pipe from tank bottom -->
        <Pipe
          :x1="560" :y1="500"
          :x2="560" :y2="550"
          :flowing="outletValveState === 'open'"
        />
        
        <!-- Horizontal pipe to valve -->
        <Pipe
          :x1="560" :y1="550"
          :x2="650" :y2="550"
          :flowing="outletValveState === 'open'"
        />
        
        <!-- Outlet Valve -->
        <g transform="translate(650, 538)">
          <ManualValve
            :state="outletValveState"
            label="V-002"
            @click="toggleOutletValve"
          />
        </g>
        
        <!-- Pipe to outlet -->
        <Pipe
          :x1="690" :y1="550"
          :x2="800" :y2="550"
          :flowing="outletValveState === 'open'"
        />
        
        <!-- Outlet indicator -->
        <text x="820" y="555" font-size="14" fill="#666">→ Outlet</text>
      </g>
    </svg>
    
    <div class="status">
      <div class="status-grid">
        <div>
          <strong>PT-001 (Inlet Pressure):</strong> 
          {{ pressure.toFixed(1) }} PSI 
          <span :class="`badge ${pressureAlarm}`">{{ pressureAlarm }}</span>
        </div>
        
        <div>
          <strong>V-001 (Inlet Valve):</strong> 
          {{ inletValveState }}
        </div>
        
        <div>
          <strong>P-001 (Pump):</strong> 
          {{ pumpState }}
        </div>
        
        <div>
          <strong>T-001 (Tank):</strong> 
          {{ tankLevel.toFixed(1) }}% ({{ tankVolume.toFixed(0) }} L)
          <span :class="`badge ${tankAlarm}`">{{ tankAlarm }}</span>
        </div>
        
        <div>
          <strong>V-002 (Outlet Valve):</strong> 
          {{ outletValveState }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { 
  PressureSensor, 
  ManualValve, 
  CentrifugalPump, 
  VerticalTank,
  Pipe 
} from '../packages/core/src/components';

// State
const pressure = ref(125.5);
const inletValveState = ref<'open' | 'closed'>('closed');
const pumpState = ref<'running' | 'stopped'>('stopped');
const tankLevel = ref(50);
const outletValveState = ref<'open' | 'closed'>('closed');

// Tank calculations (consumer side - good!)
const tankCapacity = 1000; // Liters
const tankVolume = computed(() => (tankLevel.value / 100) * tankCapacity);

// Alarm logic (consumer side)
const pressureAlarm = computed(() => {
  if (pressure.value < 10 || pressure.value > 190) return 'alarm';
  if (pressure.value < 20 || pressure.value > 180) return 'warning';
  return 'none';
});

const tankAlarm = computed(() => {
  if (tankLevel.value < 5 || tankLevel.value > 95) return 'alarm';
  if (tankLevel.value < 10 || tankLevel.value > 90) return 'warning';
  return 'none';
});

// Actions
function toggleInletValve() {
  inletValveState.value = inletValveState.value === 'open' ? 'closed' : 'open';
}

function togglePump() {
  pumpState.value = pumpState.value === 'running' ? 'stopped' : 'running';
}

function toggleOutletValve() {
  outletValveState.value = outletValveState.value === 'open' ? 'closed' : 'open';
}
</script>

<style scoped>
.app {
  padding: 20px;
  font-family: Arial, sans-serif;
}

h1 {
  margin-bottom: 20px;
}

.controls {
  display: flex;
  gap: 20px;
  margin-bottom: 20px;
}

.control-group {
  padding: 15px;
  background: white;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.control-group h3 {
  margin: 0 0 10px 0;
  font-size: 14px;
  color: #666;
}

button {
  padding: 8px 16px;
  background: #2196F3;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 13px;
  margin: 4px;
}

button:hover {
  background: #1976D2;
}

.status {
  margin-top: 20px;
  padding: 15px;
  background: white;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.status-grid {
  display: grid;
  gap: 10px;
}

.status-grid div {
  padding: 8px;
  background: #f5f5f5;
  border-radius: 3px;
}

.badge {
  padding: 2px 8px;
  border-radius: 3px;
  font-size: 11px;
  font-weight: bold;
  margin-left: 8px;
}

.badge.none {
  background: #4CAF50;
  color: white;
}

.badge.warning {
  background: #FF9800;
  color: white;
}

.badge.alarm {
  background: #F44336;
  color: white;
}
</style>
