/**
 * Simple WebSocket Adapter
 * 
 * Connects to WebSocket server and manages data subscriptions
 */

export type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'error';

export interface StateUpdateCallback {
  (data: any): void;
}

export class SimpleWebSocketAdapter {
  private ws: WebSocket | null = null;
  private connectionState: ConnectionState = 'disconnected';
  private callbacks: Set<StateUpdateCallback> = new Set();
  private reconnectTimer: number | null = null;
  
  public onConnectionChange?: (state: ConnectionState) => void;
  
  constructor(private url: string) {}
  
  /**
   * Connect to WebSocket server
   */
  async connect(): Promise<void> {
    if (this.connectionState === 'connected' || this.connectionState === 'connecting') {
      console.warn('[WS] Already connected or connecting');
      return;
    }
    
    this.setConnectionState('connecting');
    
    try {
      this.ws = new WebSocket(this.url);
      
      this.ws.onopen = () => {
        console.log('[WS] ✅ Connected');
        this.setConnectionState('connected');
        
        // Clear reconnect timer
        if (this.reconnectTimer) {
          clearTimeout(this.reconnectTimer);
          this.reconnectTimer = null;
        }
      };
      
      this.ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data);
          
          if (message.type === 'state-update') {
            // Notify all subscribers
            this.callbacks.forEach(cb => cb(message.data));
          }
        } catch (error) {
          console.error('[WS] Error parsing message:', error);
        }
      };
      
      this.ws.onerror = (error) => {
        console.error('[WS] ❌ Error:', error);
        this.setConnectionState('error');
      };
      
      this.ws.onclose = () => {
        console.log('[WS] 👋 Disconnected');
        this.setConnectionState('disconnected');
        
        // Auto-reconnect after 3 seconds
        this.reconnectTimer = window.setTimeout(() => {
          console.log('[WS] 🔄 Reconnecting...');
          this.connect();
        }, 3000);
      };
    } catch (error) {
      console.error('[WS] Connection failed:', error);
      this.setConnectionState('error');
      throw error;
    }
  }
  
  /**
   * Disconnect from server
   */
  disconnect(): void {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer);
      this.reconnectTimer = null;
    }
    
    if (this.ws) {
      this.ws.close();
      this.ws = null;
    }
    
    this.callbacks.clear();
    this.setConnectionState('disconnected');
  }
  
  /**
   * Subscribe to state updates
   */
  subscribe(callback: StateUpdateCallback): () => void {
    this.callbacks.add(callback);
    
    // Return unsubscribe function
    return () => {
      this.callbacks.delete(callback);
    };
  }
  
  /**
   * Send command to server
   */
  sendCommand(target: string, value: any): void {
    if (!this.isConnected()) {
      console.error('[WS] Cannot send command - not connected');
      return;
    }
    
    const command = {
      type: 'command',
      target,
      value,
      timestamp: Date.now(),
    };
    
    this.ws!.send(JSON.stringify(command));
    console.log('[WS] 📤 Command sent:', target, value);
  }
  
  /**
   * Get current connection state
   */
  getConnectionState(): ConnectionState {
    return this.connectionState;
  }
  
  /**
   * Check if connected
   */
  isConnected(): boolean {
    return this.connectionState === 'connected';
  }
  
  private setConnectionState(state: ConnectionState): void {
    if (this.connectionState !== state) {
      this.connectionState = state;
      this.onConnectionChange?.(state);
    }
  }
}
