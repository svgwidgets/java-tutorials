<template>
  <div class="app">
    <div class="header">
      <h1>🔴 Live P&ID Demo - WebSocket</h1>
      <div class="connection-status" :class="`status-${connectionState}`">
        <span class="indicator"></span>
        {{ connectionState.toUpperCase() }}
      </div>
    </div>
    
    <div class="info-banner">
      <div>💡 <strong>Live Connection:</strong> Data updates in real-time from WebSocket server</div>
      <div>🎮 <strong>Interactive:</strong> Click valves/pump to control the system</div>
      <div>📊 <strong>Simulation:</strong> Tank fills when pump runs, drains when outlet opens</div>
    </div>
    
    <svg width="1000" height="600" viewBox="0 0 1000 600" class="diagram">
      <!-- Title -->
      <text x="500" y="30" text-anchor="middle" font-size="18" font-weight="bold" fill="#333">
        Live Tank Fill System ({{ Math.round(updateRate) }} updates/sec)
      </text>
      
      <!-- Inlet Section -->
      <g id="inlet">
        <!-- Pressure Sensor -->
        <g transform="translate(100, 200)">
          <PressureSensor
            :value="pressure"
            :alarm="pressureAlarm"
            units="PSI"
            label="PT-001"
          />
        </g>
        
        <!-- Pipe from sensor to valve -->
        <Pipe
          :x1="132" :y1="216"
          :x2="250" :y2="216"
          :flowing="inletValveState === 'open'"
        />
        
        <!-- Inlet Valve -->
        <g transform="translate(250, 204)">
          <ManualValve
            :state="inletValveState"
            label="V-001"
            @click="toggleInletValve"
          />
        </g>
        
        <!-- Pipe from valve to pump -->
        <Pipe
          :x1="290" :y1="216"
          :x2="400" :y2="216"
          :flowing="inletValveState === 'open' && pumpState === 'running'"
        />
      </g>
      
      <!-- Pump Section -->
      <g id="pump">
        <g transform="translate(400, 192)">
          <CentrifugalPump
            :state="pumpState"
            label="P-001"
            @click="togglePump"
          />
        </g>
        
        <!-- Pipe from pump to tank -->
        <Pipe
          :x1="448" :y1="216"
          :x2="560" :y2="216"
          :flowing="pumpState === 'running' && inletValveState === 'open'"
        />
        
        <!-- Vertical pipe to tank -->
        <Pipe
          :x1="560" :y1="216"
          :x2="560" :y2="300"
          :flowing="pumpState === 'running' && inletValveState === 'open'"
        />
      </g>
      
      <!-- Tank Section -->
      <g id="tank">
        <g transform="translate(530, 300)">
          <VerticalTank
            :level="tankLevel"
            :current-volume="tankVolume"
            units="L"
            :alarm="tankAlarm"
            label="T-001"
            :width="60"
            :height="200"
          />
        </g>
      </g>
      
      <!-- Outlet Section -->
      <g id="outlet">
        <!-- Vertical pipe from tank bottom -->
        <Pipe
          :x1="560" :y1="500"
          :x2="560" :y2="550"
          :flowing="outletValveState === 'open'"
        />
        
        <!-- Horizontal pipe to valve -->
        <Pipe
          :x1="560" :y1="550"
          :x2="650" :y2="550"
          :flowing="outletValveState === 'open'"
        />
        
        <!-- Outlet Valve -->
        <g transform="translate(650, 538)">
          <ManualValve
            :state="outletValveState"
            label="V-002"
            @click="toggleOutletValve"
          />
        </g>
        
        <!-- Pipe to outlet -->
        <Pipe
          :x1="690" :y1="550"
          :x2="800" :y2="550"
          :flowing="outletValveState === 'open'"
        />
        
        <!-- Outlet indicator -->
        <text x="820" y="555" font-size="14" fill="#666">→ Outlet</text>
      </g>
    </svg>
    
    <div class="live-status">
      <div class="status-card">
        <div class="status-header">
          <strong>PT-001</strong> Inlet Pressure
        </div>
        <div class="status-value">{{ pressure.toFixed(1) }} PSI</div>
        <div class="status-badge" :class="`badge-${pressureAlarm}`">{{ pressureAlarm }}</div>
        <div class="status-update">Updated: {{ formatTime(lastUpdate) }}</div>
      </div>
      
      <div class="status-card" :class="{ active: inletValveState === 'open' }">
        <div class="status-header">
          <strong>V-001</strong> Inlet Valve
        </div>
        <div class="status-value">{{ inletValveState.toUpperCase() }}</div>
        <button @click="toggleInletValve" :disabled="!isConnected">
          {{ inletValveState === 'open' ? 'Close' : 'Open' }}
        </button>
      </div>
      
      <div class="status-card" :class="{ active: pumpState === 'running' }">
        <div class="status-header">
          <strong>P-001</strong> Pump
        </div>
        <div class="status-value">{{ pumpState.toUpperCase() }}</div>
        <button @click="togglePump" :disabled="!isConnected">
          {{ pumpState === 'running' ? 'Stop' : 'Start' }}
        </button>
      </div>
      
      <div class="status-card">
        <div class="status-header">
          <strong>T-001</strong> Tank
        </div>
        <div class="status-value">{{ tankLevel.toFixed(1) }}%</div>
        <div class="status-volume">{{ tankVolume.toFixed(0) }} L</div>
        <div class="status-badge" :class="`badge-${tankAlarm}`">{{ tankAlarm }}</div>
      </div>
      
      <div class="status-card" :class="{ active: outletValveState === 'open' }">
        <div class="status-header">
          <strong>V-002</strong> Outlet Valve
        </div>
        <div class="status-value">{{ outletValveState.toUpperCase() }}</div>
        <button @click="toggleOutletValve" :disabled="!isConnected">
          {{ outletValveState === 'open' ? 'Close' : 'Open' }}
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue';
import { 
  PressureSensor, 
  ManualValve, 
  CentrifugalPump, 
  VerticalTank,
  Pipe 
} from '../packages/core/src/components';
import { SimpleWebSocketAdapter } from './adapters/SimpleWebSocketAdapter';

// Create adapter
const adapter = new SimpleWebSocketAdapter('ws://localhost:8080');

// Connection state
const connectionState = ref<'disconnected' | 'connecting' | 'connected' | 'error'>('disconnected');
const isConnected = computed(() => connectionState.value === 'connected');

// Component state (from WebSocket)
const pressure = ref(0);
const inletValveState = ref<'open' | 'closed'>('closed');
const pumpState = ref<'running' | 'stopped'>('stopped');
const tankLevel = ref(0);
const outletValveState = ref<'open' | 'closed'>('closed');

// UI state
const lastUpdate = ref(Date.now());
const updateCount = ref(0);
const updateRate = ref(0);

// Tank calculations (consumer side)
const tankCapacity = 1000; // Liters
const tankVolume = computed(() => (tankLevel.value / 100) * tankCapacity);

// Alarm logic (consumer side)
const pressureAlarm = computed(() => {
  if (pressure.value < 10 || pressure.value > 190) return 'alarm';
  if (pressure.value < 20 || pressure.value > 180) return 'warning';
  return 'none';
});

const tankAlarm = computed(() => {
  if (tankLevel.value < 5 || tankLevel.value > 95) return 'alarm';
  if (tankLevel.value < 10 || tankLevel.value > 90) return 'warning';
  return 'none';
});

// Calculate update rate
let rateInterval: number;
onMounted(() => {
  rateInterval = window.setInterval(() => {
    updateRate.value = updateCount.value;
    updateCount.value = 0;
  }, 1000);
});

onUnmounted(() => {
  clearInterval(rateInterval);
});

// Format time
function formatTime(timestamp: number): string {
  const now = Date.now();
  const diff = now - timestamp;
  
  if (diff < 1000) return 'just now';
  if (diff < 60000) return `${Math.floor(diff / 1000)}s ago`;
  return new Date(timestamp).toLocaleTimeString();
}

// Initialize connection
onMounted(async () => {
  // Track connection state
  adapter.onConnectionChange = (state) => {
    connectionState.value = state;
  };
  
  // Subscribe to state updates
  adapter.subscribe((data) => {
    // Update component state from WebSocket
    pressure.value = data.pressure;
    inletValveState.value = data.valveV001 ? 'open' : 'closed';
    pumpState.value = data.pump ? 'running' : 'stopped';
    tankLevel.value = data.tankLevel;
    outletValveState.value = data.valveV002 ? 'open' : 'closed';
    
    // Track updates
    lastUpdate.value = Date.now();
    updateCount.value++;
  });
  
  // Connect
  try {
    await adapter.connect();
  } catch (error) {
    console.error('Failed to connect:', error);
  }
});

// Cleanup
onUnmounted(() => {
  adapter.disconnect();
});

// Control functions
function toggleInletValve() {
  if (!isConnected.value) return;
  const newState = inletValveState.value === 'open' ? false : true;
  adapter.sendCommand('valveV001', newState);
}

function togglePump() {
  if (!isConnected.value) return;
  const newState = pumpState.value === 'running' ? false : true;
  adapter.sendCommand('pump', newState);
}

function toggleOutletValve() {
  if (!isConnected.value) return;
  const newState = outletValveState.value === 'open' ? false : true;
  adapter.sendCommand('valveV002', newState);
}
</script>

<style scoped>
.app {
  padding: 20px;
  font-family: Arial, sans-serif;
  background: #f0f2f5;
  min-height: 100vh;
}

.header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

h1 {
  margin: 0;
  font-size: 24px;
}

.connection-status {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 16px;
  border-radius: 20px;
  font-size: 12px;
  font-weight: bold;
}

.connection-status .indicator {
  width: 10px;
  height: 10px;
  border-radius: 50%;
  animation: pulse 2s ease-in-out infinite;
}

.status-disconnected {
  background: #ffebee;
  color: #c62828;
}

.status-disconnected .indicator {
  background: #f44336;
}

.status-connecting {
  background: #fff3e0;
  color: #e65100;
}

.status-connecting .indicator {
  background: #ff9800;
}

.status-connected {
  background: #e8f5e9;
  color: #2e7d32;
}

.status-connected .indicator {
  background: #4caf50;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.info-banner {
  background: #e3f2fd;
  border-left: 4px solid #2196f3;
  padding: 15px;
  margin-bottom: 20px;
  border-radius: 4px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  font-size: 14px;
}

.diagram {
  background: white;
  border-radius: 8px;
  box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  margin-bottom: 20px;
  display: block;
}

.live-status {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 16px;
}

.status-card {
  background: white;
  padding: 16px;
  border-radius: 8px;
  box-shadow: 0 2px 4px rgba(0,0,0,0.1);
  transition: all 0.3s ease;
}

.status-card.active {
  border: 2px solid #4caf50;
  box-shadow: 0 4px 8px rgba(76, 175, 80, 0.3);
}

.status-header {
  font-size: 12px;
  color: #666;
  margin-bottom: 8px;
}

.status-value {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 8px;
}

.status-volume {
  font-size: 14px;
  color: #666;
  margin-bottom: 8px;
}

.status-badge {
  display: inline-block;
  padding: 4px 12px;
  border-radius: 12px;
  font-size: 11px;
  font-weight: bold;
  text-transform: uppercase;
}

.badge-none {
  background: #e8f5e9;
  color: #2e7d32;
}

.badge-warning {
  background: #fff3e0;
  color: #e65100;
}

.badge-alarm {
  background: #ffebee;
  color: #c62828;
}

.status-update {
  font-size: 11px;
  color: #999;
  margin-top: 8px;
}

button {
  width: 100%;
  padding: 8px;
  margin-top: 8px;
  background: #2196f3;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-weight: 600;
  transition: background 0.2s;
}

button:hover:not(:disabled) {
  background: #1976d2;
}

button:disabled {
  background: #ccc;
  cursor: not-allowed;
}
</style>
