<template>
  <div class="app">
    <h1>Simple P&ID Demo</h1>
    
    <div class="controls">
      <button @click="pressure += 10">Increase Pressure</button>
      <button @click="pressure -= 10">Decrease Pressure</button>
      <button @click="toggleValve">Toggle Valve</button>
      <button @click="togglePump">Toggle Pump</button>
    </div>
    
    <svg width="800" height="400" viewBox="0 0 800 400" style="border: 1px solid #ccc; background: #f5f5f5;">
      <!-- Pressure Sensor -->
      <g transform="translate(100, 150)">
        <PressureSensor
          :value="pressure"
          :alarm="pressureAlarm"
          units="PSI"
          label="PT-001"
        />
      </g>
      
      <!-- Pipe -->
      <line x1="132" y1="166" x2="300" y2="166" stroke="#333" stroke-width="4" />
      
      <!-- Manual Valve -->
      <g transform="translate(300, 154)">
        <ManualValve
          :state="valveState"
          :alarm="valveAlarm"
          label="V-001"
          @click="toggleValve"
        />
      </g>
      
      <!-- Pipe -->
      <line x1="340" y1="166" x2="500" y2="166" stroke="#333" stroke-width="4" />
      
      <!-- Centrifugal Pump -->
      <g transform="translate(500, 142)">
        <CentrifugalPump
          :state="pumpState"
          label="P-001"
        />
      </g>
      
      <!-- Pipe -->
      <line x1="548" y1="166" x2="700" y2="166" stroke="#333" stroke-width="4" />
    </svg>
    
    <div class="status">
      <div><strong>Pressure:</strong> {{ pressure.toFixed(1) }} PSI ({{ pressureAlarm }})</div>
      <div><strong>Valve:</strong> {{ valveState }} ({{ valveAlarm }})</div>
      <div><strong>Pump:</strong> {{ pumpState }}</div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import { PressureSensor, ManualValve, CentrifugalPump } from './components';

// State
const pressure = ref(125.5);
const valveState = ref<'open' | 'closed'>('closed');
const pumpState = ref<'running' | 'stopped'>('stopped');

// Alarm logic (your business logic)
const pressureAlarm = computed(() => {
  if (pressure.value < 10 || pressure.value > 190) return 'alarm';
  if (pressure.value < 20 || pressure.value > 180) return 'warning';
  return 'none';
});

const valveAlarm = computed(() => 'none');

// Actions
function toggleValve() {
  valveState.value = valveState.value === 'open' ? 'closed' : 'open';
}

function togglePump() {
  pumpState.value = pumpState.value === 'running' ? 'stopped' : 'running';
}
</script>

<style scoped>
.app {
  padding: 20px;
  font-family: Arial, sans-serif;
}

h1 {
  margin-bottom: 20px;
}

.controls {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}

button {
  padding: 10px 20px;
  background: #2196F3;
  color: white;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  font-size: 14px;
}

button:hover {
  background: #1976D2;
}

.status {
  margin-top: 20px;
  padding: 15px;
  background: white;
  border: 1px solid #ccc;
  border-radius: 4px;
}

.status div {
  margin: 5px 0;
}
</style>
